#include "native_shard_layout.hpp"
#include <cassert>
#include <iostream>
int main(){
 using namespace native_shards;
 static_assert(key(0x08021AB8u)==key(0x08021BD8u));
 static_assert(key(0x08021AB8u)!=key(0x0801014Cu));
 static_assert(key(0x0801A9DAu)==key(0x0801A9DCu));
 if(name(key(0x0801014Cu))!="native_thumb_010020")return 1;
 if(name(key(0x08021AB8u))!="native_thumb_010043")return 2;
 const auto a=name(key(0x0801014Cu)),b=name(key(0x08021AB8u));
 if(a==b)return 3;
 // The name of either file is invariant when any third ROM address appears.
 if(a!=name(key(0x0801014Cu))||b!=name(key(0x08021AB8u)))return 4;
 std::cout<<"Stable address-derived Thumb shard identity PASS\n";
}
