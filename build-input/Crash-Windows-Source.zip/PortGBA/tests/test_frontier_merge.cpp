#include "trace_audit.hpp"
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <iterator>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
namespace fs=std::filesystem;
int main(){
#define CHECK(x) do {if(!(x)){std::cerr<<"FAILED line "<<__LINE__<<": "<<#x<<"\n";std::abort();}} while(false)
 auto dir=fs::current_path()/"frontier-merge-tests";fs::create_directories(dir);
 std::vector<unsigned char> bytes(0x200,0x46);
 bytes[0]=0;bytes[1]=0;bytes[2]=0;bytes[3]=0xEA;
 {std::ofstream f(dir/"a.gba",std::ios::binary);f.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));}
 GbaRom rom;std::string error;CHECK(rom.load(dir/"a.gba",error));
 std::string h=gba_trace_header(rom);h.replace(0,12,"GBA_FRONTIER_V1");
 const auto master=dir/"master.txt",observed=dir/"observed.txt";
 auto put=[&](fs::path file,const std::string& value){std::ofstream(file,std::ios::trunc)<<value;};
 auto read=[&](fs::path file){std::ifstream f(file);return std::string(std::istreambuf_iterator<char>(f),{});};
 put(master,h+"\n0x08000100 THUMB\n");
 put(observed,h+"\n0x08000120 THUMB\n");
 size_t added=0;CHECK(merge_native_frontier(rom,master,observed,added,error)&&added==1);
 std::vector<GbaCodeEdge> roots;CHECK(read_native_frontier(rom,master,roots,error)&&roots.size()==2);
 CHECK(merge_native_frontier(rom,master,observed,added,error)&&added==0);
 const auto before=read(master);
 put(observed,"GBA_FRONTIER_V1 0000000000000000 999\n0x08000140 THUMB\n");
 CHECK(!merge_native_frontier(rom,master,observed,added,error)&&read(master)==before);
 put(observed,h+"\n0x08000121 THUMB\n");
 CHECK(!merge_native_frontier(rom,master,observed,added,error)&&read(master)==before);
 put(observed,h+"\n0x02000000 THUMB\n");
 CHECK(!merge_native_frontier(rom,master,observed,added,error)&&read(master)==before);
 put(observed,h+"\n0x08000140 THUMB\nEXTRA\n");
 CHECK(!merge_native_frontier(rom,master,observed,added,error)&&read(master)==before);
 put(observed,h+"\n0x08000140 THUMB\n");
 CHECK(!merge_native_frontier(rom,master,master,added,error)&&read(master)==before);
 for(int i=0;i<63;i++){
   char line[48];std::snprintf(line,sizeof(line),"0x%08X THUMB\n",0x08000000+2*i);
   std::ofstream(master,std::ios::app)<<line;
 }
 CHECK(!merge_native_frontier(rom,master,observed,added,error));
 std::cout<<"ROM-bound frontier merge and rejection tests passed\n";
 fs::remove_all(dir);
}
