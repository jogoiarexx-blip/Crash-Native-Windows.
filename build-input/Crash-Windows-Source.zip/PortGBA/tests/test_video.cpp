#include "video_evidence_audit.hpp"
#include <fstream>
#include <filesystem>
#include <iostream>
#include <string>
int main(){
 const auto path=std::filesystem::temp_directory_path()/"port_gba_video_audit_test.txt";
 const std::vector<uint8_t> rom{0x11,0x22,0x33};
 uint64_t h=14695981039346656037ull;
 for(auto b:rom){h^=b;h*=1099511628211ull;}
 auto put=[&](int mode){
  std::ofstream out(path);
  out<<"GBA_VIDEO_V1 rom_fnv=0x"<<std::hex<<(mode==1?h+1:h)<<std::dec<<" rom_bytes=3\n";
  out<<"frame=1 cycles=197120 vcount=160 dispcnt=0x100 regs=0x12 vram=0x23 palette=0x34 oam=0x45 vram_changes=1 palette_changes=1 oam_changes=1 video_io_changes=1 dma3=0\n";
  out<<"frame=2 cycles="<<(mode==2?478017:478016)<<" vcount=160 dispcnt=0x100 regs=0x13 vram=0x24 palette=0x35 oam=0x45 vram_changes="<<(mode==3?1:2)<<" palette_changes=2 oam_changes=1 video_io_changes=2 dma3=1\n";
 };
 put(0);auto ok=audit_video_evidence(rom,path.string());
 if((std::cerr<<ok.report<<"\n",!ok.valid)||ok.samples!=2||ok.vram_transitions!=1||ok.palette_transitions!=1||ok.last_dma3!=1)return 1;
 for(int mode=1;mode<=3;++mode){put(mode);auto bad=audit_video_evidence(rom,path.string());if(bad.valid)return 2+mode;}
 std::filesystem::remove(path);
 std::cout<<"GBA_VIDEO_V1 ROM identity, VBlank timestamps, write-counter invariants PASS\n";
}
