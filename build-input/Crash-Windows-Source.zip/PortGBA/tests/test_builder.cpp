#include "gba_rom.hpp"
#include "analyzer.hpp"
#include "generator.hpp"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
namespace fs=std::filesystem;
int main(){
 auto check=[](bool v){if(!v)std::abort();};
 check(true);
 #define check(v) do {if(!(v)){ std::cerr << "FAIL at line " << __LINE__ << ": " << #v << "\n"; std::abort();}}while(false)
 const fs::path root="builder-test-output";fs::remove_all(root);fs::create_directories(root);std::vector<uint8_t>d(0x500,0);
 auto put16=[&](size_t p,uint16_t v){d[p]=uint8_t(v);d[p+1]=uint8_t(v>>8);};
 auto put32=[&](size_t p,uint32_t v){for(int i=0;i<4;i++)d[p+i]=uint8_t(v>>(8*i));};
 // Standard ARM cartridge entry: B 0x080000C0.
 put32(0x00,0xEA00002E);
 const char title[]="TEST GAME";for(size_t i=0;i<sizeof(title)-1;i++)d[0xA0+i]=uint8_t(title[i]);d[0xAC]='T';d[0xAD]='E';d[0xAE]='S';d[0xAF]='T';d[0xB0]='0';d[0xB1]='1';d[0xB2]=0x96;
 uint8_t sum=0;for(size_t i=0xA0;i<=0xBC;i++)sum=uint8_t(sum-d[i]);d[0xBD]=uint8_t(sum-0x19);
 // ARM boot bridge: LDR r0,[pc,#0] / BX r0 / literal 0x08000101.
 put32(0xC0,0xE59F0000);put32(0xC4,0xE12FFF10);put32(0xC8,0x08000101);
 // Thumb entry branches into an agbcc-style switch veneer.
 put16(0x100,0xE00E); // B 0x08000120
 put16(0x120,0x0080); // LSL r0,r0,#2
 put16(0x122,0x4903); // LDR r1,[PC,#12] -> literal at 0x130
 put16(0x124,0x1840); // ADD r0,r0,r1
 put16(0x126,0x6800); // LDR r0,[r0,#0]
 put16(0x128,0x4687); // MOV pc,r0
 put32(0x130,0x08000140);
 put32(0x140,0x08000150);put32(0x144,0x08000160);put32(0x148,0);
 // Old agbcc return form: POP r1; BX r1.
 put16(0x150,0xBC02);put16(0x152,0x4708);
 put16(0x160,0x4770);
 // A valid tiny LZ10 stream and memory-region literals for the broad audit.
 d[0x180]=0x10;d[0x181]=3;d[0x182]=0;d[0x183]=0;d[0x184]=0;d[0x185]='A';d[0x186]='B';d[0x187]='C';
 put32(0x1C0,0x08000100);put32(0x1C4,0x02000020);put32(0x1C8,0x040000B0);
 // Synthetic ARM image stored in ROM, destined for another runtime address.
 put32(0x300,0xE92D4010u); // STMDB sp!,{r4,lr}
 put32(0x304,0xE0000291u); // MUL r0,r1,r2
 put32(0x308,0xE1D430B2u); // LDRH r3,[r4,#2]
 put32(0x30C,0xE12FFF1Eu); // BX lr
 std::ofstream f(root/"test.gba",std::ios::binary);f.write(reinterpret_cast<const char*>(d.data()),std::streamsize(d.size()));f.close();
 GbaRom rom;std::string err;check(rom.load(root/"test.gba",err));auto r=analyze_rom(rom);
 check(r.entry_looks_arm_branch&&r.entry_target==0x080000C0u);
 check(r.rom_pointer_literals>=1&&r.ewram_pointer_literals>=1&&r.dma_io_literals>=1);
 check(r.lz10_candidates>=1&&r.lz10_decompressed_bytes>=3);
 check(!r.cfg.blocks.empty());
 check(r.cfg.arm_blocks>=1&&r.cfg.thumb_blocks>=1);
 check(r.cfg.resolved_indirects>=2); // ARM boot BX + Thumb switch table.
 check(r.cfg.resolved_switch_tables==1);
 check(r.cfg.resolved_switch_targets==2);
 check(r.cfg.compiler_epilogue_returns>=1);
 check(r.cfg.unresolved_indirects==0);
 check(r.cfg.thumb_liftable_blocks>=1);
 bool sawThumb=false,sawCaseA=false,sawCaseB=false;for(const auto& e:r.cfg.blocks){if(e.start==0x08000100u&&e.mode==GbaCodeMode::Thumb)sawThumb=true;if(e.start==0x08000150u)sawCaseA=true;if(e.start==0x08000160u)sawCaseB=true;}check(sawThumb&&sawCaseA&&sawCaseB);
 // Cross-block must-constant: literal function pointer survives a B,
 // then flows into a call-via-r2 stub; a RAM vtable load does not.
 std::vector<uint8_t> indirect(0x500,0);
 auto i16=[&](size_t off,uint16_t value){indirect[off]=uint8_t(value);indirect[off+1]=uint8_t(value>>8);};
 auto i32=[&](size_t off,uint32_t value){for(int j=0;j<4;j++)indirect[off+j]=uint8_t(value>>(8*j));};
 i32(0,0xEA00002Eu); indirect[0xB2]=0x96;
 // ARM boot -> Thumb entry; code at 0x100 loads r2 then branches.
 i32(0xC0,0xE59F0000u);i32(0xC4,0xE12FFF10u);i32(0xC8,0x08000101u);
 i16(0x100,0x4A03); // LDR r2,[PC,#12] = literal 0x110.
 i16(0x102,0xE001); // B 0x108.
 i16(0x108,0xF000);i16(0x10A,0xF80A); // BL 0x120 (_call_via_r2).
 i16(0x10C,0x4770);i32(0x110,0x08000141u);
 i16(0x120,0x4710); // BX r2.
 i16(0x140,0x4770); // concrete target.
 std::ofstream f2(root/"indirect.gba",std::ios::binary);f2.write(reinterpret_cast<const char*>(indirect.data()),std::streamsize(indirect.size()));f2.close();
 GbaRom rom2;check(rom2.load(root/"indirect.gba",err));
 const auto recovered=build_recursive_cfg(rom2,0x080000C0u);
 check(recovered.resolved_dynamic_call_sites==1u);
 check(recovered.resolved_dynamic_call_targets==1u);
 bool foundTarget=false;for(const auto& b:recovered.blocks)if(b.start==0x08000140u)foundTarget=true;
 check(foundTarget);
 // A runtime-loaded address is not a proved ROM function pointer.
 i16(0x100,0x4A03);i16(0x102,0x6812); // LDR r2,[r2] from EWRAM.
 i16(0x104,0xE000); // branch to 0x108.
 i32(0x110,0x02000000u);
 std::ofstream f3(root/"unknown.gba",std::ios::binary);f3.write(reinterpret_cast<const char*>(indirect.data()),std::streamsize(indirect.size()));f3.close();
 GbaRom rom3;check(rom3.load(root/"unknown.gba",err));
 const auto unknown=build_recursive_cfg(rom3,0x080000C0u);
 check(unknown.resolved_dynamic_call_sites==0u);
 // ROM-rooted GBA C++ virtual table: only methods of a table addressed
 // by reached code are lifted, not arbitrary pointer-shaped ROM data.
 std::vector<uint8_t> tables(0x600,0);
 auto t16=[&](size_t off,uint16_t value){tables[off]=uint8_t(value);tables[off+1]=uint8_t(value>>8);};
 auto t32=[&](size_t off,uint32_t value){for(int j=0;j<4;j++)tables[off+j]=uint8_t(value>>(8*j));};
 t32(0,0xEA00002Eu);tables[0xB2]=0x96;
 t32(0xC0,0xE59F0000u);t32(0xC4,0xE12FFF10u);t32(0xC8,0x08000101u);
 t16(0x100,0x4803);t16(0x102,0x4770); // LDR r0, [PC,#12] -> table pointer 0x110.
 t32(0x110,0x08000300u);
 t32(0x308,0u);t32(0x30C,0x08000201u);
 t32(0x310,0u);t32(0x314,0x08000211u);
 t32(0x318,0u);t32(0x31C,0x08000221u);
 t16(0x200,0x4770);t16(0x210,0x4770);t16(0x220,0x4770);
 std::ofstream ft(root/"tables.gba",std::ios::binary);ft.write(reinterpret_cast<const char*>(tables.data()),std::streamsize(tables.size()));ft.close();
 GbaRom rom4;check(rom4.load(root/"tables.gba",err));
 const auto tableCfg=build_recursive_cfg(rom4,0x080000C0u);
 // A runtime-observed Thumb entry seeds reachable blocks but is not a direct-call proof.
 const auto profileCfg=build_recursive_cfg(rom4,0x080000C0u,{{0x08000250u,GbaCodeMode::Thumb}});
 check(profileCfg.profiled_roots.size()==1u);
 check(profileCfg.blocks.size()>tableCfg.blocks.size());
 check(profileCfg.function_entries.size()==tableCfg.function_entries.size());
 const auto invalidCfg=build_recursive_cfg(rom4,0x080000C0u,{{0x0800FFFFu,GbaCodeMode::Thumb}});
 check(invalidCfg.profiled_roots.empty());
 check(tableCfg.rooted_function_tables.size()==1u);
 check(tableCfg.rooted_table_slots==3u);
 check(tableCfg.rooted_table_distinct_functions==3u);
 check(tableCfg.resolved_dynamic_call_sites==0u);
 // Unreferenced 'valid-looking' table must not expand the frontier.
 t16(0x100,0x4770);
 std::ofstream fu(root/"unreferenced.gba",std::ios::binary);fu.write(reinterpret_cast<const char*>(tables.data()),std::streamsize(tables.size()));fu.close();
 GbaRom rom5;check(rom5.load(root/"unreferenced.gba",err));
 const auto noTableCfg=build_recursive_cfg(rom5,0x080000C0u);
 check(noTableCfg.rooted_function_tables.empty());
 // A real straight-line constructor store and a separately reached
 // virtual-call load sequence produce evidence, but never a resolved edge.
 std::vector<uint8_t> vc(0x600,0);
 auto v16=[&](size_t off,uint16_t value){vc[off]=uint8_t(value);vc[off+1]=uint8_t(value>>8);};
 auto v32=[&](size_t off,uint32_t value){for(int j=0;j<4;j++)vc[off+j]=uint8_t(value>>(8*j));};
 v32(0,0xEA00002Eu);vc[0xB2]=0x96;
 v32(0xC0,0xE59F0000u);v32(0xC4,0xE12FFF10u);v32(0xC8,0x08000101u);
 v16(0x100,0x4803); // LDR r0,=vtable+8 (0x110)
 v16(0x102,0x6188); // STR r0,[r1,#24] constructor vptr install
 v16(0x104,0xE00C); // B 0x120
 v32(0x110,0x08000308u);
 v16(0x120,0x6983); // LDR r3,[r0,#24] object vptr
 v16(0x122,0x685A); // LDR r2,[r3,#4] method slot 0
 v16(0x124,0xF000);v16(0x126,0xF814); // BL 0x150 _call_via_r2
 v16(0x128,0x4770);v16(0x150,0x4710); // BX LR, BX r2
 v32(0x308,0);v32(0x30C,0x08000201u);
 v32(0x310,0);v32(0x314,0x08000211u);
 v32(0x318,0);v32(0x31C,0x08000221u);
 v16(0x200,0x4770);v16(0x210,0x4770);v16(0x220,0x4770);
 std::ofstream fv(root/"vc.gba",std::ios::binary);
 fv.write(reinterpret_cast<const char*>(vc.data()),std::streamsize(vc.size()));fv.close();
 GbaRom rv;check(rv.load(root/"vc.gba",err));
 auto vcfg=build_recursive_cfg(rv,0x080000C0u);
 check(vcfg.rooted_function_tables.size()==1u);
 check(vcfg.vtable_installs.size()==1u);
 check(vcfg.vtable_installs[0].table_address==0x08000300u);
 check(vcfg.vtable_installs[0].object_offset==24u);
 check(vcfg.virtual_call_patterns.size()==1u);
 check(vcfg.virtual_call_patterns[0].object_offset==24u);
 check(vcfg.virtual_call_patterns[0].slot_offset==4u);
 check(vcfg.virtual_call_patterns[0].candidate_tables.size()==1u);
 check(vcfg.virtual_call_patterns[0].candidate_methods.size()==1u);
 check(vcfg.virtual_call_patterns[0].candidate_methods[0].address==0x08000200u);
 check(vcfg.resolved_dynamic_call_sites==0u); // candidate != proven
 // Clearing constructor store must discard association, not invent a root.
 v16(0x102,0x2000);
 std::ofstream fn(root/"vc-no-install.gba",std::ios::binary);
 fn.write(reinterpret_cast<const char*>(vc.data()),std::streamsize(vc.size()));fn.close();
 GbaRom rv2;check(rv2.load(root/"vc-no-install.gba",err));
 auto noInstall=build_recursive_cfg(rv2,0x080000C0u);
 check(noInstall.vtable_installs.empty());
 check(noInstall.virtual_call_patterns.size()==1u);
 check(noInstall.virtual_call_patterns[0].candidate_methods.empty());

 // v0.7: the first vptr load and the method load live in DIFFERENT
 // basic blocks. Must-provenance follows an unconditional Thumb branch.
 v16(0x102,0x6188); // restore constructor's vptr store
 v16(0x104,0x4608); // MOV r0,r1: now r0 is the object
 v16(0x106,0xE00B); // B 0x120
 v16(0x120,0x6983); // LDR r3,[r0,#24]
 v16(0x122,0xE002); // B 0x12A
 v16(0x12A,0x685A); // LDR r2,[r3,#4]
 v16(0x12C,0xF000);v16(0x12E,0xF810); // BL 0x150
 v16(0x130,0x4770);
 std::ofstream fcb(root/"vc-crossblock.gba",std::ios::binary);
 fcb.write(reinterpret_cast<const char*>(vc.data()),std::streamsize(vc.size()));fcb.close();
 GbaRom rcb;check(rcb.load(root/"vc-crossblock.gba",err));
 auto cbcfg=build_recursive_cfg(rcb,0x080000C0u);
 check(cbcfg.crossblock_virtual_patterns==1u);
 check(cbcfg.virtual_call_patterns.size()==1u);
 check(cbcfg.virtual_call_patterns[0].callsite==0x0800012Cu);
 check(cbcfg.virtual_call_patterns[0].candidate_methods.size()==1u);
 check(cbcfg.resolved_dynamic_call_sites==0u); // still advisory
 // On the other path, r3 is overwritten. Joining two predecessor
 // states must invalidate its provenance instead of fabricating a call.
 v16(0x122,0xD002); // BEQ 0x12A
 v16(0x124,0x2300); // MOV r3,#0 (different origin)
 v16(0x126,0xE000); // B 0x12A
 std::ofstream fj(root/"vc-join.gba",std::ios::binary);
 fj.write(reinterpret_cast<const char*>(vc.data()),std::streamsize(vc.size()));fj.close();
 GbaRom rj;check(rj.load(root/"vc-join.gba",err));
 auto jcfg=build_recursive_cfg(rj,0x080000C0u);
 check(jcfg.crossblock_virtual_patterns==0u);
 check(jcfg.virtual_call_patterns.empty());
 // Also track which direct caller invokes a function containing a
 // vptr install. This is callgraph evidence, NOT object identity proof.
 v16(0x100,0xF000);v16(0x102,0xF81E); // BL 0x140
 v16(0x104,0x4770);
 v16(0x140,0x4803);v16(0x142,0x6188);v16(0x144,0x4770);
 v32(0x150,0x08000308u);
 std::ofstream fcp(root/"vc-constructor-caller.gba",std::ios::binary);
 fcp.write(reinterpret_cast<const char*>(vc.data()),std::streamsize(vc.size()));fcp.close();
 GbaRom rcp;check(rcp.load(root/"vc-constructor-caller.gba",err));
 auto cpcfg=build_recursive_cfg(rcp,0x080000C0u);
 check(!cpcfg.constructor_callers.empty());
 bool linked=false;
 for(const auto& link:cpcfg.constructor_callers)
    if(link.callsite==0x08000100u && link.callee_entry==0x08000140u &&
       link.constructor_store==0x08000142u && link.table_address==0x08000300u) linked=true;
 check(linked);

 check(is_arm_instruction_liftable(0xE92D4010u));
 check(is_arm_instruction_liftable(0xE0000291u));
 check(is_arm_instruction_liftable(0xE1D430B2u));
 check(!is_arm_instruction_liftable(0xE1D4F0B2u)); // unsupported PC writes
 const GbaRelocatedArm relocated{0x08000300u,0x03000000u,0x40u,0x03000000u};
 check(validate_relocated_arm(rom,relocated,err));
 GbaRelocatedArm withExtra=relocated;
 withExtra.extra_copies.push_back({0x08000300u,0x03002208u,0x40u,0x03002208u});
 check(validate_relocated_arm(rom,withExtra,err));
 withExtra.observed_arm_roots.push_back(0x03002214u);
 check(validate_relocated_arm(rom,withExtra,err));
 withExtra.observed_arm_roots.push_back(0x03005000u);
 check(!validate_relocated_arm(rom,withExtra,err));
 withExtra.observed_arm_roots.pop_back();
 withExtra.extra_copies.push_back({0x08000300u,0x03002220u,0x40u,0x03002220u});
 check(!validate_relocated_arm(rom,withExtra,err));
 withExtra.extra_copies.back().overlay=true;
 check(validate_relocated_arm(rom,withExtra,err)); // explicit runtime-overlaid code image
 withExtra.extra_copies.back().overlay=false;
 check(!validate_relocated_arm(rom,withExtra,err)); // ordinary overlap remains invalid
 withExtra.extra_copies.pop_back();
 withExtra.extra_copies[0].source_rom++;
 check(!validate_relocated_arm(rom,withExtra,err));

 const GbaRelocatedArm relocatedIrq{0x08000300u,0x03000000u,0x40u,0x03000000u,0x03000020u};
 check(validate_relocated_arm(rom,relocatedIrq,err));
 check(!validate_relocated_arm(rom,{0x08000300u,0x03000000u,0x40u,0x03000000u,0x03000041u},err));
 check(!validate_relocated_arm(rom,{0x08000300u,0x03000000u,0x40u,0x03000000u,0x03000080u},err));

 check(!validate_relocated_arm(rom,{0x08000302u,0x03000000u,0x40u,0x03000000u},err));
 check(!validate_relocated_arm(rom,{0x08000300u,0x03007FF0u,0x40u,0x03007FF0u},err));
 check(!validate_relocated_arm(rom,{0x08000300u,0x03000000u,0x40u,0x03000100u},err));
 check(generate_port_project(rom,r,root/"generated",err));
 check(generate_port_project(rom,r,root/"relocated",err,&relocated));
 // v1.7: two distinct original ROM instructions can occupy the SAME
 // runtime address at different times. The C++ dispatcher must emit one
 // switch case with guarded opcode alternatives, never a duplicate case.
 GbaRelocatedArm trueOverlay=relocated;
 trueOverlay.extra_copies.push_back({0x08000304u,0x03000000u,0x10u,0x03000000u,true});
 check(validate_relocated_arm(rom,trueOverlay,err));
 check(generate_port_project(rom,r,root/"overlaid",err,&trueOverlay));
 {std::ifstream source(root/"overlaid/generated/native_iwram.cpp");
  const std::string generated(std::istreambuf_iterator<char>(source),{});
  const std::string testCase="case 0x3000000u:";
  const auto first=generated.find(testCase);
  check(first!=std::string::npos && generated.find(testCase,first+1u)==std::string::npos);
  check(generated.find("runtime.read32(0x3000000u)==0xE92D4010u")!=std::string::npos);
  check(generated.find("runtime.read32(0x3000000u)==0xE0000291u")!=std::string::npos);
 }
 check(fs::exists(root/"relocated/generated/native_iwram.cpp"));
 check(fs::exists(root/"relocated/tests/relocated_boot_integration_test.cpp"));
 {std::ifstream stream(root/"relocated/reports/iwram-lift.txt");
  const std::string content(std::istreambuf_iterator<char>(stream),{});
  check(content.find("generated_ARM_instructions=4")!=std::string::npos);
 }
 // Regeneration with the ROM already inside output/input must not truncate
 // its bytes. In v1.5 the source and destination streams aliased and zeroed it.
 const auto inputCopy=root/"generated/input"/rom.path().filename();
 GbaRom sameInput;check(sameInput.load(inputCopy,err));
 const auto copiedBytes=sameInput.bytes();
 check(generate_port_project(sameInput,r,root/"generated",err));
 GbaRom intact;check(intact.load(inputCopy,err));
 check(intact.bytes()==copiedBytes && !intact.bytes().empty());
 check(fs::exists(root/"generated/runtime/gba_runtime.cpp"));
 check(fs::exists(root/"generated/runtime/thumb_ops.cpp"));
 check(fs::exists(root/"generated/generated/native_blocks.cpp"));
 check(fs::exists(root/"generated/reports/recursive-cfg.txt"));
 fs::remove_all(root);return 0;
}
