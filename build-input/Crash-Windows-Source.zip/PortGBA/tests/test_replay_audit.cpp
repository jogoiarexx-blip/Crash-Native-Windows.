#include "replay_audit.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
namespace fs=std::filesystem;
static uint64_t hashRom(const std::vector<uint8_t>& rom){uint64_t h=14695981039346656037ull;for(uint8_t c:rom){h^=c;h*=1099511628211ull;}return h;}
static void make(const fs::path& dir,const std::vector<uint8_t>& rom,bool diff,bool early=false,bool wrongRom=false){
 fs::create_directories(dir);
 std::ofstream out(dir/"manifest.tsv");out<<"GBA_FRAME_V1\trom_fnv=0x"<<std::hex<<(hashRom(rom)+(wrongRom?1u:0u))<<std::dec<<"\trom_bytes="<<rom.size()<<"\n";
 for(unsigned frame:{10u,20u,30u}){
  const uint64_t pix=(early&&frame==10)?5u:(diff&&frame==30)?4u:3u;
  out<<frame<<"\t0\t0x1f40\t0x"<<std::hex<<pix<<std::dec<<"\t0\tvblank_"<<frame<<".png\n";
  std::ofstream(dir/("vblank_"+std::to_string(frame)+".png"))<<"fixture";
 }
}
int main(){
 const fs::path work="replay-audit-test-work";fs::remove_all(work);
 const std::vector<uint8_t> rom{1,2,3,4};
 make(work/"a",rom,false);make(work/"b",rom,true);
 auto okay=audit_input_replay(rom,work/"a/manifest.tsv",work/"b/manifest.tsv",20);
 assert(okay.valid&&okay.matching_before==2&&okay.divergent_after==1);
 make(work/"b",rom,false);assert(!audit_input_replay(rom,work/"a/manifest.tsv",work/"b/manifest.tsv",20).valid);
 make(work/"b",rom,true,true);assert(!audit_input_replay(rom,work/"a/manifest.tsv",work/"b/manifest.tsv",20).valid);
 make(work/"b",rom,true,false,true);assert(!audit_input_replay(rom,work/"a/manifest.tsv",work/"b/manifest.tsv",20).valid);
 make(work/"b",rom,true);fs::remove(work/"b/vblank_30.png");assert(!audit_input_replay(rom,work/"a/manifest.tsv",work/"b/manifest.tsv",20).valid);
 fs::remove_all(work);std::cout<<"ROM-bound input replay frame audit PASS\n";return 0;
}
