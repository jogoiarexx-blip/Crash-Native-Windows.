#include "trace_audit.hpp"
#include "analyzer.hpp"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
namespace fs=std::filesystem;
int main(){
#define CHECK(x) do{if(!(x)){std::cerr<<"FAILED "<<__LINE__<<" "<<#x<<"\n";std::abort();}}while(false)
 fs::path dir="trace-audit-tests";fs::create_directories(dir);
 std::vector<uint8_t> v(0x300u,0);
 auto put16=[&](size_t off,uint16_t n){v.at(off)=uint8_t(n);v.at(off+1)=uint8_t(n>>8);};
 auto put32=[&](size_t off,uint32_t n){for(unsigned i=0;i<4;++i)v.at(off+i)=uint8_t(n>>(8*i));};
 put32(0,0xEA00002Eu);v[0xB2]=0x96;
 put32(0xC0,0xE59F0000u);put32(0xC4,0xE12FFF10u);put32(0xC8,0x08000101u);
 // BL from 0x100 to the BX r2 veneer at 0x120; valid dynamic callsite.
 put16(0x100,0xF000u);put16(0x102,0xF80Eu);put16(0x104,0x4770u);
 put16(0x120,0x4710u);
 put16(0x140,0x4770u); // not statically reached by this ROM.
 // ROM vtable candidate for a controlled v2 test (method slot +4).
 put32(0x200,0x08000141u);put32(0x204,0x08000141u);
 std::ofstream romFile(dir/"synthetic.gba",std::ios::binary);
 romFile.write(reinterpret_cast<const char*>(v.data()),static_cast<std::streamsize>(v.size()));romFile.close();
 GbaRom rom;std::string err;CHECK(rom.load(dir/"synthetic.gba",err));
 auto cfg=analyze_rom(rom).cfg;
 CHECK(cfg.indirect_call_sites==1u);
 {std::ofstream f(dir/"good.txt");f<<gba_trace_header(rom)<<"\n";
   f<<"0x08000100 0x08000120 0x08000141\n";
   f<<"0x08000100 0x08000120 0x08000141\n"; // dedupe
   f<<"0x08000100 0x08000120 0x02000001\n"; // RAM: observed but not ROM code
   f<<"0x08000100 0x08000120 0x08000101\n"; // already mapped
   f<<"0x08000106 0x08000120 0x08000141\n"; // bad callsite
   f<<"0x08000100 0x08000122 0x08000141\n"; // wrong veneer
   f<<"garbage\n"; // invalid row
 }
 auto audit=audit_dynamic_trace(rom,cfg,dir/"good.txt");
 CHECK(audit.accepted==3u);CHECK(audit.candidate==1u);CHECK(audit.external==1u);
 CHECK(audit.known==1u);CHECK(audit.rejected==3u);CHECK(audit.distinct_callsites==1u);
 CHECK(audit.polymorphic_callsites==1u);
 {std::ofstream f(dir/"wrong-rom.txt");f<<"GBA_TRACE_V1 0000000000000000 0\n0x08000100 0x08000120 0x08000141\n";}
 auto bad=audit_dynamic_trace(rom,cfg,dir/"wrong-rom.txt");CHECK(bad.accepted==0u&&bad.rejected>0u);
 // Conservative ROM-consistency test: validated slot + confirmed
 // provenance-backed call pattern. Synthetic data, never gameplay proof.
 GbaVirtualCallPattern pat;pat.callsite=0x08000100u;pat.veneer=0x08000120u;
 pat.object_offset=0u;pat.slot_offset=4u;pat.candidate_tables.push_back(0x08000200u);
 cfg.virtual_call_patterns.push_back(pat);
 {std::ofstream f(dir/"v2.txt");f<<gba_trace_header(rom).replace(0,12,"GBA_TRACE_V2")<<"\n";
   // Format: callsite, veneer, target, reg, receiver, object_field, vtable, slot, evidence.
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x1\n";
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000024 0x0 0x08000200 0x4 0x1\n"; // distinct receiver
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000028 0x0 0x08000200 0x8 0x1\n"; // wrong slot
   f<<"0x08000100 0x08000120 0x08000141 0xFFFFFFFF 0x0 0x0 0x0 0x0 0x2\n"; // ambiguity
   f<<"0x08000100 0x08000120 0x08000141 0xFFFFFFFF 0x0 0x0 0x0 0x0 0x0\n"; // no evidence
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x03000000 0x0 0x08000204 0x0 0x1\n"; // unrooted table
 }
 const auto v2=audit_dynamic_trace(rom,cfg,dir/"v2.txt");
 CHECK(v2.accepted==4u && v2.consistent_snapshots==2u && v2.ambiguous_snapshots==1u);
 CHECK(v2.rejected==2u && v2.rejected_snapshots==2u);
 // V3 lifecycle: a write generation is valid only until the NEXT write
 // to that word, even if the new word happens to contain the same vtable.
 {std::ofstream f(dir/"v3.txt");f<<gba_trace_header(rom).replace(0,12,"GBA_TRACE_V3")<<"\n";
   f<<"W 0x1 0x02000020 0x08000200\n";
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x3 0x1\n";
   f<<"W 0x2 0x02000020 0x08000204\n";
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x3 0x1\n"; // stale serial, reject
   f<<"W 0x3 0x02000020 0x08000200\n";
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x3 0x3\n";
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x3 0x2\n"; // wrong serial
   f<<"W 0x4 0x02000020 0x08000200\n"; // identical vptr stored again = NEW lifetime generation
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x3 0x3\n"; // same value but stale serial
   f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x3 0x4\n"; // new serial valid
   f<<"W 0x4 0x02000024 0x08000200\n"; // duplicate sequence
   f<<"0x08000100 0x08000120 0x08000141 0xFFFFFFFF 0x0 0x0 0x0 0x0 0x2 0x0\n"; // ambiguous
 }
 const auto v3=audit_dynamic_trace(rom,cfg,dir/"v3.txt");
 CHECK(v3.accepted==4u&&v3.tracked_snapshots==3u&&v3.memory_writes==4u);
 CHECK(v3.rejected==4u&&v3.lifecycle_rejected==4u&&v3.ambiguous_snapshots==1u);
 {std::ofstream f(dir/"v3-missing-write.txt");f<<gba_trace_header(rom).replace(0,12,"GBA_TRACE_V3")<<"\n";
  f<<"0x08000100 0x08000120 0x08000141 0x0 0x02000020 0x0 0x08000200 0x4 0x3 0x1\n";
 }
 const auto missing=audit_dynamic_trace(rom,cfg,dir/"v3-missing-write.txt");
 CHECK(missing.accepted==0u&&missing.rejected==1u&&missing.lifecycle_rejected==1u);
 std::cout<<"trace v1/v2/v3: ROM, vtable, write generations, stale rejection PASS\n";
}
