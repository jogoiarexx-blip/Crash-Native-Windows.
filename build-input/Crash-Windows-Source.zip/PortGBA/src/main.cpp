#include "gba_rom.hpp"
#include "analyzer.hpp"
#include "generator.hpp"
#include "trace_audit.hpp"
#include "replay_audit.hpp"
#include "video_evidence_audit.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
namespace fs=std::filesystem;
static void usage(){std::cout<<R"TXT(Port GBA Builder v2.13.0

Uso:
  PortGBABuilder analyze jogo.gba [saida]
  PortGBABuilder generate jogo.gba pasta_saida [--frontier arquivo.txt] [--iwram-copy ORIGEM_ROM DESTINO_RAM TAMANHO ENTRADA_RAM] [--iwram-irq-entry ENTRADA_IRQ_RAM] [--iwram-extra ORIGEM_ROM DESTINO_RAM TAMANHO ENTRADA_RAM]... [--iwram-overlay ORIGEM_ROM DESTINO_RAM TAMANHO ENTRADA_RAM]... [--iwram-root ENTRADA_ARM_RAM]... [--iwram-scan]
  PortGBABuilder trace-audit jogo.gba trace.txt pasta_saida
  PortGBABuilder video-audit jogo.gba video-evidence.txt
  PortGBABuilder frontier-merge jogo.gba base.txt observado.txt
  PortGBABuilder replay-audit jogo.gba sem-controles/manifest.tsv com-controles/manifest.tsv PRIMEIRO_FRAME

Comandos:
  analyze   Audita header, CFG recursivo ARM/Thumb, memoria, I/O, ponteiros e LZ10
  generate  Cria runtime GBA + blocos ARM/Thumb C++ estaticos + testes de boot
  trace-audit Confere eventos dinamicos contra a ROM exata e o CFG
  video-audit Confere assinaturas de estado de video na ROM exata
  frontier-merge Integra apenas raizes ROM autenticadas, com limite e backup
  replay-audit Compara assinaturas ROM-bound antes e depois da entrada do jogador
)TXT";}
int main(int argc,char**argv){if(argc<3){usage();return 1;}const std::string cmd=argv[1];const fs::path rom_path=argv[2];GbaRom rom;std::string error;if(!rom.load(rom_path,error)){std::cerr<<"ERRO: "<<error<<"\n";return 2;}if(cmd=="replay-audit"){
 if(argc!=6){std::cerr<<"Uso: replay-audit ROM.gba baseline/manifest.tsv input/manifest.tsv first-input-frame\n";return 1;}
 try{size_t used=0;const auto number=std::stoull(argv[5],&used,0);
 if(used!=std::string(argv[5]).size()||number>10000000ull||!number)throw std::out_of_range("frame");
 auto audit=audit_input_replay(rom.bytes(),argv[3],argv[4],unsigned(number));std::cout<<audit.report<<"\n";return audit.valid?0:4;
 }catch(const std::exception&){std::cerr<<"ERRO: first-input-frame invalido\n";return 2;}
}
if(cmd=="frontier-merge"){
 if(argc!=5){std::cerr<<"Uso: frontier-merge ROM.gba master.txt observed.txt\n";return 1;}
 size_t added=0;
 if(!merge_native_frontier(rom,argv[3],argv[4],added,error)){
  std::cerr<<"ERRO: "<<error<<"\n";return 4;
 }
 std::cout<<"Fronteira validada: "<<added<<" novas raizes ROM.\n";return 0;
}
auto report=analyze_rom(rom);
GbaRelocatedArm relocated{};bool haveRelocation=false;
if(cmd=="generate" && argc>4){
    std::vector<GbaCodeEdge> roots;
    for(int i=4;i<argc;){
        const std::string arg=argv[i];
        if(arg=="--frontier" && i+1<argc){
            if(!roots.empty()||!read_native_frontier(rom,argv[i+1],roots,error)){
                std::cerr<<"ERRO: "<<(error.empty()?"Fronteira duplicada":error)<<"\n";return 4;
            }
            i+=2;
        }else if(arg=="--iwram-copy" && !haveRelocation && i+4<argc){
            try{
                auto num=[](const char* s)->uint32_t {std::string t(s);size_t used=0;auto n=std::stoull(t,&used,0);if(used!=t.size()||n>0xFFFFFFFFull)throw std::out_of_range("range");return uint32_t(n);};
                relocated.source_rom=num(argv[i+1]);relocated.dest_ram=num(argv[i+2]);
                relocated.byte_count=num(argv[i+3]);relocated.entry_ram=num(argv[i+4]);
            }catch(const std::exception&){std::cerr<<"ERRO: Numeros invalidos para --iwram-copy\n";return 4;}
            if(!validate_relocated_arm(rom,relocated,error)){
                std::cerr<<"ERRO: "<<error<<"\n";return 4;
            }
            haveRelocation=true;i+=5;
        }else if((arg=="--iwram-extra" || arg=="--iwram-overlay") && haveRelocation && i+4<argc){
            try{
                auto num=[](const char* s)->uint32_t {std::string t(s);size_t used=0;const auto v=std::stoull(t,&used,0);if(used!=t.size()||v>0xFFFFFFFFull)throw std::out_of_range("range");return uint32_t(v);};
                relocated.extra_copies.push_back({num(argv[i+1]),num(argv[i+2]),num(argv[i+3]),num(argv[i+4]),arg=="--iwram-overlay"});
            }catch(const std::exception&){std::cerr<<"ERRO: Parametros invalidos para --iwram-extra\n";return 4;}
            if(!validate_relocated_arm(rom,relocated,error)){std::cerr<<"ERRO: "<<error<<"\n";return 4;}
            i+=5;
        }else if(arg=="--iwram-scan" && haveRelocation && !relocated.scan_rom_backed_copies){
            relocated.scan_rom_backed_copies=true;i+=1;
        }else if(arg=="--iwram-root" && haveRelocation && i+1<argc){
            try{
                const std::string t=argv[i+1];size_t used=0;
                const auto n=std::stoull(t,&used,0);
                if(used!=t.size()||n>0xFFFFFFFFull)throw std::out_of_range("root");
                relocated.observed_arm_roots.push_back(uint32_t(n));
            }catch(const std::exception&){std::cerr<<"ERRO: Entrada ARM IWRAM observada invalida\n";return 4;}
            if(!validate_relocated_arm(rom,relocated,error)){std::cerr<<"ERRO: "<<error<<"\n";return 4;}
            i+=2;
        }else if(arg=="--iwram-irq-entry" && haveRelocation && !relocated.irq_entry_ram && i+1<argc){
            try{
                std::string number=argv[i+1];size_t used=0;
                const auto parsed=std::stoull(number,&used,0);
                if(used!=number.size()||parsed>0xFFFFFFFFull)throw std::out_of_range("irq entry");
                relocated.irq_entry_ram=uint32_t(parsed);
            }catch(const std::exception&){std::cerr<<"ERRO: Entrada IRQ IWRAM invalida\n";return 4;}
            if(!validate_relocated_arm(rom,relocated,error)){std::cerr<<"ERRO: "<<error<<"\n";return 4;}
            i+=2;
        }else{std::cerr<<"ERRO: Opcao generate invalida: "<<arg<<"\n";return 4;}
    }
    if(!roots.empty()){
        report.cfg=build_recursive_cfg(rom,report.entry_target,roots);
        std::cerr<<"Fronteira observada: "<<report.cfg.profiled_roots.size()<<" raizes.\n";
    }
}
if(cmd=="video-audit"){if(argc!=4){std::cerr<<"Informe arquivo GBA_VIDEO_V1\n";return 1;}const auto audit=audit_video_evidence(rom.bytes(),argv[3]);std::cout<<audit.report<<"\n";return audit.valid?0:4;}if(cmd=="analyze"){fs::path out=argc>=4?fs::path(argv[3]):fs::path("analysis-output");fs::create_directories(out);std::ofstream(out/"compatibility-report.txt")<<report_to_text(rom,report);std::ofstream(out/"compatibility-report.json")<<report_to_json(rom,report);std::cout<<report_to_text(rom,report)<<"\nRelatorios salvos em: "<<fs::absolute(out).string()<<"\n";return 0;}if(cmd=="trace-audit"){if(argc<5){std::cerr<<"Informe trace e pasta de saida.\n";return 1;}const auto a=audit_dynamic_trace(rom,report.cfg,argv[3]);fs::create_directories(argv[4]);std::ofstream(fs::path(argv[4])/"trace-audit.txt")<<a.report;std::cout<<a.report;return a.rejected?4:0;}if(cmd=="generate"){if(argc<4){std::cerr<<"Informe a pasta de saida.\n";return 1;}fs::path out=argv[3];if(!generate_port_project(rom,report,out,error,haveRelocation?&relocated:nullptr)){std::cerr<<"ERRO: "<<error<<"\n";return 3;}std::cout<<report_to_text(rom,report)<<"\nProjeto nativo gerado em: "<<fs::absolute(out).string()<<"\n";return 0;}usage();return 1;}
