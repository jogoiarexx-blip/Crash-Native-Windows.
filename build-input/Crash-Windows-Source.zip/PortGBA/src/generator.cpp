#include "generator.hpp"
#include "native_rom_window_template.hpp"
#include "trace_audit.hpp"
#include "ppu_template.hpp"
#include "video_bus_template.hpp"
#include "native_shard_layout.hpp"
#include <algorithm>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iterator>
#include <map>
#include <set>
#include <sstream>

namespace fs = std::filesystem;
namespace {
bool write_file(const fs::path& p,const std::string& s){
    // Avoid recompiling every generated shard when its content has not changed.
    if(fs::exists(p)){
        std::ifstream old(p,std::ios::binary);
        if(old && std::string(std::istreambuf_iterator<char>(old),{})==s)return true;
    }
    fs::create_directories(p.parent_path());
    std::ofstream f(p,std::ios::binary|std::ios::trunc);
    if(!f)return false;
    f<<s;
    return bool(f);
} 
std::string safe_name(std::string s){for(char& c:s)if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-'))c='_';if(s.empty())s="gba_game";return s;}
std::string cpp_string(const std::string& s){std::string o;for(char c:s){if(c=='\\'||c=='\"')o.push_back('\\');o.push_back(c);}return o;}

std::string hexu(uint32_t v){std::ostringstream o;o<<"0x"<<std::hex<<std::uppercase<<v<<"u";return o.str();}


bool arm_block_liftable(const GbaBasicBlock& b){if(b.mode!=GbaCodeMode::Arm||b.instructions.empty())return false;for(const auto&i:b.instructions)if(!is_arm_instruction_liftable(i.raw))return false;return true;}

void emit_arm_noncontrol(std::ostringstream& o,uint32_t w,uint32_t a){
 const unsigned cond=w>>28;
 const std::string guard=cond==14u?std::string():std::string("if(runtime.condition(")+std::to_string(cond)+"))";
 if((w&0x0FB0FFF0u)==0x0120F000u){const unsigned fields=(w>>16)&15u,rm=w&15u;o<<"      "<<guard<<"ArmOps::msr(runtime,"<<fields<<","<<rm<<");\n";return;}
 if((w&0x0F000000u)==0x0F000000u){const unsigned swi=(w>>16)&255u;o<<"      "<<guard<<"runtime.swi("<<swi<<");\n";return;}
 if((w&0x0E000000u)==0x08000000u){const unsigned pre=(w>>24)&1u,up=(w>>23)&1u,wb=(w>>21)&1u,load=(w>>20)&1u,rn=(w>>16)&15u,list=w&0xFFFFu;
 o<<"      "<<guard<<"ArmOps::blockTransfer(runtime,"<<load<<","<<pre<<","<<up<<","<<wb<<","<<rn<<","<<list<<","<<hexu(a)<<");\n";return;}
 if((w&0x0E000090u)==0x00000090u&&(w&0x0FC000F0u)!=0x00000090u){
   const unsigned pre=(w>>24)&1u,up=(w>>23)&1u,imm=(w>>22)&1u,wb=(w>>21)&1u,load=(w>>20)&1u,rn=(w>>16)&15u,rd=(w>>12)&15u,sh=(w>>5)&3u;
   const unsigned offset=imm?(((w>>8)&15u)<<4)|(w&15u):(w&15u);
   o<<"      "<<guard<<"ArmOps::halfTransfer(runtime,"<<load<<","<<sh<<","<<pre<<","<<up<<","<<wb<<","<<imm<<","<<rn<<","<<rd<<","<<offset<<","<<hexu(a)<<");\n";return;
 }
 if((w&0x0FC000F0u)==0x00000090u){const unsigned acc=(w>>21)&1u,sf=(w>>20)&1u,rd=(w>>16)&15u,rn=(w>>12)&15u,rs=(w>>8)&15u,rm=w&15u;
 o<<"      "<<guard<<"ArmOps::multiply(runtime,"<<acc<<","<<sf<<","<<rd<<","<<rn<<","<<rs<<","<<rm<<");\n";return;}
 if((w&0x0C000000u)==0x04000000u){const unsigned pre=(w>>24)&1u,up=(w>>23)&1u,byte=(w>>22)&1u,writeback=(w>>21)&1u,load=(w>>20)&1u,rn=(w>>16)&15u,rd=(w>>12)&15u,imm=w&0xFFFu,regOffset=(w>>25)&1u;o<<"      "<<guard<<"ArmOps::singleTransfer(runtime,"<<load<<","<<byte<<","<<pre<<","<<up<<","<<writeback<<","<<rn<<","<<rd<<","<<imm<<","<<regOffset<<","<<hexu(a)<<");\n";return;}
 if((w&0x0C000000u)==0){const unsigned opcode=(w>>21)&15u,setf=(w>>20)&1u,rn=(w>>16)&15u,rd=(w>>12)&15u,imm=(w>>25)&1u;o<<"      "<<guard<<"ArmOps::dataProc(runtime,"<<opcode<<","<<setf<<","<<rn<<","<<rd<<","<<imm;if(imm){o<<","<<(w&255u)<<","<<((w>>8)&15u)<<",0,0,0,";}else{o<<",0,0,"<<(w&15u)<<","<<((w>>5)&3u)<<","<<((w>>7)&31u)<<",";}o<<hexu(a)<<");\n";return;}
}

void emit_arm_block_case(std::ostringstream& o,const GbaBasicBlock& b){
 o<<"    case "<<hexu(b.start)<<": {\n";
 for(const auto& rec:b.instructions){const uint32_t w=rec.raw;const unsigned cond=w>>28;
  if((w&0x0E000000u)==0x0A000000u&&cond!=15u){const int32_t imm=int32_t(w&0xFFFFFFu);const int32_t sx=(imm&0x800000)?(imm|int32_t(0xFF000000u)):imm;const uint32_t t=uint32_t(int64_t(rec.address)+8+int64_t(sx)*4);const bool link=(w&0x01000000u)!=0;if(cond==14u){if(link)o<<"      runtime.reg(14)="<<hexu(rec.address+4u)<<";\n";o<<"      return {NativeTransferKind::Next,"<<hexu(t)<<",false};\n    }\n";}else{o<<"      if(runtime.condition("<<cond<<")){";if(link)o<<"runtime.reg(14)="<<hexu(rec.address+4u)<<";";o<<"return {NativeTransferKind::Next,"<<hexu(t)<<",false};}\n      return {NativeTransferKind::Next,"<<hexu(rec.address+4u)<<",false};\n    }\n";}return;}
  if((w&0x0FFFFFF0u)==0x012FFF10u){const unsigned rm=w&15u;if(cond==14u)o<<"      {const uint32_t t=runtime.reg("<<rm<<");return {NativeTransferKind::Next,t&~1u,(t&1u)!=0};}\n    }\n";else o<<"      if(runtime.condition("<<cond<<")){const uint32_t t=runtime.reg("<<rm<<");return {NativeTransferKind::Next,t&~1u,(t&1u)!=0};}\n      return {NativeTransferKind::Next,"<<hexu(rec.address+4u)<<",false};\n    }\n";return;}
  if((w&0x0E100000u)==0x08100000u&&(w&0x8000u)){
     emit_arm_noncontrol(o,w,rec.address);
     if(cond!=14u)o<<"      if(runtime.condition("<<cond<<")){const uint32_t t=runtime.reg(15);return {NativeTransferKind::Next,t&~1u,(t&1u)!=0};}\n";
     else o<<"      {const uint32_t t=runtime.reg(15);return {NativeTransferKind::Next,t&~1u,(t&1u)!=0};}\n";
  }else if((w&0x0C000000u)==0u && ((w>>12)&15u)==15u &&
           ((w>>21)&15u)!=8u && ((w>>21)&15u)!=9u &&
           ((w>>21)&15u)!=10u && ((w>>21)&15u)!=11u){
    // ARM ALU writing PC is a branch; guard both effect and transfer.
    if(cond!=14u)o<<"      if(runtime.condition("<<cond<<")){\n";
    emit_arm_noncontrol(o,w,rec.address);
    o<<"      return {NativeTransferKind::Next,runtime.reg(15)&~3u,false};\n";
    if(cond!=14u)o<<"      }\n";
    else {o<<"    }\n";return;}
  }else emit_arm_noncontrol(o,w,rec.address);
 }
 uint32_t next=b.end;if(!b.successors.empty())next=b.successors.front().address;o<<"      return {NativeTransferKind::Next,"<<hexu(next)<<",false};\n    }\n";
}

bool thumb_block_liftable(const GbaBasicBlock& b){
 if(b.mode!=GbaCodeMode::Thumb||b.instructions.empty())return false;
 for(size_t i=0;i<b.instructions.size();++i){
  const uint16_t h=static_cast<uint16_t>(b.instructions[i].raw);
  const bool has=i+1<b.instructions.size();
  const uint16_t n=has?static_cast<uint16_t>(b.instructions[i+1].raw):0;
  if(!is_thumb_instruction_liftable(h,n,has))return false;
  if((h&0xF800u)==0xF000u&&has&&((n&0xF800u)==0xF800u))++i;
 }
 return true;
}

void emit_thumb_noncontrol(std::ostringstream& o,uint16_t h,uint32_t a){
 if((h&0xE000u)==0x0000u){
  if((h&0xF800u)==0x1800u){const unsigned imm=(h>>10)&1u,sub=(h>>9)&1u,rn=(h>>6)&7u,rs=(h>>3)&7u,rd=h&7u;o<<"      ThumbOps::addSub(runtime,"<<sub<<","<<imm<<","<<rd<<","<<rs<<","<<rn<<");\n";}
  else{const unsigned op=(h>>11)&3u,imm=(h>>6)&31u,rs=(h>>3)&7u,rd=h&7u;o<<"      ThumbOps::shiftImm(runtime,"<<op<<","<<rd<<","<<rs<<","<<imm<<");\n";}return;
 }
 if((h&0xE000u)==0x2000u){const unsigned op=(h>>11)&3u,rd=(h>>8)&7u,imm=h&255u;o<<"      ThumbOps::immOp(runtime,"<<op<<","<<rd<<","<<imm<<");\n";return;}
 if((h&0xFC00u)==0x4000u){const unsigned op=(h>>6)&15u,rs=(h>>3)&7u,rd=h&7u;o<<"      ThumbOps::alu(runtime,"<<op<<","<<rd<<","<<rs<<");\n";return;}
 if((h&0xFC00u)==0x4400u){const unsigned op=(h>>8)&3u,rd=(h&7u)|((h>>4)&8u),rs=(h>>3)&15u;if(op!=3u)o<<"      ThumbOps::highOp(runtime,"<<op<<","<<rd<<","<<rs<<","<<hexu(a)<<");\n";return;}
 if((h&0xF800u)==0x4800u){const unsigned rd=(h>>8)&7u;const uint32_t lit=((a+4u)&~3u)+uint32_t(h&255u)*4u;o<<"      runtime.reg("<<rd<<")=runtime.read32("<<hexu(lit)<<");\n";return;}
 if((h&0xF000u)==0x5000u){const unsigned ro=(h>>6)&7u,rb=(h>>3)&7u,rd=h&7u;if((h&0x0200u)==0){const unsigned load=(h>>11)&1u,byte=(h>>10)&1u;o<<"      ThumbOps::loadStoreReg(runtime,"<<load<<","<<byte<<","<<rd<<","<<rb<<","<<ro<<");\n";}else{const unsigned hs=(h>>10)&3u;o<<"      ThumbOps::loadStoreSign(runtime,"<<hs<<","<<rd<<","<<rb<<","<<ro<<");\n";}return;}
 if((h&0xE000u)==0x6000u){const unsigned byte=(h>>12)&1u,load=(h>>11)&1u,imm=(h>>6)&31u,rb=(h>>3)&7u,rd=h&7u;o<<"      ThumbOps::loadStoreImm(runtime,"<<load<<","<<byte<<","<<rd<<","<<rb<<","<<imm<<");\n";return;}
 if((h&0xF000u)==0x8000u){const unsigned load=(h>>11)&1u,imm=(h>>6)&31u,rb=(h>>3)&7u,rd=h&7u;o<<"      ThumbOps::loadStoreHalf(runtime,"<<load<<","<<rd<<","<<rb<<","<<imm<<");\n";return;}
 if((h&0xF000u)==0x9000u){const unsigned load=(h>>11)&1u,rd=(h>>8)&7u,imm=h&255u;o<<"      ThumbOps::spRelative(runtime,"<<load<<","<<rd<<","<<imm<<");\n";return;}
 if((h&0xF000u)==0xA000u){const unsigned sp=(h>>11)&1u,rd=(h>>8)&7u,imm=h&255u;o<<"      ThumbOps::loadAddress(runtime,"<<sp<<","<<rd<<","<<imm<<","<<hexu(a)<<");\n";return;}
 if((h&0xFF00u)==0xB000u){const unsigned sub=(h>>7)&1u,imm=h&127u;o<<"      ThumbOps::addSp(runtime,"<<sub<<","<<imm<<");\n";return;}
 if((h&0xFE00u)==0xB400u){const unsigned lr=(h>>8)&1u,list=h&255u;o<<"      ThumbOps::push(runtime,"<<list<<","<<lr<<");\n";return;}
 if((h&0xFE00u)==0xBC00u){const unsigned pc=(h>>8)&1u,list=h&255u;if(!pc)o<<"      ThumbOps::pop(runtime,"<<list<<",false);\n";return;}
 if((h&0xF000u)==0xC000u){const unsigned load=(h>>11)&1u,rb=(h>>8)&7u,list=h&255u;o<<"      ThumbOps::multiple(runtime,"<<load<<","<<rb<<","<<list<<");\n";return;}
 if((h&0xFF00u)==0xDF00u){o<<"      runtime.swi("<<(h&255u)<<");\n";return;}
}

void emit_native_block_case(std::ostringstream& o,const GbaBasicBlock& b){
 o<<"    case "<<hexu(b.start)<<": {\n";
 for(size_t i=0;i<b.instructions.size();++i){
  const auto& rec=b.instructions[i];const uint16_t h=static_cast<uint16_t>(rec.raw);
  if((h&0xF800u)==0xF000u&&i+1<b.instructions.size()){const uint16_t h2=static_cast<uint16_t>(b.instructions[i+1].raw);if((h2&0xF800u)==0xF800u){const int32_t high=((int32_t(h&0x7FFu)^0x400)-0x400)*4096;const int32_t low=int32_t(h2&0x7FFu)*2;const uint32_t target=uint32_t(int64_t(rec.address)+4+high+low);o<<"      runtime.reg(14)="<<hexu((rec.address+4u)|1u)<<";\n      return {NativeTransferKind::Next,"<<hexu(target)<<",true};\n    }\n";++i;return;}}
  if((h&0xF800u)==0xE000u){const int32_t d=((int32_t(h&0x7FFu)^0x400)-0x400)*2;const uint32_t t=uint32_t(int64_t(rec.address)+4+d);o<<"      return {NativeTransferKind::Next,"<<hexu(t)<<",true};\n    }\n";return;}
  if((h&0xF000u)==0xD000u&&((h>>8)&15u)<14u){const unsigned cond=(h>>8)&15u;const int32_t d=int32_t(int8_t(h&255u))*2;const uint32_t t=uint32_t(int64_t(rec.address)+4+d);const uint32_t f=rec.address+2u;o<<"      return {NativeTransferKind::Next,runtime.condition("<<cond<<")?"<<hexu(t)<<":"<<hexu(f)<<",true};\n    }\n";return;}
  if((h&0xFC00u)==0x4400u&&((h>>8)&3u)==3u){const unsigned rs=(h>>3)&15u;const std::string source=rs==15u?hexu(rec.address+4u):(std::string("runtime.reg(")+std::to_string(rs)+")");o<<"      {const uint32_t t="<<source<<";return {NativeTransferKind::Next,t&~1u,(t&1u)!=0};}\n    }\n";return;}
  if((h&0xFC00u)==0x4400u){const unsigned op=(h>>8)&3u,rd=(h&7u)|((h>>4)&8u),rs=(h>>3)&15u;if(rd==15u&&(op==0u||op==2u)){if(op==2u)o<<"      {const uint32_t t="<<(rs==15u?hexu(rec.address+4u):(std::string("runtime.reg(")+std::to_string(rs)+")"))<<"&~1u;return {NativeTransferKind::Next,t,true};}\n    }\n";else o<<"      {const uint32_t t=("<<hexu(rec.address+4u)<<"+runtime.reg("<<rs<<"))&~1u;return {NativeTransferKind::Next,t,true};}\n    }\n";return;}}
  if((h&0xFE00u)==0xBC00u&&(h&0x0100u)){const unsigned list=h&255u;o<<"      {const uint32_t t=ThumbOps::pop(runtime,"<<list<<",true);return {NativeTransferKind::Next,t&~1u,(t&1u)!=0};}\n    }\n";return;}
  emit_thumb_noncontrol(o,h,rec.address);
 }
 uint32_t next=b.end;
 if(!b.successors.empty())next=b.successors.front().address;
 o<<"      return {NativeTransferKind::Next,"<<hexu(next)<<",true};\n    }\n";
}
}


// Relocation validation does not trust a raw RAM root or a source-ROM alias.
// It requires one aligned, bounded copy and an in-range executable ARM entry.
bool validate_relocated_arm(const GbaRom& rom,const GbaRelocatedArm& m,std::string& error){
 if((m.source_rom&3u)||(m.dest_ram&3u)||(m.byte_count&3u)||(m.entry_ram&3u)){
   error="ARM IWRAM copy requires 4-byte alignment";return false;}
 if(m.byte_count<4u||m.byte_count>0x8000u){error="IWRAM copy size outside 4..32768";return false;}
 if(m.dest_ram<0x03000000u||uint64_t(m.dest_ram)+m.byte_count>0x03008000ull){error="IWRAM copy outside physical RAM";return false;}
 if(m.source_rom<0x08000000u||uint64_t(m.source_rom-0x08000000u)+m.byte_count>rom.bytes().size()){
   error="ROM source copy outside the exact input ROM";return false;}
 if(m.entry_ram<m.dest_ram||uint64_t(m.entry_ram)+4u>uint64_t(m.dest_ram)+m.byte_count){error="ARM entry outside copy range";return false;}
 if(m.irq_entry_ram && ((m.irq_entry_ram&3u)!=0u || m.irq_entry_ram<m.dest_ram || uint64_t(m.irq_entry_ram)+4u>uint64_t(m.dest_ram)+m.byte_count)){
    error="ARM IRQ entry outside IWRAM copy or unaligned";return false;
 }
 std::vector<std::pair<uint32_t,uint32_t>> regions{{m.dest_ram,m.dest_ram+m.byte_count}};
 if(m.extra_copies.size()>16u){error="Too many relocated ARM regions";return false;}
 for(const auto& e:m.extra_copies){
   if((e.source_rom&3u)||(e.dest_ram&3u)||(e.byte_count&3u)||(e.entry_ram&3u)){
     error="Extra ARM IWRAM copy requires 4-byte alignment";return false;
   }
   if(e.byte_count<4u||e.byte_count>0x8000u||e.dest_ram<0x03000000u||
      uint64_t(e.dest_ram)+e.byte_count>0x03008000ull){error="Extra ARM copy outside IWRAM";return false;}
   if(e.source_rom<0x08000000u||uint64_t(e.source_rom-0x08000000u)+e.byte_count>rom.bytes().size()){
     error="Extra ARM source outside exact ROM";return false;}
   if(e.entry_ram<e.dest_ram||uint64_t(e.entry_ram)+4u>uint64_t(e.dest_ram)+e.byte_count){error="Extra ARM entry outside copy";return false;}
   const uint32_t end=e.dest_ram+e.byte_count;
   for(const auto& existing:regions)if(e.dest_ram<existing.second&&existing.first<end && !e.overlay){error="Overlapping relocated ARM regions require explicit overlay";return false;}
   regions.push_back({e.dest_ram,end});
 }
 if(m.observed_arm_roots.size()>128u){error="Too many observed IWRAM roots";return false;}
 for(uint32_t root:m.observed_arm_roots){
   bool valid=(root&3u)==0u;
   bool inside=false;
   for(const auto& region:regions)if(root>=region.first&&uint64_t(root)+4u<=region.second)inside=true;
   if(!valid||!inside){error="Observed ARM root outside mapped IWRAM region";return false;}
 }
 return true;
}

namespace {
// One instruction per mapped native block. Enqueue only reachable ARM control
// flow, not the literals/data embedded in a relocatable ROM image.
std::vector<GbaBasicBlock> decode_relocated_arm(const GbaRom& rom,const GbaRelocatedArm& m){
 std::deque<uint32_t> pending{m.entry_ram};if(m.irq_entry_ram)pending.push_back(m.irq_entry_ram);
 for(uint32_t root:m.observed_arm_roots)pending.push_back(root);
 // Opt-in: every aligned word of an explicitly verified ROM->IWRAM copy
 // is eligible for native lifting, even across indirect entry points.
 // Dispatch below still checks the LIVE instruction word for every candidate.
 if(m.scan_rom_backed_copies)
   for(uint32_t offset=0;offset<m.byte_count;offset+=4u)pending.push_back(m.dest_ram+offset);
 std::set<uint32_t> seen;
 std::vector<GbaBasicBlock> out;
 auto inside=[&](uint32_t a){return a>=m.dest_ram && (a&3u)==0u && uint64_t(a)+4u<=uint64_t(m.dest_ram)+m.byte_count;};
 auto enqueue=[&](uint32_t a){if(inside(a)&&!seen.count(a))pending.push_back(a);};
 while(!pending.empty()&&seen.size()<8192u){
   const uint32_t pc=pending.front();pending.pop_front();
   if(!inside(pc)||!seen.insert(pc).second)continue;
   const uint32_t word=rom.read32(size_t(m.source_rom-0x08000000u)+pc-m.dest_ram);
   if(!is_arm_instruction_liftable(word))continue;
   GbaBasicBlock b;b.start=pc;b.end=pc+4u;b.mode=GbaCodeMode::Arm;
   b.terminator=GbaTerminator::Boundary;b.instructions.push_back({pc,word,4});
   const unsigned cond=word>>28;
   const bool branch=(word&0x0E000000u)==0x0A000000u;
   const bool bx=(word&0x0FFFFFF0u)==0x012FFF10u;
   const bool blockPc=(word&0x0E100000u)==0x08100000u&&(word&0x8000u);
   const bool ldrPc=(word&0x0C100000u)==0x04100000u&&((word>>12)&15u)==15u;
   const bool dataPc=(word&0x0C000000u)==0u&&((word>>12)&15u)==15u&&((word>>21)&15u)!=8u&&((word>>21)&15u)!=9u&&((word>>21)&15u)!=10u&&((word>>21)&15u)!=11u;
   if(branch){const int32_t raw=int32_t(word&0xFFFFFFu);const int32_t offset=(raw&0x800000)?(raw|int32_t(0xFF000000u)):raw;
     enqueue(uint32_t(int64_t(pc)+8+int64_t(offset)*4));
     if(cond!=14u||(word&0x01000000u))enqueue(pc+4u);
     b.terminator=GbaTerminator::DirectBranch;
   }else if(bx||blockPc||ldrPc||dataPc){
     if(cond!=14u)enqueue(pc+4u);
     b.terminator=GbaTerminator::Indirect;
   }else enqueue(pc+4u);
   out.push_back(std::move(b));
 }
 std::sort(out.begin(),out.end(),[](const auto&a,const auto&b){return a.start<b.start;});
 return out;
}
}
bool generate_port_project(const GbaRom& rom,const AnalysisReport& report,const fs::path& out_dir,std::string& error,const GbaRelocatedArm* relocated){
 try{
  fs::create_directories(out_dir/"src");fs::create_directories(out_dir/"runtime");fs::create_directories(out_dir/"generated");fs::create_directories(out_dir/"reports");fs::create_directories(out_dir/"input");fs::create_directories(out_dir/"tests");
  const auto project=safe_name(rom.header().game_code.empty()?rom.header().title:rom.header().game_code);
  uint32_t thumbReturnForTest=0;
  uint32_t firstVeneerAddress=0,firstVeneerCallsite=0;unsigned firstVeneerReg=0;
  if(!report.cfg.indirect_veneer_stats.empty()){
    firstVeneerAddress=report.cfg.indirect_veneer_stats.front().address;
    firstVeneerReg=report.cfg.indirect_veneer_stats.front().register_index;
  }
  // Select an observed direct-BL callsite to make the generated smoke trace
  // auditable against the actual ROM. This is a SYNTHETIC invocation.
  for(const auto& b:report.cfg.blocks){
    if(b.mode!=GbaCodeMode::Thumb)continue;
    bool callsVeneer=false;
    for(const auto& edge:b.calls)if(edge.address==firstVeneerAddress)callsVeneer=true;
    if(!callsVeneer)continue;
    for(const auto& ins:b.instructions){
      if(ins.address<0x08000000u)continue;
      const size_t off=static_cast<size_t>(ins.address-0x08000000u);
      if(off+4u<=rom.bytes().size()&&(rom.read16(off)&0xF800u)==0xF000u&&
         (rom.read16(off+2u)&0xF800u)==0xF800u){
        firstVeneerCallsite=ins.address;break;
      }
    }
    if(firstVeneerCallsite)break;
  }
  for(const auto& b:report.cfg.blocks) if(b.mode==GbaCodeMode::Thumb &&
      b.instructions.size()==1u && b.instructions[0].raw==0x4770u &&
      thumb_block_liftable(b)) { thumbReturnForTest=b.start; break; }

  // Find an exact ROM vtable-slot pair for a SYNTHETIC receiver test.
  const GbaVirtualCallPattern* receiverPattern=nullptr;
  uint32_t receiverTable=0,receiverTarget=0;
  for(const auto& pattern:report.cfg.virtual_call_patterns){
    if(receiverPattern)break;
    const auto veneer=std::find_if(report.cfg.indirect_veneer_stats.begin(),report.cfg.indirect_veneer_stats.end(),
        [&](const GbaIndirectVeneerStat& v){return v.address==pattern.veneer;});
    if(veneer==report.cfg.indirect_veneer_stats.end())continue;
    for(uint32_t table:pattern.candidate_tables){
      if(table<0x08000000u||uint64_t(table-0x08000000u)+pattern.slot_offset+4u>rom.bytes().size())continue;
      const uint32_t raw=rom.read32(size_t(table-0x08000000u)+pattern.slot_offset);
      if(raw>=0x08000001u && raw<0x0A000000u && (raw&1u)){
        receiverPattern=&pattern;receiverTable=table;receiverTarget=raw;break;
      }
    }
  }
  std::vector<GbaBasicBlock> iwramBlocks;
  if(relocated){if(!validate_relocated_arm(rom,*relocated,error))return false;
    GbaRelocatedArm primary=*relocated;
    primary.extra_copies.clear();
    primary.observed_arm_roots.clear();
    for(uint32_t root:relocated->observed_arm_roots)if(root>=primary.dest_ram&&uint64_t(root)+4u<=uint64_t(primary.dest_ram)+primary.byte_count)primary.observed_arm_roots.push_back(root);
    iwramBlocks=decode_relocated_arm(rom,primary);
    if(iwramBlocks.empty()||std::none_of(iwramBlocks.begin(),iwramBlocks.end(),[&](const auto& b){return b.start==relocated->entry_ram;})){error="No liftable IWRAM entry";return false;}
    for(const auto& e:relocated->extra_copies){
      GbaRelocatedArm copy{e.source_rom,e.dest_ram,e.byte_count,e.entry_ram};
      copy.scan_rom_backed_copies=relocated->scan_rom_backed_copies;
      for(uint32_t root:relocated->observed_arm_roots)if(root>=e.dest_ram&&uint64_t(root)+4u<=uint64_t(e.dest_ram)+e.byte_count)copy.observed_arm_roots.push_back(root);
      auto blocks=decode_relocated_arm(rom,copy);
      if(blocks.empty()||std::none_of(blocks.begin(),blocks.end(),[&](const auto& b){return b.start==e.entry_ram;})){
        error="No liftable extra IWRAM entry";return false;
      }
      iwramBlocks.insert(iwramBlocks.end(),blocks.begin(),blocks.end());
    }
    std::sort(iwramBlocks.begin(),iwramBlocks.end(),[](const auto&a,const auto&b){return a.start<b.start;});
  }
  // Stable ROM-address windows: discovering one new entry must not renumber
  // thousands of existing blocks and cause all Thumb modules to recompile.
  std::map<uint32_t,std::vector<const GbaBasicBlock*>> thumbShards;
  for(const auto& block:report.cfg.blocks)if(thumb_block_liftable(block))
    thumbShards[native_shards::key(block.start)].push_back(&block);
  const size_t shardCount=thumbShards.size();
  size_t liftableThumbCount=0;
  for(const auto& entry:thumbShards)liftableThumbCount+=entry.second.size();
  auto shardName=[](uint32_t key){return native_shards::name(key);};
  std::ostringstream cmake;
  cmake<<"cmake_minimum_required(VERSION 3.20)\nproject("<<project<<"_Native LANGUAGES CXX)\nset(CMAKE_CXX_STANDARD 17)\nset(CMAKE_CXX_STANDARD_REQUIRED ON)\nset(CMAKE_CXX_EXTENSIONS OFF)\n"
       <<"add_library(gba_runtime runtime/gba_runtime.cpp runtime/arm_ops.cpp runtime/thumb_ops.cpp generated/code_map.cpp generated/block_cycles.cpp generated/native_blocks.cpp generated/native_iwram.cpp";
  for(const auto& entry:thumbShards)cmake<<" generated/"<<shardName(entry.first)<<".cpp";
  cmake<<")\ntarget_include_directories(gba_runtime PUBLIC runtime generated)\n";
  cmake<<"if(WIN32)\n add_executable("<<project<<"_ROM_Window WIN32 src/rom_window_win32.cpp)\n target_link_libraries("<<project<<"_ROM_Window PRIVATE gba_runtime user32 gdi32)\nendif()\n";
  cmake
       <<"add_executable("<<project<<"_Native src/main.cpp generated/game_entry.cpp)\ntarget_link_libraries("<<project<<"_Native PRIVATE gba_runtime)\n"
       <<"enable_testing()\nadd_executable(RuntimeSelfTest tests/runtime_test.cpp)\ntarget_link_libraries(RuntimeSelfTest PRIVATE gba_runtime)\nadd_test(NAME RuntimeSelfTest COMMAND RuntimeSelfTest)\n"
       <<"add_executable(BootBridgeSelfTest tests/boot_bridge_test.cpp)\ntarget_link_libraries(BootBridgeSelfTest PRIVATE gba_runtime)\nadd_test(NAME BootBridgeSelfTest COMMAND BootBridgeSelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  if(thumbReturnForTest)
    cmake<<"add_executable(NativeThumbDispatchSelfTest tests/native_thumb_dispatch_test.cpp)\ntarget_link_libraries(NativeThumbDispatchSelfTest PRIVATE gba_runtime)\nadd_test(NAME NativeThumbDispatchSelfTest COMMAND NativeThumbDispatchSelfTest)\n";
  if(firstVeneerAddress && thumbReturnForTest)
    cmake<<"add_executable(DynamicCallTraceSelfTest tests/dynamic_call_trace_test.cpp)\ntarget_link_libraries(DynamicCallTraceSelfTest PRIVATE gba_runtime)\nadd_test(NAME DynamicCallTraceSelfTest COMMAND DynamicCallTraceSelfTest)\n";
  cmake<<"add_executable(RomPreviewSelfTest tests/rom_preview_test.cpp)\n"
       <<"target_link_libraries(RomPreviewSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME RomPreviewSelfTest COMMAND RomPreviewSelfTest)\n";
  cmake<<"add_executable(VideoBusSelfTest tests/video_bus_test.cpp)\n"
       <<"target_link_libraries(VideoBusSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME VideoBusSelfTest COMMAND VideoBusSelfTest)\n";
  cmake<<"add_executable(ThumbPcPipelineSelfTest tests/thumb_pc_pipeline_test.cpp)\n"
       <<"target_link_libraries(ThumbPcPipelineSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME ThumbPcPipelineSelfTest COMMAND ThumbPcPipelineSelfTest)\n";
  cmake<<"add_executable(PpuObjWindowSelfTest tests/ppu_obj_window_test.cpp)\n"
       <<"target_link_libraries(PpuObjWindowSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME PpuObjWindowSelfTest COMMAND PpuObjWindowSelfTest)\n";
  cmake<<"add_executable(PpuEffectsSelfTest tests/ppu_effects_test.cpp)\n"
       <<"target_link_libraries(PpuEffectsSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME PpuEffectsSelfTest COMMAND PpuEffectsSelfTest)\n";
  cmake<<"add_executable(PpuObjLayerSelfTest tests/ppu_obj_layer_test.cpp)\n"
       <<"target_link_libraries(PpuObjLayerSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME PpuObjLayerSelfTest COMMAND PpuObjLayerSelfTest)\n";
  cmake<<"add_executable(PpuRasterSelfTest tests/ppu_raster_test.cpp)\n"
       <<"target_link_libraries(PpuRasterSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME PpuRasterSelfTest COMMAND PpuRasterSelfTest)\n";
  cmake<<"add_executable(PpuBitmapAffineSelfTest tests/ppu_bitmap_affine_test.cpp)\n"
       <<"target_link_libraries(PpuBitmapAffineSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME PpuBitmapAffineSelfTest COMMAND PpuBitmapAffineSelfTest)\n";
  cmake<<"add_executable(PpuFrameSelfTest tests/ppu_frame_test.cpp)\n"
       <<"target_link_libraries(PpuFrameSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME PpuFrameSelfTest COMMAND PpuFrameSelfTest)\n";
  cmake<<"add_executable(VideoStateSelfTest tests/video_state_test.cpp)\n"
       <<"target_link_libraries(VideoStateSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME VideoStateSelfTest COMMAND VideoStateSelfTest)\n";
  cmake<<"add_executable(HardwareTimingSelfTest tests/hardware_timing_test.cpp)\n"
       <<"target_link_libraries(HardwareTimingSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME HardwareTimingSelfTest COMMAND HardwareTimingSelfTest)\n";
  cmake<<"add_executable(IrqExceptionSelfTest tests/irq_exception_test.cpp)\n"
       <<"target_link_libraries(IrqExceptionSelfTest PRIVATE gba_runtime)\n"
       <<"add_test(NAME IrqExceptionSelfTest COMMAND IrqExceptionSelfTest)\n";
  cmake<<"add_executable(RomCopyOriginSelfTest tests/rom_copy_origin_test.cpp)\ntarget_link_libraries(RomCopyOriginSelfTest PRIVATE gba_runtime)\nadd_test(NAME RomCopyOriginSelfTest COMMAND RomCopyOriginSelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  if(relocated)cmake<<"add_executable(RelocatedBootIntegrationSelfTest tests/relocated_boot_integration_test.cpp)\n"
      <<"target_link_libraries(RelocatedBootIntegrationSelfTest PRIVATE gba_runtime)\n"
      <<"add_test(NAME RelocatedBootIntegrationSelfTest COMMAND RelocatedBootIntegrationSelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  if(relocated)cmake<<"add_executable(RelocatedArmSelfTest tests/relocated_arm_test.cpp)\n"
      <<"target_link_libraries(RelocatedArmSelfTest PRIVATE gba_runtime)\n"
      <<"add_test(NAME RelocatedArmSelfTest COMMAND RelocatedArmSelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  if(relocated && relocated->scan_rom_backed_copies)
    cmake<<"add_executable(IwramScanGuardSelfTest tests/iwram_scan_guard_test.cpp)\n"
      <<"target_link_libraries(IwramScanGuardSelfTest PRIVATE gba_runtime)\n"
      <<"add_test(NAME IwramScanGuardSelfTest COMMAND IwramScanGuardSelfTest)\n";
  if(relocated && !relocated->extra_copies.empty())
    cmake<<"add_executable(ExtraArmExecutionSelfTest tests/extra_arm_execution_test.cpp)\n"
      <<"target_link_libraries(ExtraArmExecutionSelfTest PRIVATE gba_runtime)\n"
      <<"add_test(NAME ExtraArmExecutionSelfTest COMMAND ExtraArmExecutionSelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  if(relocated && std::any_of(relocated->extra_copies.begin(),relocated->extra_copies.end(),
      [](const GbaArmCopyRegion& r){return r.overlay;}))
    cmake<<"add_executable(RelocatedOverlaySelfTest tests/relocated_overlay_test.cpp)\n"
      <<"target_link_libraries(RelocatedOverlaySelfTest PRIVATE gba_runtime)\n"
      <<"add_test(NAME RelocatedOverlaySelfTest COMMAND RelocatedOverlaySelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  if(relocated && std::any_of(iwramBlocks.begin(),iwramBlocks.end(),[](const GbaBasicBlock& b){
      return b.start==0x030022A4u&&!b.instructions.empty()&&b.instructions[0].raw==0xE0822008u;}) &&
    std::any_of(iwramBlocks.begin(),iwramBlocks.end(),[](const GbaBasicBlock& b){
      return b.start==0x030022B4u&&!b.instructions.empty()&&b.instructions[0].raw==0xBAFFFFF3u;}))
    cmake<<"add_executable(ArmPatchedOpcodesSelfTest tests/arm_patched_opcodes_test.cpp)\n"
      <<"target_link_libraries(ArmPatchedOpcodesSelfTest PRIVATE gba_runtime)\n"
      <<"add_test(NAME ArmPatchedOpcodesSelfTest COMMAND ArmPatchedOpcodesSelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  if(receiverPattern)
    cmake<<"add_executable(NativeReceiverTraceSelfTest tests/native_receiver_trace_test.cpp)\n"
         <<"target_link_libraries(NativeReceiverTraceSelfTest PRIVATE gba_runtime)\n"
         <<"add_test(NAME NativeReceiverTraceSelfTest COMMAND NativeReceiverTraceSelfTest \"${CMAKE_CURRENT_SOURCE_DIR}/input/"<<cpp_string(rom.path().filename().string())<<"\")\n";
  cmake<<"add_executable(KeyScriptSelfTest tests/key_script_test.cpp)\n"
       <<"add_test(NAME KeyScriptSelfTest COMMAND KeyScriptSelfTest)\n";
  cmake
       <<"if(MSVC)\n target_compile_options(gba_runtime PRIVATE /W4 /permissive-)\n target_compile_options("<<project<<"_Native PRIVATE /W4 /permissive-)\n target_compile_options(RuntimeSelfTest PRIVATE /W4 /permissive-)\n target_compile_options(BootBridgeSelfTest PRIVATE /W4 /permissive-)\nelse()\n target_compile_options(gba_runtime PRIVATE -Wall -Wextra -Wpedantic)\n target_compile_options("<<project<<"_Native PRIVATE -Wall -Wextra -Wpedantic)\n target_compile_options(RuntimeSelfTest PRIVATE -Wall -Wextra -Wpedantic)\n target_compile_options(BootBridgeSelfTest PRIVATE -Wall -Wextra -Wpedantic)\nendif()\n";
  if(!write_file(out_dir/"CMakeLists.txt",cmake.str())){error="Falha escrevendo CMakeLists.txt";return false;}

  const std::string romName=rom.path().filename().string();
  const char* keyReplayHeader=R"KEYREPLAY(#pragma once
#include <cstdint>
#include <fstream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

namespace gba_input {
using Event=std::pair<uint64_t,uint16_t>;
inline bool loadScript(const std::string& path,std::vector<Event>& events,std::string& error){
    std::ifstream stream(path);
    if(!stream){error="Cannot open key script: "+path;return false;}
    std::vector<Event> parsed;
    std::string line;unsigned lineNumber=0;
    while(std::getline(stream,line)){
        ++lineNumber;
        const auto hash=line.find('#');if(hash!=std::string::npos)line.erase(hash);
        std::istringstream fields(line);
        std::string frameToken,maskToken,extra;
        if(!(fields>>frameToken))continue;
        if(frameToken=="GBA_INPUT_V1"){
            if(!parsed.empty()||(fields>>extra)){error="Invalid script header at line "+std::to_string(lineNumber);return false;}
            continue;
        }
        if(!(fields>>maskToken)||(fields>>extra)){
            error="Expected FRAME PRESSED_MASK at line "+std::to_string(lineNumber);return false;
        }
        try{
            size_t usedFrame=0,usedMask=0;
            const auto frame=std::stoull(frameToken,&usedFrame,0);
            const auto mask=std::stoul(maskToken,&usedMask,0);
            if(usedFrame!=frameToken.size()||usedMask!=maskToken.size()||frame<1u||frame>65535u||mask>0x3ffu||
               parsed.size()>=256u||(!parsed.empty()&&frame<=parsed.back().first)){
                error="Invalid/out-of-order key event at line "+std::to_string(lineNumber);return false;
            }
            parsed.emplace_back(frame,uint16_t(mask));
        }catch(const std::exception&){
            error="Invalid key event at line "+std::to_string(lineNumber);return false;
        }
    }
    if(!stream.eof()){error="Error reading key script";return false;}
    if(parsed.empty()){error="Key script contains no events";return false;}
    events=std::move(parsed);
    return true;
}
}
)KEYREPLAY";
  if(!write_file(out_dir/"src/gba_input_replay.hpp",keyReplayHeader)){
    error="Falha escrevendo replay de controles";return false;
  }
  if(!write_file(out_dir/"tests/key_script_test.cpp",R"REPLAYTEST(#include "../src/gba_input_replay.hpp"
#include <cassert>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>
int main(){
    const std::string path="key-script-selftest.txt";
    auto write=[&](const std::string& s){std::ofstream f(path);f<<s;};
    std::vector<gba_input::Event> ev;std::string err;
    write("GBA_INPUT_V1\n# buttons\n200 0x8\n205 0\n900 0x1 # A\n905 0\n");
    assert(gba_input::loadScript(path,ev,err));
    assert(ev.size()==4u&&ev[0].first==200&&ev[0].second==8&&ev[2].first==900&&ev[2].second==1);
    write("200 0x8\n200 0\n");assert(!gba_input::loadScript(path,ev,err));
    write("200 0x400\n");assert(!gba_input::loadScript(path,ev,err));
    write("xyz 0x1\n");assert(!gba_input::loadScript(path,ev,err));
    write("GBA_INPUT_V1\n");assert(!gba_input::loadScript(path,ev,err));
    std::remove(path.c_str());return 0;
}
)REPLAYTEST")){
    error="Falha escrevendo teste de replay";return false;
  }
  std::ostringstream maincpp;
  maincpp << R"MAIN(#include <iostream>
#include <string>
#include <exception>
#include <fstream>
#include "gba_runtime.hpp"
#include "game_entry.hpp"
#include "native_blocks.hpp"
#include "native_trace_file.hpp"
#include "gba_input_replay.hpp"

int main(int argc,char** argv){
    GbaRuntime runtime;
    std::string error;
    const char* romPath=argc>1?argv[1]:"input/)MAIN" << cpp_string(romName) << R"MAIN(";
    if(!runtime.loadRom(romPath,error)){
        std::cerr<<"ROM load failed: "<<error<<'\n';return 2;
    }
    std::cout<<"Generated by Port GBA Builder v2.13.0 + deterministic input script replay\n";
    // The native code was generated against one ROM. Refuse all others.
    uint64_t hash=14695981039346656037ull;
    for(uint8_t byte:runtime.rom()){hash^=byte;hash*=1099511628211ull;}
    if(hash!=)MAIN" << gba_trace_fingerprint(rom) << R"MAIN(ull ||
       runtime.rom().size()!=)MAIN" << rom.bytes().size() << R"MAIN(u){
        std::cerr<<"ROM fingerprint mismatch; refusing generated handlers\n";
        return 4;
    }
    if(argc>=3){
        if(std::string(argv[2])!="--run"||argc<4){
            std::cerr<<"Usage: executable ROM.gba [--run MAX_BLOCKS [--trace path] [--frontier-out path] [--video-evidence path] [--frame-dir directory] [--frame-ids 3,10,20,40,61] [--key-event FRAME:MASK]... [--key-script path]]\n";return 2;
        }
        size_t blocks=0;
        try{
            const auto n=std::stoull(argv[3]);
            if(n==0||n>100000000u||std::to_string(n)!=argv[3])throw std::out_of_range("blocks");
            blocks=static_cast<size_t>(n);
        }catch(const std::exception&){std::cerr<<"MAX_BLOCKS must be 1..100000000\n";return 2;}
        NativeTraceFile trace;
        bool tracing=false;
        std::string frontierFile;
        std::string videoFile;
        std::string frameDir;
        std::string frameList="3,10,20,40,61";
        std::vector<std::pair<uint64_t,uint16_t>> keyEvents;
        std::string keyScriptFile;
        for(int i=4;i<argc;i+=2){
            if(i+1>=argc){std::cerr<<"Missing option argument\n";return 2;}
            const std::string opt=argv[i];
            if(opt=="--trace"&&!tracing){
                if(!trace.open(argv[i+1])){std::cerr<<"Unable to open trace\n";return 2;}
                tracing=true;
            }else if(opt=="--frontier-out"&&frontierFile.empty())frontierFile=argv[i+1];
            else if(opt=="--video-evidence"&&videoFile.empty())videoFile=argv[i+1];
            else if(opt=="--frame-dir"&&frameDir.empty())frameDir=argv[i+1];
            else if(opt=="--frame-ids")frameList=argv[i+1];
            else if(opt=="--key-script"&&keyScriptFile.empty())keyScriptFile=argv[i+1];
            else if(opt=="--key-event"){
                const std::string arg=argv[i+1];const size_t c=arg.find(':');
                try{
                    if(c==std::string::npos)throw std::invalid_argument("separator");
                    const auto f=std::stoull(arg.substr(0,c));
                    size_t used=0;const auto keys=std::stoul(arg.substr(c+1),&used,0);
                    if(used!=arg.size()-c-1||f<1u||f>65535u||keys>1023u||keyEvents.size()>=256u||
                       (!keyEvents.empty()&&f<=keyEvents.back().first))throw std::out_of_range("key event");
                    keyEvents.push_back({f,uint16_t(keys)});
                }catch(const std::exception&){std::cerr<<"--key-event expects increasing FRAME:MASK, e.g. 250:0x8 then 255:0\n";return 2;}
            }
            else{std::cerr<<"Unknown/duplicate option: "<<opt<<'\n';return 2;}
        }
        if(!keyScriptFile.empty()){
            if(!keyEvents.empty()){
                std::cerr<<"Do not combine --key-script and --key-event\n";return 2;
            }
            std::string keyError;
            if(!gba_input::loadScript(keyScriptFile,keyEvents,keyError)){
                std::cerr<<"Invalid key script: "<<keyError<<'\n';return 2;
            }
        }
        runtime.reset(); // boot uses fresh system state; reset clears the observers.
        for(const auto& event:keyEvents)runtime.scheduleKeysAtFrame(event.first,event.second);
        if(!videoFile.empty())runtime.enableVideoCapture(true);
        if(!frameDir.empty()){
            std::vector<uint64_t> wanted;
            std::istringstream nums(frameList);std::string part;
            while(std::getline(nums,part,',')){
                try{
                    const auto n=std::stoull(part);
                    if(n==0||n>2048||std::to_string(n)!=part||wanted.size()>=16u)throw std::out_of_range("frame");
                    wanted.push_back(n);
                }catch(const std::exception&){std::cerr<<"--frame-ids: use comma separated 1..2048, max 16\n";return 2;}
            }
            if(wanted.empty()){std::cerr<<"--frame-ids requires at least one frame\n";return 2;}
            runtime.enableFrameCapture(wanted);
        }
        if(tracing){
            runtime.setMemoryWriteObserver(&NativeTraceFile::captureWrite,&trace);
            set_native_dynamic_call_observer(&NativeTraceFile::capture,&trace);
        }
        const auto result=run_native_blocks(runtime,)MAIN" << hexu(report.entry_target) << R"MAIN(,false,blocks);
        set_native_dynamic_call_observer(nullptr,nullptr);
        runtime.setMemoryWriteObserver(nullptr,nullptr);
        std::cout<<"Actual generated native block execution: "<<result.blocks
                 <<" blocks, PC=0x"<<std::hex<<result.pc<<std::dec
                 <<" mode="<<(result.thumb?"Thumb":"ARM")
                 <<" IWRAM_ARM_blocks="<<result.relocated_arm_blocks
                 <<" rom_fingerprint=0x"<<std::hex<<hash<<std::dec
                 <<" rom_bytes="<<runtime.rom().size()
                 <<" estimated_cycles="<<runtime.clockCycles()
                 <<" vblank_events="<<runtime.vblankEvents()
                 <<" scripted_key_events="<<keyEvents.size()
                 <<" completed_frames="<<runtime.completedFrames()
                 <<" vcount="<<runtime.scanline()
                 <<" pending_irq=0x"<<std::hex<<runtime.pendingIrq()<<std::dec
                 <<" irq_entries="<<runtime.irqEntries()
                 <<" irq_returns="<<runtime.irqReturns()
                 <<" irq_unvectored="<<runtime.irqUnvectored()
                 <<" irq_active="<<(runtime.inBiosIrq()?1u:0u)
                 <<" lr=0x"<<std::hex<<runtime.reg(14)
                 <<" sp=0x"<<runtime.reg(13)
                 <<" cpsr=0x"<<runtime.cpsr()<<std::dec
                 <<" status="<<(result.supported?"budget-reached":"unsupported")<<'\n';
        if(!result.supported){
            std::cerr<<"MISSING_NATIVE_BLOCK pc=0x"<<std::hex<<std::uppercase<<result.pc
                     <<std::dec<<" mode="<<(result.thumb?"THUMB":"ARM")
                     <<" executed_blocks="<<result.blocks<<'\n';
            if((result.pc>=0x02000000u&&result.pc<0x02040000u)||
               (result.pc>=0x03000000u&&result.pc<0x03008000u)){
                const auto origin=runtime.uniqueRomCopyOrigin(result.pc);
                std::cerr<<"RELOCATED_RAM_CODE entry=0x"<<std::hex<<result.pc
                         <<" source_ROM=0x"<<origin<<std::dec
                         <<" (needs relocatable-code native lifting, not ROM CFG seeding)\n";
            }
            if(!frontierFile.empty()){
                std::ofstream miss(frontierFile,std::ios::trunc);
                if(!miss){std::cerr<<"Cannot write frontier file\n";return 3;}
                if((result.pc>=0x02000000u&&result.pc<0x02040000u)||
                   (result.pc>=0x03000000u&&result.pc<0x03008000u)){
                    miss<<")MAIN" << gba_trace_header(rom).replace(0,12,"GBA_RELOCATED_V1") << R"MAIN(\n0x"
                        <<std::hex<<std::uppercase<<result.pc<<" "<<(result.thumb?"THUMB":"ARM")
                        <<" source_ROM=0x"<<runtime.uniqueRomCopyOrigin(result.pc)<<'\n';
                }else{
                    miss<<")MAIN" << gba_trace_header(rom).replace(0,12,"GBA_FRONTIER_V1") << R"MAIN(\n0x"
                        <<std::hex<<std::uppercase<<result.pc<<" "<<(result.thumb?"THUMB":"ARM")<<'\n';
                }
                if(!miss){std::cerr<<"Cannot write frontier file\n";return 3;}
            }
        }
        if(!videoFile.empty()){
            std::ofstream video(videoFile,std::ios::trunc);
            if(!video){std::cerr<<"Cannot write video evidence file\n";return 3;}
            video<<"GBA_VIDEO_V1 rom_fnv=0x"<<std::hex<<hash<<std::dec
                 <<" rom_bytes="<<runtime.rom().size()<<"\n";
            for(const auto& sample:runtime.videoSamples()){
                video<<"frame="<<sample.frame<<" cycles="<<sample.cycles
                     <<" vcount="<<sample.vcount
                     <<" dispcnt=0x"<<std::hex<<sample.dispcnt
                     <<" regs=0x"<<sample.regs_hash
                     <<" vram=0x"<<sample.vram_hash
                     <<" palette=0x"<<sample.palette_hash
                     <<" oam=0x"<<sample.oam_hash<<std::dec
                     <<" vram_changes="<<sample.vram_changes
                     <<" palette_changes="<<sample.palette_changes
                     <<" oam_changes="<<sample.oam_changes
                     <<" video_io_changes="<<sample.video_io_changes
                     <<" dma3="<<sample.dma3_transfers<<"\n";
            }
            if(!video){std::cerr<<"Failed to save video evidence\n";return 3;}
            std::cout<<"VIDEO_EVIDENCE samples="<<runtime.videoSamples().size()
                     <<" output="<<videoFile<<" (state only; no rendered frames)\n";
        }
        if(!frameDir.empty()){
            namespace fs=std::filesystem;
            std::error_code ec;
            fs::create_directories(frameDir,ec);
            if(ec){std::cerr<<"Cannot create frame directory: "<<ec.message()<<'\n';return 3;}
            std::ofstream manifest(fs::path(frameDir)/"manifest.tsv",std::ios::trunc);
            if(!manifest){std::cerr<<"Cannot create framebuffer manifest\n";return 3;}
            manifest<<"GBA_FRAME_V1\trom_fnv=0x"<<std::hex<<hash<<std::dec
                    <<"\trom_bytes="<<runtime.rom().size()<<"\n";
            for(const auto& captured:runtime.frameCaptures()){
                const std::string filename="vblank_"+std::to_string(captured.frame)+".png";
                if(!gba_ppu::writePng(fs::path(frameDir)/filename,captured.image)){
                    std::cerr<<"Unable to write "<<filename<<'\n';return 3;
                }
                manifest<<captured.frame<<'\t'<<captured.image.mode<<"\t0x"<<std::hex
                        <<captured.image.dispcnt<<"\t0x"<<gba_ppu::fingerprint(captured.image)
                        <<std::dec<<'\t'<<captured.image.unsupported_effects
                        <<'\t'<<filename<<"\n";
            }
            if(!manifest){std::cerr<<"Frame manifest write failed\n";return 3;}
            std::cout<<"PPU_FRAME_EXPORT frames="<<runtime.frameCaptures().size()
                     <<" output="<<frameDir<<" (HBlank register/palette/VRAM/OAM sampled; not pixel-accurate hardware reference)\n";
        }
        // Budget reached is NOT equivalent to completing gameplay.
        return result.supported?0:5;
    }
    return gba_generated_entry(runtime);
}
)MAIN";
  write_file(out_dir/"src/main.cpp",maincpp.str());
  std::string winSource=kNativeRomWindowSource;
  auto replaceToken=[&](const std::string& needle,const std::string& value){const auto p=winSource.find(needle);if(p!=std::string::npos)winSource.replace(p,needle.size(),value);};
  replaceToken("__ROM_HASH__",std::to_string(gba_trace_fingerprint(rom)));
  replaceToken("__ENTRY_PC__",std::to_string(report.entry_target));
  replaceToken("__ROM_NAME__",cpp_string(rom.path().filename().string()));
  replaceToken("__EXE_NAME__",project+"_ROM_Window.exe");
  replaceToken("__ROM_SIZE__",std::to_string(rom.bytes().size()));
  write_file(out_dir/"src/rom_window_win32.cpp",winSource);
  std::string winLauncher=R"CMD(@echo off
setlocal
cd /d "%~dp0"
if not exist "build\Release\__EXE_NAME__" if not exist "build\__EXE_NAME__" (
 echo Compile o projeto gerado usando COMPILAR-WINDOWS.cmd.
 pause
 exit /b 1
)
if exist "build\Release\__EXE_NAME__" ("build\Release\__EXE_NAME__") else ("build\__EXE_NAME__")
)CMD";
  const std::string exeToken="__EXE_NAME__",actualExe=project+"_ROM_Window.exe";
  for(size_t at=0;(at=winLauncher.find(exeToken,at))!=std::string::npos;at+=actualExe.size())
      winLauncher.replace(at,exeToken.size(),actualExe);
  write_file(out_dir/"ABRIR-ROM-ORIGINAL.cmd",winLauncher);

  const char* runtime_h=R"CPP(#pragma once
#include "gba_ppu_renderer.hpp"
#include "gba_video_bus.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>
#include <unordered_map>

struct GbaFrameCapture {uint64_t frame=0;gba_ppu::Frame image;};
struct GbaVideoSample {
    uint64_t frame=0,cycles=0;
    uint16_t vcount=0,dispcnt=0;
    uint64_t regs_hash=0,vram_hash=0,palette_hash=0,oam_hash=0;
    uint64_t vram_changes=0,palette_changes=0,oam_changes=0,video_io_changes=0,dma3_transfers=0;
};

class GbaRuntime {
public:
    static constexpr uint32_t ROM_BASE=0x08000000u;
    void reset();
    bool loadRom(const std::filesystem::path& path,std::string& error);
    uint8_t read8(uint32_t address) const;
    uint16_t read16(uint32_t address) const;
    uint32_t read32(uint32_t address) const;
    void write8(uint32_t address,uint8_t value);
    void write16(uint32_t address,uint16_t value);
    void write32(uint32_t address,uint32_t value);
    using MemoryWriteObserver=void(*)(uint32_t alignedAddress,uint32_t newWord,uint32_t serial,void*);
    void setMemoryWriteObserver(MemoryWriteObserver observer,void* context);
    uint32_t lastWriteSerial(uint32_t alignedAddress)const;
    uint32_t uniqueRomCopyOrigin(uint32_t ramAddress,size_t bytes=24u) const;
    uint32_t& reg(size_t index){return regs_.at(index);}
    const uint32_t& reg(size_t index)const{return regs_.at(index);}
    bool flagN()const{return n_;}
    bool flagZ()const{return z_;}
    bool flagC()const{return c_;}
    bool flagV()const{return v_;}
    void setNZ(uint32_t value);
    void setNZC(uint32_t value,bool carry);
    void setNZCV(uint32_t value,bool carry,bool overflow);
    void setAddFlags(uint32_t a,uint32_t b,uint32_t result);
    void setSubFlags(uint32_t a,uint32_t b,uint32_t result);
    bool condition(unsigned code)const;
    uint32_t cpsr()const;
    void writeCpsr(uint32_t value,unsigned fieldMask);
    void registerRamReset(uint32_t flags);
    void swi(uint32_t number);
    // Host-side coarse instruction cost advances an exact LCD/timer event model.
    // Instruction waitstates and interrupt exception entry are not cycle exact.
    void advanceCycles(uint32_t cycles);
    uint64_t clockCycles()const{return clockCycles_;}
    uint64_t completedFrames()const{return completedFrames_;}
    uint64_t vblankEvents()const{return vblankEvents_;}
    void enableVideoCapture(bool enabled){videoCapture_=enabled;videoSamples_.clear();}
    GbaVideoSample currentVideoSample()const;
    const std::vector<GbaVideoSample>& videoSamples()const{return videoSamples_;}
    void enableFrameCapture(const std::vector<uint64_t>& targets){
        frameTargets_=targets;frameCaptures_.clear();
        if(frameTargets_.empty())rasterVram_.clear();
        else rasterVram_.assign(160u*0x18000u,0);
    }
    const std::vector<GbaFrameCapture>& frameCaptures()const{return frameCaptures_;}
    uint16_t scanline()const{return scanline_;}
    uint16_t lineCycles()const{return lineCycles_;}
    uint16_t pendingIrq()const;
    bool irqRequested()const;
    // BIOS IRQ vector at 0x03007FFC is entered in ARM state.
    // Returns false if IRQ is masked or the user vector is not installed.
    bool enterBiosIrq(uint32_t resumePc,bool resumeThumb,uint32_t& handlerPc);
    bool finishBiosIrq(uint32_t& resumePc,bool& resumeThumb);
    bool inBiosIrq()const{return biosIrqActive_;}
    uint32_t spsrIrq()const{return spsrIrq_;}
    uint64_t irqEntries()const{return irqEntries_;}
    uint64_t irqReturns()const{return irqReturns_;}
    uint64_t irqUnvectored()const{return irqUnvectored_;}
    void setKeysPressed(uint16_t pressed);
    void scheduleKeysAtFrame(uint64_t frame,uint16_t pressed);
    size_t scheduledKeyEvents()const{return keyEvents_.size();}
    gba_ppu::Frame renderPreview()const;
    const std::vector<uint8_t>& rom()const{return rom_;}
private:
    std::array<uint32_t,16> regs_{};
    bool n_=false,z_=false,c_=false,v_=false;
    uint32_t cpsrControl_=0x1Fu;
    uint32_t userSp_=0,irqSp_=0,svcSp_=0;
    uint32_t userLr_=0,irqLr_=0,svcLr_=0;
    uint32_t spsrIrq_=0,irqResumePc_=0;
    bool biosIrqActive_=false,irqResumeThumb_=false;
    uint64_t irqEntries_=0,irqReturns_=0,irqUnvectored_=0;
    std::array<uint8_t,0x40000> ewram_{};
    std::array<uint8_t,0x8000> iwram_{};
    std::array<uint8_t,0x400> io_{};
    // Register state at end of the visible portion of each scanline.
    std::array<uint8_t,0x60u*160u> rasterIo_{};
    // Palette DMA/writes during HBlank can change colors between scanlines.
    std::array<uint8_t,0x400u*160u> rasterPalette_{};
    std::vector<uint8_t> rasterVram_; // allocated only when PNG frame capture is enabled
    std::array<uint8_t,0x400u*160u> rasterOam_{};
    std::array<uint8_t,0x400> palette_{};
    std::array<uint8_t,0x18000> vram_{};
    std::array<uint8_t,0x400> oam_{};
    std::array<uint8_t,0x10000> sram_{};
    std::vector<uint8_t> rom_;
    MemoryWriteObserver memoryObserver_=nullptr;
    void* memoryObserverContext_=nullptr;
    uint32_t nextWriteSerial_=0;
    std::unordered_map<uint32_t,uint32_t> lastWriteSerials_;
    uint64_t clockCycles_=0,completedFrames_=0,vblankEvents_=0;
    uint16_t scanline_=0,lineCycles_=0;
    bool videoCapture_=false;
    std::vector<GbaVideoSample> videoSamples_;
    std::vector<uint64_t> frameTargets_;
    std::vector<GbaFrameCapture> frameCaptures_;
    struct KeyFrameEvent {uint64_t frame;uint16_t pressed;};
    std::vector<KeyFrameEvent> keyEvents_;
    size_t nextKeyEvent_=0;
    uint64_t vramChanges_=0,paletteChanges_=0,oamChanges_=0,videoIoChanges_=0,dma3Transfers_=0;
    std::array<uint16_t,4> timerReload_{},timerValue_{},timerControl_{};
    std::array<uint32_t,4> timerPhase_{};
    void requestIrq(uint16_t bit);
    void timerIncrement(unsigned index,uint32_t ticks);
    void advanceTimers(uint32_t cycles);
    void refreshDispstat();
    void recordVideoSample();
    void runDma3(uint32_t controlWord);
    void writeByteCore(uint32_t address,uint8_t value);
    const uint8_t* readPtr(uint32_t address,size_t bytes)const;
    uint8_t* writePtr(uint32_t address,size_t bytes);
    std::vector<uint8_t> decodeLz10(uint32_t source)const;
};
)CPP";
  const char* runtime_cpp=R"CPP(#include "gba_runtime.hpp"
#include <algorithm>
#include <deque>
#include <cmath>
#include <fstream>
#include <iterator>
#include <stdexcept>

namespace {
template<class A> const uint8_t* in_const(const A& a,uint32_t address,uint32_t base,size_t bytes){if(address<base)return nullptr;const uint64_t off=uint64_t(address-base);if(off+bytes>a.size())return nullptr;return a.data()+off;}
template<class A> uint8_t* in_mut(A& a,uint32_t address,uint32_t base,size_t bytes){if(address<base)return nullptr;const uint64_t off=uint64_t(address-base);if(off+bytes>a.size())return nullptr;return a.data()+off;}
}

void GbaRuntime::reset(){regs_.fill(0);n_=z_=c_=v_=false;cpsrControl_=0x1Fu;userSp_=irqSp_=svcSp_=0;userLr_=irqLr_=svcLr_=0;spsrIrq_=irqResumePc_=0;biosIrqActive_=irqResumeThumb_=false;irqEntries_=irqReturns_=irqUnvectored_=0;ewram_.fill(0);iwram_.fill(0);io_.fill(0);rasterIo_.fill(0);rasterPalette_.fill(0);rasterVram_.clear();rasterOam_.fill(0);palette_.fill(0);vram_.fill(0);oam_.fill(0);sram_.fill(0);
 clockCycles_=completedFrames_=vblankEvents_=0;scanline_=lineCycles_=0;
 videoCapture_=false;videoSamples_.clear();frameTargets_.clear();frameCaptures_.clear();keyEvents_.clear();nextKeyEvent_=0;vramChanges_=paletteChanges_=oamChanges_=videoIoChanges_=dma3Transfers_=0;
 timerReload_.fill(0);timerValue_.fill(0);timerControl_.fill(0);timerPhase_.fill(0);
 io_[0x130]=0xFF;io_[0x131]=0x03;refreshDispstat();memoryObserver_=nullptr;memoryObserverContext_=nullptr;
 nextWriteSerial_=0;lastWriteSerials_.clear();}
bool GbaRuntime::loadRom(const std::filesystem::path& path,std::string& error){std::ifstream f(path,std::ios::binary);if(!f){error="Nao foi possivel abrir a ROM copiada para input/.";return false;}rom_=std::vector<uint8_t>(std::istreambuf_iterator<char>(f),{});if(rom_.empty()||rom_.size()>32u*1024u*1024u){error="Tamanho de ROM invalido.";rom_.clear();return false;}return true;}
const uint8_t* GbaRuntime::readPtr(uint32_t a,size_t n)const{
 if(auto p=in_const(ewram_,a,0x02000000u,n))return p;
 if(auto p=in_const(iwram_,a,0x03000000u,n))return p;
 if(auto p=in_const(io_,a,0x04000000u,n))return p;
 if(gba_video_bus::locate(a).region==gba_video_bus::Region::Palette)return in_const(palette_,gba_video_bus::canonical(a),0x05000000u,n);
 if(gba_video_bus::locate(a).region==gba_video_bus::Region::Vram)return in_const(vram_,gba_video_bus::canonical(a),0x06000000u,n);
 if(gba_video_bus::locate(a).region==gba_video_bus::Region::Oam)return in_const(oam_,gba_video_bus::canonical(a),0x07000000u,n);
 if(auto p=in_const(sram_,a,0x0E000000u,n))return p;
 if(a>=0x08000000u&&a<=0x0DFFFFFFu&&!rom_.empty()){const uint32_t off=(a-0x08000000u)&0x01FFFFFFu;if(uint64_t(off)+n<=rom_.size())return rom_.data()+off;}return nullptr;
}
uint8_t* GbaRuntime::writePtr(uint32_t a,size_t n){
 if(auto p=in_mut(ewram_,a,0x02000000u,n))return p;
 if(auto p=in_mut(iwram_,a,0x03000000u,n))return p;
 if(auto p=in_mut(io_,a,0x04000000u,n))return p;
 if(gba_video_bus::locate(a).region==gba_video_bus::Region::Palette)return in_mut(palette_,gba_video_bus::canonical(a),0x05000000u,n);
 if(gba_video_bus::locate(a).region==gba_video_bus::Region::Vram)return in_mut(vram_,gba_video_bus::canonical(a),0x06000000u,n);
 if(gba_video_bus::locate(a).region==gba_video_bus::Region::Oam)return in_mut(oam_,gba_video_bus::canonical(a),0x07000000u,n);
 if(auto p=in_mut(sram_,a,0x0E000000u,n))return p;
 return nullptr;
}
uint8_t GbaRuntime::read8(uint32_t a)const{if(auto p=readPtr(a,1))return *p;return 0;}
uint16_t GbaRuntime::read16(uint32_t a)const{return uint16_t(read8(a))|uint16_t(read8(a+1))<<8;}
uint32_t GbaRuntime::read32(uint32_t a)const{return uint32_t(read16(a))|uint32_t(read16(a+2))<<16;}
uint32_t GbaRuntime::uniqueRomCopyOrigin(uint32_t ramAddress,size_t bytes)const{
 if(bytes<16u||bytes>256u||rom_.size()<bytes)return 0u;
 // Compare the bytes actually present at an executable RAM address with
 // the source ROM, without treating RAM as static CFG code.
 const auto first=readPtr(ramAddress,bytes);
 if(!first)return 0u;
 const auto it=std::search(rom_.begin(),rom_.end(),first,first+bytes);
 if(it==rom_.end())return 0u;
 if(std::search(it+1,rom_.end(),first,first+bytes)!=rom_.end())return 0u;
 return ROM_BASE+uint32_t(std::distance(rom_.begin(),it));
}
void GbaRuntime::setMemoryWriteObserver(MemoryWriteObserver observer,void* context){
 memoryObserver_=observer;memoryObserverContext_=context;lastWriteSerials_.clear();nextWriteSerial_=0;
}
uint32_t GbaRuntime::lastWriteSerial(uint32_t a)const{
 const auto it=lastWriteSerials_.find(a);
 return it==lastWriteSerials_.end()?0u:it->second;
}
void GbaRuntime::write8(uint32_t a,uint8_t v){
 const auto policy=gba_video_bus::bytePolicy(a,io_[0]&7u);
 if(policy==gba_video_bus::BytePolicy::Ignore)return;
 if(policy==gba_video_bus::BytePolicy::DuplicateHalfword){
   const uint32_t aligned=gba_video_bus::canonical(a)&~1u;
   writeByteCore(aligned,v);writeByteCore(aligned+1u,v);
   return;
 }
 writeByteCore(a,v);
}
void GbaRuntime::writeByteCore(uint32_t a,uint8_t v){
 if(a>=0x04000000u&&a<0x04000400u){
   const unsigned off=a-0x04000000u;
   if(off==6u||off==7u||off==0x130u||off==0x131u)return; // hardware read-only
   if(off<0x60u&&io_[off]!=v)++videoIoChanges_;
   if(off==0x202u||off==0x203u){io_[off]=uint8_t(io_[off]&~v);return;} // IF: write-one-to-clear
   if(off==4u){io_[4]=uint8_t((io_[4]&7u)|(v&0x38u));refreshDispstat();return;}
   if(off==5u){io_[5]=v;refreshDispstat();return;}
   if(off>=0x100u&&off<0x110u){
     const unsigned id=(off-0x100u)/4u,sub=(off-0x100u)%4u;
     if(sub<2u){const uint16_t mask=uint16_t(0xFFu<<(sub*8));
       timerReload_[id]=uint16_t((timerReload_[id]&~mask)|(uint16_t(v)<<(sub*8)));
       if(!(timerControl_[id]&0x80u))timerValue_[id]=timerReload_[id];
     }else{
       const uint16_t old=timerControl_[id];
       if(sub==2u){timerControl_[id]=uint16_t(v&0xC7u);
         if(!(old&0x80u)&&(timerControl_[id]&0x80u)){timerValue_[id]=timerReload_[id];timerPhase_[id]=0;}
       }
     }
     io_[0x100u+4u*id]=uint8_t(timerValue_[id]);
     io_[0x101u+4u*id]=uint8_t(timerValue_[id]>>8);
     io_[0x102u+4u*id]=uint8_t(timerControl_[id]);io_[0x103u+4u*id]=0;
     return;
   }
 }
 if(auto p=writePtr(a,1)){
  if(*p!=v){
   const auto region=gba_video_bus::locate(a).region;
   if(region==gba_video_bus::Region::Palette)++paletteChanges_;
   if(region==gba_video_bus::Region::Vram)++vramChanges_;
   if(region==gba_video_bus::Region::Oam)++oamChanges_;
  }
  *p=v;
  if(a==0x040000DFu&&(v&0x80u)){
    const uint32_t ctl=read32(0x040000DCu);
    if(((ctl>>28)&3u)==0u)runDma3(ctl);
  }
  if(memoryObserver_&&((a>=0x02000000u&&a<0x02040000u)||
                      (a>=0x03000000u&&a<0x03008000u))){
   const uint32_t aligned=a&~3u;
   if(nextWriteSerial_==0xFFFFFFFFu){
    // Sequence overflow invalidates all old bindings. Avoid silently
    // recycling identifiers within a trace; detach collection instead.
    memoryObserver_=nullptr;lastWriteSerials_.clear();return;
   }
   const uint32_t serial=++nextWriteSerial_;
   lastWriteSerials_[aligned]=serial;
   memoryObserver_(aligned,read32(aligned),serial,memoryObserverContext_);
  }
 }
}
void GbaRuntime::write16(uint32_t a,uint16_t v){writeByteCore(a,uint8_t(v));writeByteCore(a+1,uint8_t(v>>8));}
void GbaRuntime::write32(uint32_t a,uint32_t v){write16(a,uint16_t(v));write16(a+2,uint16_t(v>>16));}
void GbaRuntime::setNZ(uint32_t value){n_=(value>>31)!=0;z_=value==0;}
void GbaRuntime::setNZC(uint32_t value,bool carry){setNZ(value);c_=carry;}
void GbaRuntime::setNZCV(uint32_t value,bool carry,bool overflow){setNZ(value);c_=carry;v_=overflow;}
void GbaRuntime::setAddFlags(uint32_t a,uint32_t b,uint32_t result){const uint64_t wide=uint64_t(a)+uint64_t(b);const bool ov=((~(a^b)&(a^result))>>31)!=0;setNZCV(result,(wide>>32)!=0,ov);}
void GbaRuntime::setSubFlags(uint32_t a,uint32_t b,uint32_t result){const bool ov=(((a^b)&(a^result))>>31)!=0;setNZCV(result,a>=b,ov);}
bool GbaRuntime::condition(unsigned c)const{switch(c&15u){case 0:return z_;case 1:return !z_;case 2:return c_;case 3:return !c_;case 4:return n_;case 5:return !n_;case 6:return v_;case 7:return !v_;case 8:return c_&&!z_;case 9:return !c_||z_;case 10:return n_==v_;case 11:return n_!=v_;case 12:return !z_&&(n_==v_);case 13:return z_||(n_!=v_);case 14:return true;default:return false;}}
uint32_t GbaRuntime::cpsr()const{return (cpsrControl_&0x0FFFFFFFu)|(n_?0x80000000u:0u)|(z_?0x40000000u:0u)|(c_?0x20000000u:0u)|(v_?0x10000000u:0u);}
void GbaRuntime::writeCpsr(uint32_t value,unsigned fields){
 if(fields&1u){
   const unsigned oldMode=cpsrControl_&0x1Fu;
   const unsigned newMode=value&0x1Fu;
   if(oldMode!=newMode){
     if(oldMode==0x12u){irqSp_=regs_[13];irqLr_=regs_[14];}
     else if(oldMode==0x13u){svcSp_=regs_[13];svcLr_=regs_[14];}
     else {userSp_=regs_[13];userLr_=regs_[14];}
     if(newMode==0x12u){regs_[13]=irqSp_;regs_[14]=irqLr_;}
     else if(newMode==0x13u){regs_[13]=svcSp_;regs_[14]=svcLr_;}
     else {regs_[13]=userSp_;regs_[14]=userLr_;}
   }
   cpsrControl_=(cpsrControl_&~0xFFu)|(value&0xFFu);
 }
 if(fields&2u)cpsrControl_=(cpsrControl_&~0xFF00u)|(value&0xFF00u);
 if(fields&4u)cpsrControl_=(cpsrControl_&~0x00FF0000u)|(value&0x00FF0000u);
 if(fields&8u){n_=(value&0x80000000u)!=0;z_=(value&0x40000000u)!=0;c_=(value&0x20000000u)!=0;v_=(value&0x10000000u)!=0;}
}
void GbaRuntime::registerRamReset(uint32_t f){if(f&1u)ewram_.fill(0);if(f&2u)iwram_.fill(0);if(f&4u){for(uint8_t b:palette_)if(b)++paletteChanges_;palette_.fill(0);}
 if(f&8u){for(uint8_t b:vram_)if(b)++vramChanges_;vram_.fill(0);}
 if(f&0x10u){for(uint8_t b:oam_)if(b)++oamChanges_;oam_.fill(0);}
 if(f&0xE0u){for(size_t i=0x60;i<io_.size();++i)io_[i]=0;timerReload_.fill(0);timerValue_.fill(0);timerControl_.fill(0);timerPhase_.fill(0);
 io_[0x130]=0xFF;io_[0x131]=0x03;refreshDispstat();}}
void GbaRuntime::runDma3(uint32_t ctl){
 if(!(ctl&0x80000000u))return;
 ++dma3Transfers_;
 const unsigned start=(ctl>>28)&3u;uint32_t src=read32(0x040000D4u),dst=read32(0x040000D8u);
 size_t count=ctl&0xFFFFu;if(!count)count=0x10000u;
 const bool word=(ctl&(1u<<26))!=0;const size_t step=word?4u:2u;
 const unsigned dstMode=(ctl>>21)&3u,srcMode=(ctl>>23)&3u;
 const uint32_t initialDst=dst;
 for(size_t i=0;i<count;++i){const uint32_t val=word?read32(src):read16(src);
   if(word)write32(dst,val);else write16(dst,uint16_t(val));
   if(srcMode==0)src+=uint32_t(step);else if(srcMode==1)src-=uint32_t(step);
   if(dstMode==0||dstMode==3)dst+=uint32_t(step);else if(dstMode==1)dst-=uint32_t(step);
 }
 if(dstMode==3u)dst=initialDst;
 // DMA internal address registers advance for subsequent repeat requests.
 for(unsigned i=0;i<4;++i){io_[0xD4u+i]=uint8_t(src>>(8u*i));io_[0xD8u+i]=uint8_t(dst>>(8u*i));}
 if(ctl&(1u<<30))requestIrq(uint16_t(1u<<11));
 const bool repeat=(ctl&(1u<<25))!=0 && start!=0u;
 const uint32_t finalCtl=repeat?ctl:(ctl&~0x80000000u);
 for(unsigned i=0;i<4;++i)io_[0xDCu+i]=uint8_t(finalCtl>>(8u*i));
}
void GbaRuntime::requestIrq(uint16_t bit){
 const uint16_t flags=uint16_t(io_[0x202])|(uint16_t(io_[0x203])<<8);
 const uint16_t raised=uint16_t(flags|bit);
 io_[0x202]=uint8_t(raised);io_[0x203]=uint8_t(raised>>8);
}
uint16_t GbaRuntime::pendingIrq()const{
 const uint16_t enabled=uint16_t(read16(0x04000200u));
 return uint16_t(enabled&read16(0x04000202u));
}
bool GbaRuntime::irqRequested()const{
 return (read16(0x04000208u)&1u)!=0 && pendingIrq()!=0u && !(cpsrControl_&0x80u);
}
// Host implements only the documented BIOS IRQ prologue/epilogue, not BIOS
// memory outside the GBA ROM. The user ISR still executes as native ARM.
bool GbaRuntime::enterBiosIrq(uint32_t resumePc,bool resumeThumb,uint32_t& handlerPc){
 if(biosIrqActive_||!irqRequested())return false;
 const uint32_t vector=read32(0x03007FFCu);
 if(!vector || (vector&3u)!=0u){++irqUnvectored_;return false;}
 spsrIrq_=cpsr()|(resumeThumb?0x20u:0u);
 spsrIrq_=resumeThumb?(spsrIrq_|0x20u):(spsrIrq_&~0x20u);
 irqResumePc_=resumePc;irqResumeThumb_=resumeThumb;
 // ARM7TDMI IRQ: IRQ mode, ARM state, I bit set, LR_irq=PC_next+4.
 writeCpsr((spsrIrq_&~0x3Fu)|0x12u|0x80u,1u);
 regs_[14]=resumePc+4u;
 // BIOS 0x128: stmfd sp!,{r0-r3,r12,lr} in the banked IRQ stack.
 const uint32_t newSp=regs_[13]-24u;
 for(unsigned i=0;i<4u;++i)write32(newSp+i*4u,regs_[i]);
 write32(newSp+16u,regs_[12]);write32(newSp+20u,regs_[14]);
 regs_[13]=newSp;
 regs_[0]=0x04000000u;
 regs_[14]=0x00000138u; // BIOS resumes at 0x138 after BX LR.
 biosIrqActive_=true;++irqEntries_;
 handlerPc=vector;
 return true;
}
bool GbaRuntime::finishBiosIrq(uint32_t& resumePc,bool& resumeThumb){
 if(!biosIrqActive_ || (cpsrControl_&0x1Fu)!=0x12u)return false;
 const uint32_t sp=regs_[13];
 for(unsigned i=0;i<4u;++i)regs_[i]=read32(sp+i*4u);
 regs_[12]=read32(sp+16u);
 regs_[14]=read32(sp+20u);
 regs_[13]=sp+24u;
 // BIOS 0x13C: SUBS PC, LR_irq, #4 copies SPSR_irq back to CPSR.
 resumePc=regs_[14]-4u;resumeThumb=(spsrIrq_&0x20u)!=0u;
 if(resumePc!=irqResumePc_ || resumeThumb!=irqResumeThumb_)return false;
 writeCpsr(spsrIrq_,0xFu);
 biosIrqActive_=false;++irqReturns_;
 return true;
}
void GbaRuntime::setKeysPressed(uint16_t pressed){
 const uint16_t value=uint16_t(~pressed)&0x03FFu;
 io_[0x130]=uint8_t(value);io_[0x131]=uint8_t(value>>8);
}
void GbaRuntime::scheduleKeysAtFrame(uint64_t frame,uint16_t pressed){
 if(!frame||frame>65535u||pressed>0x03FFu||keyEvents_.size()>=256u)
     throw std::invalid_argument("GBA key event out of range");
 if(!keyEvents_.empty()&&frame<=keyEvents_.back().frame)
     throw std::invalid_argument("GBA key events must have strictly increasing frames");
 keyEvents_.push_back({frame,pressed});
}
gba_ppu::Frame GbaRuntime::renderPreview()const{
 const bool haveVisibleRaster=vblankEvents_>0;
 return gba_ppu::render(io_.data(),palette_.data(),vram_.data(),oam_.data(),
                        haveVisibleRaster?rasterIo_.data():nullptr,
                        haveVisibleRaster?rasterPalette_.data():nullptr,nullptr,
                        haveVisibleRaster?rasterOam_.data():nullptr);
}
namespace {
uint64_t fnvVideo(const uint8_t* begin,size_t count){
 uint64_t h=14695981039346656037ull;
 for(size_t i=0;i<count;++i){h^=begin[i];h*=1099511628211ull;}
 return h;
}
}
GbaVideoSample GbaRuntime::currentVideoSample()const{
 GbaVideoSample s;
 s.frame=vblankEvents_;s.cycles=clockCycles_;s.vcount=scanline_;
 s.dispcnt=uint16_t(io_[0])|uint16_t(io_[1])<<8;
 // Register evidence includes all LCD-affecting IO from DISPCNT through WIN/BLD.
 s.regs_hash=fnvVideo(io_.data(),0x60u);
 s.vram_hash=fnvVideo(vram_.data(),vram_.size());
 s.palette_hash=fnvVideo(palette_.data(),palette_.size());
 s.oam_hash=fnvVideo(oam_.data(),oam_.size());
 s.vram_changes=vramChanges_;s.palette_changes=paletteChanges_;
 s.oam_changes=oamChanges_;s.video_io_changes=videoIoChanges_;
 s.dma3_transfers=dma3Transfers_;
 return s;
}
void GbaRuntime::recordVideoSample(){
 if(videoCapture_&&videoSamples_.size()<2048u)videoSamples_.push_back(currentVideoSample());
 if(frameCaptures_.size()<16u&&std::find(frameTargets_.begin(),frameTargets_.end(),vblankEvents_)!=frameTargets_.end()){
     GbaFrameCapture c;c.frame=vblankEvents_;
     c.image=gba_ppu::render(io_.data(),palette_.data(),vram_.data(),oam_.data(),
                             rasterIo_.data(),rasterPalette_.data(),
                             rasterVram_.empty()?nullptr:rasterVram_.data(),
                             rasterOam_.data());
     frameCaptures_.push_back(std::move(c));
 }
}
void GbaRuntime::refreshDispstat(){
 const bool vblank=scanline_>=160u && scanline_<227u;
 const bool hblank=lineCycles_>=1006u;
 const bool match=scanline_==io_[5];
 io_[4]=uint8_t((io_[4]&0x38u)|(vblank?1u:0u)|(hblank?2u:0u)|(match?4u:0u));
 io_[6]=uint8_t(scanline_);io_[7]=0u;
}
void GbaRuntime::timerIncrement(unsigned id,uint32_t ticks){
 if(!ticks||id>=4u||!(timerControl_[id]&0x80u))return;
 uint32_t value=timerValue_[id];
 while(ticks){
   const uint32_t toOverflow=65536u-value;
   if(ticks<toOverflow){value+=ticks;break;}
   ticks-=toOverflow;value=timerReload_[id];
   if(timerControl_[id]&0x40u)requestIrq(uint16_t(1u<<(3u+id)));
   if(id<3u&&(timerControl_[id+1]&0x84u)==0x84u)timerIncrement(id+1u,1u);
 }
 timerValue_[id]=uint16_t(value);
 const unsigned off=0x100u+4u*id;
 io_[off]=uint8_t(value);io_[off+1u]=uint8_t(value>>8);
}
void GbaRuntime::advanceTimers(uint32_t cycles){
 static const uint32_t prescalers[4]={1u,64u,256u,1024u};
 for(unsigned id=0;id<4u;++id){
   if(!(timerControl_[id]&0x80u)||(id>0u&&(timerControl_[id]&4u)))continue;
   const uint32_t rate=prescalers[timerControl_[id]&3u];
   const uint32_t combined=timerPhase_[id]+cycles;
   timerPhase_[id]=combined%rate;
   timerIncrement(id,combined/rate);
 }
}
void GbaRuntime::advanceCycles(uint32_t cycles){
 // LCD event boundaries are accurate; block->cycle cost is approximate.
 while(cycles){
   const uint32_t toEdge=lineCycles_<1006u?1006u-lineCycles_:1232u-lineCycles_;
   const uint32_t step=std::min(cycles,toEdge);
   advanceTimers(step);clockCycles_+=step;lineCycles_=uint16_t(lineCycles_+step);cycles-=step;
   if(lineCycles_==1006u){
     refreshDispstat();
     if(scanline_<160u){
       // HBlank boundary snapshot, before any HBlank DMA modifies registers.
       std::copy_n(io_.data(),0x60u,rasterIo_.data()+size_t(scanline_)*0x60u);
       std::copy_n(palette_.data(),0x400u,rasterPalette_.data()+size_t(scanline_)*0x400u);
       if(!rasterVram_.empty()){
           std::copy_n(vram_.data(),0x18000u,rasterVram_.data()+size_t(scanline_)*0x18000u);
           std::copy_n(oam_.data(),0x400u,rasterOam_.data()+size_t(scanline_)*0x400u);
       }
       if(io_[4]&0x10u)requestIrq(2u);
       const uint32_t ctl=read32(0x040000DCu);
       if((ctl&0x80000000u)&&((ctl>>28)&3u)==2u)runDma3(ctl);
     }
   }else if(lineCycles_==1232u){
     lineCycles_=0;scanline_=uint16_t((scanline_+1u)%228u);
     if(scanline_==0u)++completedFrames_;
     refreshDispstat();
     if(scanline_==160u){++vblankEvents_;
       while(nextKeyEvent_<keyEvents_.size()&&keyEvents_[nextKeyEvent_].frame<=vblankEvents_){
           setKeysPressed(keyEvents_[nextKeyEvent_].pressed);++nextKeyEvent_;
       }
       if(io_[4]&0x08u)requestIrq(1u);
       const uint32_t ctl=read32(0x040000DCu);
       if((ctl&0x80000000u)&&((ctl>>28)&3u)==1u)runDma3(ctl);
       recordVideoSample();
     }
     if((io_[4]&0x20u)&&(io_[4]&4u))requestIrq(4u);
   }
 }
}
std::vector<uint8_t> GbaRuntime::decodeLz10(uint32_t source)const{if(read8(source)!=0x10)throw std::runtime_error("SWI LZ10 header");size_t size=size_t(read8(source+1))|(size_t(read8(source+2))<<8)|(size_t(read8(source+3))<<16);if(!size||size>16u*1024u*1024u)throw std::runtime_error("SWI LZ10 size");source+=4;std::vector<uint8_t> out;out.reserve(size);while(out.size()<size){uint8_t flags=read8(source++);for(int bit=7;bit>=0&&out.size()<size;--bit){if(flags&(1u<<bit)){uint8_t x=read8(source++),y=read8(source++);size_t n=(x>>4)+3u,dist=(size_t(x&15)<<8)+y+1u;if(dist>out.size())throw std::runtime_error("SWI LZ10 distance");for(size_t i=0;i<n&&out.size()<size;++i)out.push_back(out[out.size()-dist]);}else out.push_back(read8(source++));}}return out;}
void GbaRuntime::swi(uint32_t n){
 switch(n){
 case 0x01:registerRamReset(regs_[0]);break;
 case 0x06:{int32_t den=int32_t(regs_[1]);int32_t num=int32_t(regs_[0]);if(!den){regs_[0]=regs_[1]=regs_[3]=0;break;}int32_t q=num/den,r=num%den;regs_[0]=uint32_t(q);regs_[1]=uint32_t(r);regs_[3]=uint32_t(q<0?-q:q);break;}
 case 0x08:regs_[0]=uint32_t(std::sqrt(double(regs_[0])));break;
 case 0x0B:{uint32_t src=regs_[0],dst=regs_[1],ctl=regs_[2];size_t count=ctl&0x1FFFFFu;bool word=ctl&(1u<<26),fill=ctl&(1u<<24);size_t step=word?4u:2u;uint32_t first=word?read32(src):read16(src);for(size_t i=0;i<count;++i){uint32_t v=fill?first:(word?read32(src+uint32_t(i*step)):read16(src+uint32_t(i*step)));if(word)write32(dst+uint32_t(i*step),v);else write16(dst+uint32_t(i*step),uint16_t(v));}break;}
 case 0x0C:{uint32_t src=regs_[0],dst=regs_[1],ctl=regs_[2];size_t count=ctl&0x1FFFFFu;bool fill=ctl&(1u<<24);uint32_t first=read32(src);for(size_t i=0;i<count;++i){uint32_t v=fill?first:read32(src+uint32_t(i*4));write32(dst+uint32_t(i*4),v);}break;}
 case 0x11:case 0x12:{auto out=decodeLz10(regs_[0]);
   if(n==0x12u){ // BIOS LZ77UnCompVram emits aligned halfwords, not STRB.
     for(size_t i=0;i<out.size();i+=2u){const uint16_t value=uint16_t(out[i])|uint16_t(i+1u<out.size()?out[i+1u]:0u)<<8;
       write16(regs_[1]+uint32_t(i),value);}
   }else for(size_t i=0;i<out.size();++i)write8(regs_[1]+uint32_t(i),out[i]);
   break;}
 default:break;
 }
}
)CPP";
  write_file(out_dir/"runtime/gba_ppu_renderer.hpp",kGbaPpuRendererHeader);
  write_file(out_dir/"runtime/gba_video_bus.hpp",kGbaVideoBusHeader);
  write_file(out_dir/"runtime/gba_runtime.hpp",runtime_h);write_file(out_dir/"runtime/gba_runtime.cpp",runtime_cpp);

  const char* thumb_h=R"CPP(#pragma once
#include <cstdint>
class GbaRuntime;
namespace ThumbOps {
void shiftImm(GbaRuntime&,unsigned op,unsigned rd,unsigned rs,unsigned imm);
void addSub(GbaRuntime&,bool sub,bool immediate,unsigned rd,unsigned rs,unsigned operand);
void immOp(GbaRuntime&,unsigned op,unsigned rd,uint32_t imm);
void alu(GbaRuntime&,unsigned op,unsigned rd,unsigned rs);
void highOp(GbaRuntime&,unsigned op,unsigned rd,unsigned rs,uint32_t instructionPc);
void loadStoreReg(GbaRuntime&,bool load,bool byte,unsigned rd,unsigned rb,unsigned ro);
void loadStoreSign(GbaRuntime&,unsigned hs,unsigned rd,unsigned rb,unsigned ro);
void loadStoreImm(GbaRuntime&,bool load,bool byte,unsigned rd,unsigned rb,unsigned imm5);
void loadStoreHalf(GbaRuntime&,bool load,unsigned rd,unsigned rb,unsigned imm5);
void spRelative(GbaRuntime&,bool load,unsigned rd,unsigned imm8);
void loadAddress(GbaRuntime&,bool sp,unsigned rd,unsigned imm8,uint32_t instructionAddress);
void addSp(GbaRuntime&,bool sub,unsigned imm7);
void push(GbaRuntime&,uint8_t list,bool lr);
uint32_t pop(GbaRuntime&,uint8_t list,bool pc);
void multiple(GbaRuntime&,bool load,unsigned rb,uint8_t list);
}
)CPP";
  const char* thumb_cpp=R"CPP(#include "thumb_ops.hpp"
#include "gba_runtime.hpp"
#include <cstdint>

namespace {
uint32_t ror(uint32_t v,unsigned s){s&=31u;return s?((v>>s)|(v<<(32u-s))):v;}
uint32_t loadWord(GbaRuntime& r,uint32_t a){const uint32_t v=r.read32(a&~3u);return ror(v,(a&3u)*8u);}
void storeWord(GbaRuntime& r,uint32_t a,uint32_t v){r.write32(a&~3u,v);}
unsigned bitCount(uint8_t v){unsigned n=0;for(unsigned i=0;i<8;++i)n+=(v>>i)&1u;return n;}
uint32_t shiftReg(GbaRuntime& r,unsigned op,uint32_t value,unsigned amount,bool updateCarry){
 amount&=0xFFu;bool carry=r.flagC();uint32_t out=value;
 if(op==0){if(amount==0)return value;if(amount<32){carry=((value>>(32u-amount))&1u)!=0;out=value<<amount;}else if(amount==32){carry=(value&1u)!=0;out=0;}else{carry=false;out=0;}}
 else if(op==1){if(amount==0)return value;if(amount<32){carry=((value>>(amount-1u))&1u)!=0;out=value>>amount;}else if(amount==32){carry=((value>>31)&1u)!=0;out=0;}else{carry=false;out=0;}}
 else if(op==2){if(amount==0)return value;if(amount<32){carry=((value>>(amount-1u))&1u)!=0;out=uint32_t(int32_t(value)>>amount);}else{carry=((value>>31)&1u)!=0;out=(value&0x80000000u)?0xFFFFFFFFu:0;}}
 else{if(amount==0)return value;const unsigned rot=amount&31u;if(rot==0){carry=((value>>31)&1u)!=0;out=value;}else{carry=((value>>(rot-1u))&1u)!=0;out=ror(value,rot);}}
 if(updateCarry){r.setNZC(out,carry);}return out;
}
}

namespace ThumbOps {
void shiftImm(GbaRuntime& r,unsigned op,unsigned rd,unsigned rs,unsigned imm){const uint32_t v=r.reg(rs);bool c=r.flagC();uint32_t out=v;if(op==0){if(imm){c=((v>>(32u-imm))&1u)!=0;out=v<<imm;}}else if(op==1){if(!imm){c=((v>>31)&1u)!=0;out=0;}else{c=((v>>(imm-1u))&1u)!=0;out=v>>imm;}}else{if(!imm){c=((v>>31)&1u)!=0;out=(v&0x80000000u)?0xFFFFFFFFu:0;}else{c=((v>>(imm-1u))&1u)!=0;out=uint32_t(int32_t(v)>>imm);}}r.reg(rd)=out;r.setNZC(out,c);}
void addSub(GbaRuntime& r,bool sub,bool immediate,unsigned rd,unsigned rs,unsigned operand){const uint32_t a=r.reg(rs),b=immediate?operand:r.reg(operand);const uint32_t out=sub?a-b:a+b;r.reg(rd)=out;if(sub)r.setSubFlags(a,b,out);else r.setAddFlags(a,b,out);}
void immOp(GbaRuntime& r,unsigned op,unsigned rd,uint32_t imm){const uint32_t a=r.reg(rd);if(op==0){r.reg(rd)=imm;r.setNZ(imm);}else if(op==1){const uint32_t out=a-imm;r.setSubFlags(a,imm,out);}else if(op==2){const uint32_t out=a+imm;r.reg(rd)=out;r.setAddFlags(a,imm,out);}else{const uint32_t out=a-imm;r.reg(rd)=out;r.setSubFlags(a,imm,out);}}
void alu(GbaRuntime& r,unsigned op,unsigned rd,unsigned rs){const uint32_t a=r.reg(rd),b=r.reg(rs);uint32_t out=0;switch(op){case 0:out=a&b;r.reg(rd)=out;r.setNZ(out);break;case 1:out=a^b;r.reg(rd)=out;r.setNZ(out);break;case 2:out=shiftReg(r,0,a,b,true);r.reg(rd)=out;break;case 3:out=shiftReg(r,1,a,b,true);r.reg(rd)=out;break;case 4:out=shiftReg(r,2,a,b,true);r.reg(rd)=out;break;case 5:{const uint32_t c=r.flagC()?1u:0u;out=a+b+c;const uint64_t wide=uint64_t(a)+b+c;const uint32_t rhs=b+c;const bool ov=((~(a^rhs)&(a^out))>>31)!=0;r.reg(rd)=out;r.setNZCV(out,(wide>>32)!=0,ov);break;}case 6:{const uint32_t borrow=r.flagC()?0u:1u;const uint64_t sub=uint64_t(b)+borrow;out=a-uint32_t(sub);const bool c=uint64_t(a)>=sub;const bool ov=(((a^uint32_t(sub))&(a^out))>>31)!=0;r.reg(rd)=out;r.setNZCV(out,c,ov);break;}case 7:out=shiftReg(r,3,a,b,true);r.reg(rd)=out;break;case 8:r.setNZ(a&b);break;case 9:out=0u-b;r.reg(rd)=out;r.setSubFlags(0,b,out);break;case 10:out=a-b;r.setSubFlags(a,b,out);break;case 11:out=a+b;r.setAddFlags(a,b,out);break;case 12:out=a|b;r.reg(rd)=out;r.setNZ(out);break;case 13:out=a*b;r.reg(rd)=out;r.setNZ(out);break;case 14:out=a&~b;r.reg(rd)=out;r.setNZ(out);break;case 15:out=~b;r.reg(rd)=out;r.setNZ(out);break;}}
// Thumb register-high operations read r15 as the current instruction address plus 4.
// The stored runtime r15 is not a pipeline PC and must never be used here.
void highOp(GbaRuntime& r,unsigned op,unsigned rd,unsigned rs,uint32_t instructionPc){const uint32_t a=rd==15u?instructionPc+4u:r.reg(rd),b=rs==15u?instructionPc+4u:r.reg(rs);if(op==0)r.reg(rd)=a+b;else if(op==1){const uint32_t out=a-b;r.setSubFlags(a,b,out);}else if(op==2)r.reg(rd)=b;}
void loadStoreReg(GbaRuntime& r,bool load,bool byte,unsigned rd,unsigned rb,unsigned ro){const uint32_t a=r.reg(rb)+r.reg(ro);if(load)r.reg(rd)=byte?r.read8(a):loadWord(r,a);else if(byte)r.write8(a,uint8_t(r.reg(rd)));else storeWord(r,a,r.reg(rd));}
void loadStoreSign(GbaRuntime& r,unsigned hs,unsigned rd,unsigned rb,unsigned ro){const uint32_t a=r.reg(rb)+r.reg(ro);if(hs==0)r.write16(a&~1u,uint16_t(r.reg(rd)));else if(hs==1)r.reg(rd)=uint32_t(int32_t(int8_t(r.read8(a))));else if(hs==2)r.reg(rd)=r.read16(a&~1u);else r.reg(rd)=(a&1u)?uint32_t(int32_t(int8_t(r.read8(a)))):uint32_t(int32_t(int16_t(r.read16(a))));}
void loadStoreImm(GbaRuntime& r,bool load,bool byte,unsigned rd,unsigned rb,unsigned imm5){const uint32_t a=r.reg(rb)+(byte?imm5:imm5*4u);if(load)r.reg(rd)=byte?r.read8(a):loadWord(r,a);else if(byte)r.write8(a,uint8_t(r.reg(rd)));else storeWord(r,a,r.reg(rd));}
void loadStoreHalf(GbaRuntime& r,bool load,unsigned rd,unsigned rb,unsigned imm5){const uint32_t a=r.reg(rb)+imm5*2u;if(load)r.reg(rd)=r.read16(a&~1u);else r.write16(a&~1u,uint16_t(r.reg(rd)));}
void spRelative(GbaRuntime& r,bool load,unsigned rd,unsigned imm8){const uint32_t a=r.reg(13)+imm8*4u;if(load)r.reg(rd)=loadWord(r,a);else storeWord(r,a,r.reg(rd));}
void loadAddress(GbaRuntime& r,bool sp,unsigned rd,unsigned imm8,uint32_t pc){r.reg(rd)=(sp?r.reg(13):((pc+4u)&~3u))+imm8*4u;}
void addSp(GbaRuntime& r,bool sub,unsigned imm7){const uint32_t d=imm7*4u;r.reg(13)=sub?r.reg(13)-d:r.reg(13)+d;}
void push(GbaRuntime& r,uint8_t list,bool lr){const unsigned count=bitCount(list)+(lr?1u:0u);uint32_t sp=r.reg(13)-count*4u,cur=sp;for(unsigned i=0;i<8;++i)if(list&(1u<<i)){r.write32(cur,r.reg(i));cur+=4;}if(lr)r.write32(cur,r.reg(14));r.reg(13)=sp;}
uint32_t pop(GbaRuntime& r,uint8_t list,bool pc){uint32_t cur=r.reg(13);for(unsigned i=0;i<8;++i)if(list&(1u<<i)){r.reg(i)=r.read32(cur);cur+=4;}uint32_t target=0;if(pc){target=r.read32(cur);cur+=4;}r.reg(13)=cur;return target;}
void multiple(GbaRuntime& r,bool load,unsigned rb,uint8_t list){uint32_t a=r.reg(rb);for(unsigned i=0;i<8;++i)if(list&(1u<<i)){if(load)r.reg(i)=r.read32(a);else r.write32(a,r.reg(i));a+=4;}r.reg(rb)=a;}
}
)CPP";
  write_file(out_dir/"runtime/thumb_ops.hpp",thumb_h);write_file(out_dir/"runtime/thumb_ops.cpp",thumb_cpp);

  const char* arm_h=R"CPP(#pragma once
#include <cstdint>
class GbaRuntime;
namespace ArmOps {
void msr(GbaRuntime&,unsigned fields,unsigned rm);
void dataProc(GbaRuntime&,unsigned opcode,bool setFlags,unsigned rn,unsigned rd,bool immediate,unsigned imm8,unsigned rotate,unsigned rm,unsigned shiftType,unsigned shiftImm,uint32_t instructionAddress);
void singleTransfer(GbaRuntime&,bool load,bool byte,bool pre,bool up,bool writeback,unsigned rn,unsigned rd,unsigned imm12,bool registerOffset,uint32_t instructionAddress);
void blockTransfer(GbaRuntime&,bool load,bool pre,bool up,bool writeback,unsigned rn,unsigned registerList,uint32_t instructionAddress);
void multiply(GbaRuntime&,bool accumulate,bool setFlags,unsigned rd,unsigned rn,unsigned rs,unsigned rm);
void halfTransfer(GbaRuntime&,bool load,unsigned kind,bool pre,bool up,bool writeback,bool immediate,unsigned rn,unsigned rd,unsigned offset,uint32_t instructionAddress);
}
)CPP";
  const char* arm_cpp=R"CPP(#include "arm_ops.hpp"
#include "gba_runtime.hpp"
#include <cstdint>

namespace {
uint32_t ror(uint32_t v,unsigned s){s&=31u;return s?((v>>s)|(v<<(32u-s))):v;}
uint32_t regValue(GbaRuntime& r,unsigned reg,uint32_t pc){return reg==15u?pc+8u:r.reg(reg);}
uint32_t shifted(GbaRuntime& r,uint32_t value,unsigned type,unsigned amount,bool& carry){if(type==0){if(amount){carry=((value>>(32u-amount))&1u)!=0;return value<<amount;}return value;}if(type==1){if(!amount){carry=((value>>31)&1u)!=0;return 0;}carry=((value>>(amount-1u))&1u)!=0;return value>>amount;}if(type==2){if(!amount){carry=((value>>31)&1u)!=0;return (value&0x80000000u)?0xFFFFFFFFu:0;}carry=((value>>(amount-1u))&1u)!=0;return uint32_t(int32_t(value)>>amount);}if(!amount){const uint32_t c=r.flagC()?0x80000000u:0u;carry=(value&1u)!=0;return c|(value>>1);}carry=((value>>(amount-1u))&1u)!=0;return ror(value,amount);}
uint32_t loadWord(GbaRuntime& r,uint32_t a){const uint32_t v=r.read32(a&~3u);return ror(v,(a&3u)*8u);}
void storeWord(GbaRuntime& r,uint32_t a,uint32_t v){r.write32(a&~3u,v);}
}
namespace ArmOps {
void msr(GbaRuntime& r,unsigned fields,unsigned rm){r.writeCpsr(r.reg(rm),fields);}
void dataProc(GbaRuntime& r,unsigned op,bool s,unsigned rn,unsigned rd,bool immediate,unsigned imm8,unsigned rotate,unsigned rm,unsigned shiftType,unsigned shiftImm,uint32_t pc){bool shCarry=r.flagC();uint32_t b;if(immediate){b=ror(imm8,rotate*2u);if(rotate)shCarry=(b>>31)!=0;}else b=shifted(r,regValue(r,rm,pc),shiftType,shiftImm,shCarry);const uint32_t a=regValue(r,rn,pc);uint32_t out=0;bool write=true,arith=false,sub=false;switch(op){case 0:out=a&b;break;case 1:out=a^b;break;case 2:out=a-b;arith=true;sub=true;break;case 3:out=b-a;arith=true;sub=true;break;case 4:out=a+b;arith=true;break;case 5:{const uint32_t c=r.flagC()?1u:0u;out=a+b+c;const uint32_t rhs=b+c;const uint64_t wide=uint64_t(a)+b+c;const bool ov=((~(a^rhs)&(a^out))>>31)!=0;if(s)r.setNZCV(out,(wide>>32)!=0,ov);r.reg(rd)=out;return;}case 6:{const uint32_t borrow=r.flagC()?0u:1u;const uint64_t rhs64=uint64_t(b)+borrow;const uint32_t rhs=uint32_t(rhs64);out=a-rhs;const bool ov=(((a^rhs)&(a^out))>>31)!=0;if(s)r.setNZCV(out,uint64_t(a)>=rhs64,ov);r.reg(rd)=out;return;}case 7:{const uint32_t borrow=r.flagC()?0u:1u;const uint64_t rhs64=uint64_t(a)+borrow;const uint32_t rhs=uint32_t(rhs64);out=b-rhs;const bool ov=(((b^rhs)&(b^out))>>31)!=0;if(s)r.setNZCV(out,uint64_t(b)>=rhs64,ov);r.reg(rd)=out;return;}case 8:out=a&b;write=false;s=true;break;case 9:out=a^b;write=false;s=true;break;case 10:out=a-b;write=false;s=true;arith=true;sub=true;break;case 11:out=a+b;write=false;s=true;arith=true;break;case 12:out=a|b;break;case 13:out=b;break;case 14:out=a&~b;break;case 15:out=~b;break;}if(s){if(arith){if(sub){if(op==3)r.setSubFlags(b,a,out);else r.setSubFlags(a,b,out);}else r.setAddFlags(a,b,out);}else r.setNZC(out,shCarry);}if(write)r.reg(rd)=out;}
void halfTransfer(GbaRuntime& r,bool load,unsigned kind,bool pre,bool up,bool wb,bool immediate,unsigned rn,unsigned rd,unsigned offset,uint32_t pc){
 const uint32_t base=rn==15u?pc+8u:r.reg(rn);
 const uint32_t displacement=immediate?offset:r.reg(offset);
 const uint32_t adjusted=up?base+displacement:base-displacement;
 const uint32_t addr=pre?adjusted:base;
 if(load){
   if(kind==1u)r.reg(rd)=r.read16(addr&~1u);
   else if(kind==2u)r.reg(rd)=uint32_t(int32_t(int8_t(r.read8(addr))));
   else if(kind==3u)r.reg(rd)=uint32_t(int32_t(int16_t(r.read16(addr&~1u))));
 }else if(kind==1u)r.write16(addr&~1u,uint16_t(r.reg(rd)));
 if((!pre||wb)&&rn!=15u)r.reg(rn)=adjusted;
}
void multiply(GbaRuntime& r,bool accumulate,bool setFlags,unsigned rd,unsigned rn,unsigned rs,unsigned rm){
 const uint32_t result=uint32_t(uint64_t(r.reg(rm))*r.reg(rs))+(accumulate?r.reg(rn):0u);
 r.reg(rd)=result;if(setFlags)r.setNZ(result);
}
void blockTransfer(GbaRuntime& r,bool load,bool pre,bool up,bool wb,unsigned rn,unsigned list,uint32_t pc){
 unsigned count=0;for(unsigned i=0;i<16;++i)if(list&(1u<<i))++count;
 if(!count)return;
 const uint32_t base=rn==15u?pc+8u:r.reg(rn);
 uint32_t addr=up?(base+(pre?4u:0u)):(base-count*4u+(pre?0u:4u));
 for(unsigned i=0;i<16;++i)if(list&(1u<<i)){
   if(load)r.reg(i)=r.read32(addr);
   else r.write32(addr,i==15u?pc+12u:r.reg(i));
   addr+=4u;
 }
 if(wb&&rn!=15u)r.reg(rn)=up?base+count*4u:base-count*4u;
}
void singleTransfer(GbaRuntime& r,bool load,bool byte,bool pre,bool up,bool wb,unsigned rn,unsigned rd,unsigned imm,bool registerOffset,uint32_t pc){
 uint32_t displacement=imm;
 if(registerOffset){bool carry=r.flagC();displacement=shifted(r,regValue(r,imm&15u,pc),(imm>>5)&3u,(imm>>7)&31u,carry);}
 uint32_t base=regValue(r,rn,pc);const uint32_t adjusted=up?base+displacement:base-displacement;const uint32_t addr=pre?adjusted:base;if(load){const uint32_t v=byte?r.read8(addr):loadWord(r,addr);if(rd!=15u)r.reg(rd)=v;}else{const uint32_t v=rd==15u?pc+12u:r.reg(rd);if(byte)r.write8(addr,uint8_t(v));else storeWord(r,addr,v);}if((!pre||wb)&&rn!=15u)r.reg(rn)=adjusted;}
}
)CPP";
  write_file(out_dir/"runtime/arm_ops.hpp",arm_h);write_file(out_dir/"runtime/arm_ops.cpp",arm_cpp);

  std::ostringstream map_h;map_h<<"#pragma once\n#include <cstddef>\n#include <cstdint>\nuint32_t native_approximate_block_cycles(uint32_t pc,bool thumb);\nextern const uint32_t kDiscoveredCodeTargets[];\nextern const size_t kDiscoveredCodeTargetCount;\nstruct LzAssetCandidate{uint32_t address;uint32_t compressed;uint32_t decompressed;};\nextern const LzAssetCandidate kLzAssetCandidates[];\nextern const size_t kLzAssetCandidateCount;\n";write_file(out_dir/"generated/code_map.hpp",map_h.str());
  std::ostringstream map_cpp;map_cpp<<"#include \"code_map.hpp\"\nconst uint32_t kDiscoveredCodeTargets[]={";if(report.code_targets.empty())map_cpp<<"0";for(size_t i=0;i<report.code_targets.size();++i){if(i)map_cpp<<',';map_cpp<<"0x"<<std::hex<<std::uppercase<<report.code_targets[i]<<'u'<<std::dec;}map_cpp<<"};\nconst size_t kDiscoveredCodeTargetCount="<<report.code_targets.size()<<";\nconst LzAssetCandidate kLzAssetCandidates[]={";if(report.lz10_streams.empty())map_cpp<<"{0,0,0}";for(size_t i=0;i<report.lz10_streams.size();++i){if(i)map_cpp<<',';const auto& c=report.lz10_streams[i];map_cpp<<"{0x"<<std::hex<<std::uppercase<<(0x08000000u+uint32_t(c.offset))<<"u,"<<std::dec<<c.compressed_size<<"u,"<<c.decompressed_size<<"u}";}map_cpp<<"};\nconst size_t kLzAssetCandidateCount="<<report.lz10_streams.size()<<";\n";write_file(out_dir/"generated/code_map.cpp",map_cpp.str());

  // Keep this separate from the actual native instruction handlers: costs
  // are approximations for video/timer development, NOT CPU cycle fidelity.
  struct CostRecord {uint32_t pc;bool thumb;uint32_t cost;};
  std::vector<CostRecord> costs;
  for(const auto& b:report.cfg.blocks)
    if(!b.instructions.empty())costs.push_back({b.start,b.mode==GbaCodeMode::Thumb,uint32_t(std::max<size_t>(1u,2u*b.instructions.size()))});
  for(const auto& b:iwramBlocks)
    if(!b.instructions.empty())costs.push_back({b.start,false,uint32_t(std::max<size_t>(1u,2u*b.instructions.size()))});
  std::sort(costs.begin(),costs.end(),[](const CostRecord& a,const CostRecord& b){return a.pc<b.pc;});
  std::ostringstream cycleMap;
  cycleMap<<"#include \"code_map.hpp\"\n#include <algorithm>\n#include <iterator>\nstruct BlockCycle {uint32_t pc;uint16_t cost;uint8_t thumb;};\nstatic constexpr BlockCycle kBlockCycles[]={\n";
  for(const auto& v:costs)cycleMap<<"  {"<<hexu(v.pc)<<","<<std::min<uint32_t>(v.cost,65535u)<<"u,"<<(v.thumb?1:0)<<"u},\n";
  cycleMap<<"};\nuint32_t native_approximate_block_cycles(uint32_t pc,bool thumb){\n"
           <<"const auto it=std::lower_bound(std::begin(kBlockCycles),std::end(kBlockCycles),pc,[](const BlockCycle& b,uint32_t a){return b.pc<a;});\n"
           <<"return (it!=std::end(kBlockCycles)&&it->pc==pc&&it->thumb==uint8_t(thumb))?it->cost:2u;\n}\n";
  write_file(out_dir/"generated/block_cycles.cpp",cycleMap.str());

  size_t generatedArmBlocks=0;
  size_t generatedThumbBlocks=0;
  uint32_t firstNativeThumb=0;
  std::ostringstream nativeH;
  nativeH<<"#pragma once\n#include <cstddef>\n#include <cstdint>\nclass GbaRuntime;\nenum class NativeTransferKind:uint8_t{Next,Unsupported};\nstruct NativeTransfer{NativeTransferKind kind;uint32_t address;bool thumb;};\nstruct NativeRunSummary{uint32_t pc;bool thumb;size_t blocks;bool supported;size_t relocated_arm_blocks=0;};\nstruct NativeDynamicCallEvent{uint32_t callsite;uint32_t veneer;uint32_t observed_target;bool thumb;uint32_t receiver_register=0xFFFFFFFFu;uint32_t receiver=0;uint32_t object_field=0;uint32_t vtable=0;uint32_t method_slot=0;uint32_t evidence=0;uint32_t write_serial=0;};\nusing NativeDynamicCallObserver=void(*)(const NativeDynamicCallEvent&,void*);\nvoid set_native_dynamic_call_observer(NativeDynamicCallObserver observer,void* context);\nextern const size_t kGeneratedNativeArmBlockCount;\nextern const size_t kGeneratedNativeThumbBlockCount;\nextern const uint32_t kFirstNativeThumbBlock;\nNativeTransfer dispatch_native_block(GbaRuntime& runtime,uint32_t pc,bool thumb);\nNativeRunSummary run_native_blocks(GbaRuntime& runtime,uint32_t pc,bool thumb,size_t maxBlocks);\n";
  // A runtime trace is only portable to the EXACT ROM that produced the build.
  // Header uses noncryptographic FNV-1a64 + byte count (accidental mismatch protection).
  // The default V3 file writes ONLY vtable-valued RAM words and any
  // later writes to those same words; this preserves overwrite evidence
  // while avoiding enormous IWRAM-copy and stack-update traces.
  std::set<uint32_t> traceTables;
  for(const auto& p:report.cfg.virtual_call_patterns)
    for(uint32_t table:p.candidate_tables)traceTables.insert(table);
  std::ostringstream traceH;
  traceH << R"TRACE(#pragma once
#include "native_blocks.hpp"
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <deque>
#include <unordered_set>
#include <cstdint>
namespace {
static constexpr uint32_t kTraceVtables[]={
)TRACE";
  if(traceTables.empty())traceH<<"0u,\n";
  else for(uint32_t table:traceTables)traceH<<hexu(table)<<",\n";
  traceH<<R"TRACE(};
}
class NativeTraceFile {
public:
  bool open(const char* filename){watched_.clear();file_.open(filename,std::ios::out|std::ios::trunc);if(!file_)return false;file_ << ")TRACE"
         << gba_trace_header(rom).replace(0,12,"GBA_TRACE_V3")
         << R"TRACE(\n";return bool(file_);}
  static void captureWrite(uint32_t address,uint32_t word,uint32_t serial,void* context){
    auto& t=*static_cast<NativeTraceFile*>(context);
    if(!t.file_)return;
    const bool rooted=std::binary_search(std::begin(kTraceVtables),std::end(kTraceVtables),word);
    if(rooted)t.watched_.insert(address);
    if(!rooted && !t.watched_.count(address))return;
    t.file_ << "W 0x" << std::hex << serial << " 0x" << address << " 0x" << word << std::dec << '\n';
  }
  static void capture(const NativeDynamicCallEvent& e,void* context){
    auto& f=static_cast<NativeTraceFile*>(context)->file_;
    if(f)f << "0x" << std::hex << e.callsite << " 0x" << e.veneer << " 0x" << e.observed_target << " 0x" << e.receiver_register << " 0x" << e.receiver << " 0x" << e.object_field << " 0x" << e.vtable << " 0x" << e.method_slot << " 0x" << e.evidence << " 0x" << e.write_serial << std::dec << '\n';
  }
private:
  std::ofstream file_;
  std::unordered_set<uint32_t> watched_;
};
)TRACE";
  write_file(out_dir/"generated/native_trace_file.hpp",traceH.str());
  write_file(out_dir/"generated/native_blocks.hpp",nativeH.str());
  // The sorted ROM-page shards were collected before emitting CMake.
  // A new Thumb function changes only its own 2 KiB module and the dispatcher.
  std::ostringstream armCases;
  for(const auto& b:report.cfg.blocks) {
    if (arm_block_liftable(b)) {++generatedArmBlocks;emit_arm_block_case(armCases,b);}
    if (thumb_block_liftable(b)) {if(!firstNativeThumb) firstNativeThumb=b.start;++generatedThumbBlocks;}
  }
  std::ostringstream nativeCpp;
  nativeCpp<<"#include \"code_map.hpp\"\n#include \"native_blocks.hpp\"\n#include \"gba_runtime.hpp\"\n#include \"arm_ops.hpp\"\n\n";
  for(const auto& entry:thumbShards)
    nativeCpp<<"NativeTransfer "<<shardName(entry.first)<<"(GbaRuntime&,uint32_t);\n";
  nativeCpp<<"NativeTransfer dispatch_native_iwram(GbaRuntime&,uint32_t);\n";
  nativeCpp<<"\nNativeTransfer dispatch_native_block(GbaRuntime& runtime,uint32_t pc,bool thumb){\n"
           <<"  if(!thumb && pc>=0x03000000u && pc<0x03008000u) return dispatch_native_iwram(runtime,pc);\n"
           <<"  if(!thumb){switch(pc){\n"<<armCases.str()
           <<"    default:return {NativeTransferKind::Unsupported,pc,false};\n  }}\n";
  if(shardCount) {
    nativeCpp<<"  struct Shard {uint32_t lo, hi; NativeTransfer(*run)(GbaRuntime&,uint32_t);};\n"
             <<"  static const Shard shards[]={\n";
    for(const auto& entry:thumbShards) {
      const auto& blocks=entry.second;
      nativeCpp<<"    {"<<hexu(blocks.front()->start)<<","<<hexu(blocks.back()->start)<<","<<shardName(entry.first)<<"},\n";
    }
    nativeCpp<<"  };\n  size_t lo=0,hi="<<shardCount<<"u;\n"
             <<"  while(lo<hi){const size_t mid=lo+(hi-lo)/2u;\n"
             <<"    if(pc>shards[mid].hi)lo=mid+1u;else hi=mid;}\n"
             <<"  if(lo<"<<shardCount<<"u && pc>=shards[lo].lo) return shards[lo].run(runtime,pc);\n";
  }
  nativeCpp<<"  return {NativeTransferKind::Unsupported,pc,true};\n}\n";
  nativeCpp<<"namespace {NativeDynamicCallObserver gNativeCallObserver=nullptr;void* gNativeCallContext=nullptr;}\n";
  // Only emit ROM-backed virtual load chains. The receiver is an observed
  // candidate register at the veneer, not an interprocedurally proven `this`.
  // Reject ambiguous snapshots, and never turn an observation into a CFG root.
  nativeCpp<<"namespace {struct VirtualPattern{uint32_t callsite,veneer,field,slot,table;};\n";
  nativeCpp<<"static const VirtualPattern kVirtualPatterns[]={\n";
  size_t virtualRecordCount=0;
  for(const auto& pattern:report.cfg.virtual_call_patterns)
    for(uint32_t table:pattern.candidate_tables){
      nativeCpp<<"{"<<hexu(pattern.callsite)<<","<<hexu(pattern.veneer)<<","<<pattern.object_offset
               <<"u,"<<pattern.slot_offset<<"u,"<<hexu(table)<<"},\n";
      ++virtualRecordCount;
    }
  if(!virtualRecordCount)nativeCpp<<"{0,0,0,0,0},\n";
  nativeCpp<<"};\n";
  nativeCpp<<"void match_virtual_snapshot(GbaRuntime& runtime,NativeDynamicCallEvent& e){\n"
    <<"  bool matched=false; uint32_t first_reg=0,first_obj=0,first_field=0,first_vtable=0,first_slot=0;\n"
    <<"  for(const auto& p:kVirtualPatterns){if(p.callsite!=e.callsite||p.veneer!=e.veneer)continue;\n"
    <<"    if((p.table&3u)!=0u || (p.slot&3u)!=0u || p.table>0xFFFFFFFFu-p.slot)continue;\n"
    <<"    if(runtime.read32(p.table+p.slot)!=e.observed_target)continue;\n"
    <<"    for(unsigned reg=0;reg<4;++reg){const uint32_t obj=runtime.reg(reg);\n"
    <<"      if(!((obj>=0x02000000u&&obj<0x02040000u)||(obj>=0x03000000u&&obj<0x03008000u)))continue;\n"
    <<"      if(obj>0xFFFFFFFFu-p.field || runtime.read32(obj+p.field)!=p.table)continue;\n"
    <<"      if(!matched){matched=true;first_reg=reg;first_obj=obj;first_field=p.field;first_vtable=p.table;first_slot=p.slot;}\n"
    <<"      else if(first_obj!=obj||first_field!=p.field||first_vtable!=p.table||first_slot!=p.slot){e.evidence=2u;return;}\n"
    <<"    }\n"
    <<"  }\n"
    <<"  if(matched){e.evidence=1u;e.receiver_register=first_reg;e.receiver=first_obj;e.object_field=first_field;e.vtable=first_vtable;e.method_slot=first_slot;\n"
    <<"    e.write_serial=runtime.lastWriteSerial(first_obj+first_field);\n"
    <<"    if(e.write_serial)e.evidence=3u;}\n"
    <<"}\n}\n";
  nativeCpp<<"void set_native_dynamic_call_observer(NativeDynamicCallObserver observer,void* context){gNativeCallObserver=observer;gNativeCallContext=context;}\n";
  nativeCpp<<"NativeRunSummary run_native_blocks(GbaRuntime& runtime,uint32_t pc,bool thumb,size_t maxBlocks){size_t n=0,relocated=0;for(;n<maxBlocks;++n){if(!thumb&&pc>=0x03000000u&&pc<0x03008000u)++relocated;";
  if(!report.cfg.indirect_veneer_stats.empty()) {
    nativeCpp<<"if(thumb && gNativeCallObserver){switch(pc){";
    for(const auto& veneer:report.cfg.indirect_veneer_stats)nativeCpp
      <<"case "<<hexu(veneer.address)<<":{const uint32_t lr=runtime.reg(14)&~1u;"
      <<"NativeDynamicCallEvent e{lr>=4u?lr-4u:0u,pc,runtime.reg("<<unsigned(veneer.register_index)
      <<"),(runtime.reg("<<unsigned(veneer.register_index)<<")&1u)!=0u};"
      <<"match_virtual_snapshot(runtime,e);gNativeCallObserver(e,gNativeCallContext);break;}";
    nativeCpp<<"default:break;}}";
  }
  nativeCpp<<"if(runtime.inBiosIrq() && !thumb && pc==0x00000138u){"
    <<"uint32_t resumePc=0;bool resumeThumb=false;"
    <<"if(!runtime.finishBiosIrq(resumePc,resumeThumb))return {pc,thumb,n,false,relocated};"
    <<"pc=resumePc;thumb=resumeThumb;continue;}"
    <<"const uint32_t approxCycles=native_approximate_block_cycles(pc,thumb);"
    <<"const auto t=dispatch_native_block(runtime,pc,thumb);if(t.kind==NativeTransferKind::Unsupported)return {pc,thumb,n,false,relocated};"
    <<"runtime.advanceCycles(approxCycles);pc=t.address;thumb=t.thumb;"
    <<"uint32_t isr=0;if(runtime.enterBiosIrq(pc,thumb,isr)){pc=isr;thumb=false;}"
    <<"}return {pc,thumb,n,true,relocated};}\n";
  nativeCpp<<"const size_t kGeneratedNativeArmBlockCount="<<generatedArmBlocks<<"u;\nconst size_t kGeneratedNativeThumbBlockCount="<<generatedThumbBlocks<<"u;\nconst uint32_t kFirstNativeThumbBlock="<<hexu(firstNativeThumb)<<";\n";
  std::ostringstream iwramCode;
  iwramCode<<"#include \"native_blocks.hpp\"\n#include \"gba_runtime.hpp\"\n#include \"arm_ops.hpp\"\n"
           <<"NativeTransfer dispatch_native_iwram(GbaRuntime& runtime,uint32_t pc){\n  switch(pc){\n";
  size_t overlayAddresses=0;
  for(size_t i=0;i<iwramBlocks.size();){
    size_t end=i+1u;
    while(end<iwramBlocks.size()&&iwramBlocks[end].start==iwramBlocks[i].start)++end;
    if(end>i+1u)++overlayAddresses;
    iwramCode<<"    case "<<hexu(iwramBlocks[i].start)<<":{\n";
    std::set<uint32_t> seenOpcodes;
    for(size_t j=i;j<end;++j){
      const auto& b=iwramBlocks[j];
      const uint32_t expected=b.instructions[0].raw;
      if(!seenOpcodes.insert(expected).second)continue; // same instruction = same native behavior
      iwramCode<<"      if(runtime.read32("<<hexu(b.start)<<")=="<<hexu(expected)<<"){\n";
      std::ostringstream one;
      emit_arm_block_case(one,b);
      const std::string body=one.str();
      const size_t first=body.find("{\n");
      const size_t last=body.rfind("\n    }");
      if(first==std::string::npos||last==std::string::npos||last<=first){error="ARM relocated block emitter malformed";return false;}
      iwramCode<<body.substr(first+2,last-(first+2))<<"\n      }\n";
    }
    // ARM games can patch ONLY the condition field of an existing B/BL in
    // IWRAM. The displacement, link bit and all other opcode bits must still
    // match one exact ROM-backed instruction; no generic RAM execution.
    std::set<uint32_t> conditionalBranchKeys;
    for(size_t j=i;j<end;++j){
      const uint32_t raw=iwramBlocks[j].instructions[0].raw;
      if((raw&0x0E000000u)!=0x0A000000u||(raw>>28)==15u)continue;
      const uint32_t key=raw&0x0FFFFFFFu;
      if(!conditionalBranchKeys.insert(key).second)continue;
      const uint32_t a=iwramBlocks[j].start;
      const int32_t imm=int32_t(raw&0xFFFFFFu);
      const int32_t sx=(imm&0x800000)?(imm|int32_t(0xFF000000u)):imm;
      const uint32_t dest=uint32_t(int64_t(a)+8+int64_t(sx)*4);
      iwramCode<<"      {const uint32_t live=runtime.read32("<<hexu(a)<<");"
               <<"const unsigned condition=live>>28;"
               <<"if(condition<15u && (live&0x0FFFFFFFu)=="<<hexu(key)<<") {"
               <<"if(runtime.condition(condition)){";
      if(raw&0x01000000u)iwramCode<<"runtime.reg(14)="<<hexu(a+4u)<<";";
      iwramCode<<"return {NativeTransferKind::Next,"<<hexu(dest)<<",false};}"
               <<"return {NativeTransferKind::Next,"<<hexu(a+4u)<<",false};}}\n";
    }
    // A second ROM-observed self-modification: ADD <-> SUB changes the ALU
    // opcode field only. Register wiring, flags bit, addressing and condition
    // must be identical; all other rewrites are rejected.
    std::set<uint32_t> dataProcKeys;
    for(size_t j=i;j<end;++j){
      const uint32_t raw=iwramBlocks[j].instructions[0].raw;
      const unsigned oldOp=(raw>>21)&15u;
      const unsigned cond=raw>>28;
      if((raw&0x0C000000u)!=0u||(oldOp!=2u&&oldOp!=4u)||
         ((raw>>12)&15u)==15u||cond==15u||
         ((raw&0x02000000u)==0u && (raw&0x10u)!=0u))continue;
      const uint32_t key=raw&~0x01E00000u;
      if(!dataProcKeys.insert(key).second)continue;
      const uint32_t a=iwramBlocks[j].start;
      const bool imm=(raw&0x02000000u)!=0u;
      iwramCode<<"      {const uint32_t live=runtime.read32("<<hexu(a)<<");"
               <<"const unsigned newOp=(live>>21)&15u;"
               <<"if((live&~0x01E00000u)=="<<hexu(key)<<" && (newOp==2u||newOp==4u)){";
      if(cond!=14u)iwramCode<<"if(runtime.condition("<<cond<<")){";
      iwramCode<<"ArmOps::dataProc(runtime,newOp,"<<((raw>>20)&1u)<<","<<((raw>>16)&15u)<<","<<((raw>>12)&15u)<<","<<(imm?1:0)<<",";
      if(imm)iwramCode<<(raw&255u)<<","<<((raw>>8)&15u)<<",0,0,0,";
      else iwramCode<<"0,0,"<<(raw&15u)<<","<<((raw>>5)&3u)<<","<<((raw>>7)&31u)<<",";
      iwramCode<<hexu(a)<<");";
      if(cond!=14u)iwramCode<<"}";
      iwramCode<<"return {NativeTransferKind::Next,"<<hexu(a+4u)<<",false};}}\n";
    }
    iwramCode<<"      return {NativeTransferKind::Unsupported,pc,false};\n    }\n";
    i=end;
  }
  iwramCode<<"    default:return {NativeTransferKind::Unsupported,pc,false};\n  }\n}\n";
  if(relocated && relocated->scan_rom_backed_copies){
    const GbaBasicBlock* candidate=nullptr;
    for(const auto& block:iwramBlocks){
      if(block.instructions.empty()||(block.instructions[0].raw&0x0C000000u)!=0u)continue;
      const uint32_t changed=block.instructions[0].raw^0x00000004u;
      if(std::any_of(iwramBlocks.begin(),iwramBlocks.end(),[&](const auto& other){
          return other.start==block.start&&!other.instructions.empty()&&other.instructions[0].raw==changed;}))continue;
      candidate=&block;break;
    }
    if(!candidate){error="No suitable scanned IWRAM guard candidate";return false;}
    const uint32_t pc=candidate->start,word=candidate->instructions[0].raw;
    std::ostringstream scanTest;
    scanTest<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include <cassert>\n"
      <<"int main(){GbaRuntime r;r.reset();r.write32("<<hexu(pc)<<","<<hexu(word)<<");"
      <<"const auto ok=dispatch_native_block(r,"<<hexu(pc)<<",false);"
      <<"if(ok.kind!=NativeTransferKind::Next)return 3;"
      <<"r.write32("<<hexu(pc)<<","<<hexu(word^0x00000004u)<<");"
      <<"const auto bad=dispatch_native_block(r,"<<hexu(pc)<<",false);"
      <<"if(bad.kind!=NativeTransferKind::Unsupported)return 4;return 0;}\n";
    write_file(out_dir/"tests/iwram_scan_guard_test.cpp",scanTest.str());
  }
  if(relocated){std::ostringstream reportIwram;
    reportIwram<<"GBA IWRAM address-aware lifting\nsource_ROM="<<hexu(relocated->source_rom)
      <<" dest_IWRAM="<<hexu(relocated->dest_ram)<<" bytes="<<relocated->byte_count
      <<" entry="<<hexu(relocated->entry_ram)<<" irq_entry="<<hexu(relocated->irq_entry_ram)<<" generated_ARM_instructions="<<iwramBlocks.size();
    for(const auto& e:relocated->extra_copies)reportIwram<<"\nextra_source_ROM="<<hexu(e.source_rom)<<" extra_dest_IWRAM="<<hexu(e.dest_ram)<<" bytes="<<e.byte_count<<" entry="<<hexu(e.entry_ram)<<" overlay="<<(e.overlay?"YES":"NO");
    reportIwram<<"\nscan_ROM_backed_copies="<<(relocated->scan_rom_backed_copies?"YES":"NO");
    reportIwram<<"\nobserved_ARM_roots="<<relocated->observed_arm_roots.size();
    for(uint32_t root:relocated->observed_arm_roots)reportIwram<<" "<<hexu(root);
    reportIwram<<"\nIWRAM variant addresses="<<overlayAddresses<<"\nHandlers choose a code variant only if LIVE RAM opcode matches exact ROM bytes.\n";
    write_file(out_dir/"reports/iwram-lift.txt",reportIwram.str());
  }
  if(!write_file(out_dir/"generated/native_iwram.cpp",iwramCode.str())){error="IWRAM output failed";return false;}
  if(!write_file(out_dir/"generated/native_blocks.cpp",nativeCpp.str())){error="Falha no dispatcher";return false;}
  for(const auto& entry:thumbShards) {
    std::ostringstream part;
    part<<"#include \"native_blocks.hpp\"\n#include \"gba_runtime.hpp\"\n#include \"thumb_ops.hpp\"\n"
          <<"NativeTransfer "<<shardName(entry.first)<<"(GbaRuntime& runtime,uint32_t pc){\n  switch(pc){\n";
    for(const auto* block:entry.second)emit_native_block_case(part,*block);
    part<<"    default:return {NativeTransferKind::Unsupported,pc,true};\n  }\n}\n";
    if(!write_file(out_dir/"generated"/(shardName(entry.first)+".cpp"),part.str())){error="Falha no modulo Thumb";return false;}
  }

  write_file(out_dir/"generated/game_entry.hpp","#pragma once\nclass GbaRuntime;\nint gba_generated_entry(GbaRuntime& runtime);\n");
  std::ostringstream entry;entry<<"#include \"game_entry.hpp\"\n#include \"gba_runtime.hpp\"\n#include \"code_map.hpp\"\n#include \"native_blocks.hpp\"\n#include <iostream>\nint gba_generated_entry(GbaRuntime& runtime){(void)runtime;std::cout<<\"Naive static targets: \"<<kDiscoveredCodeTargetCount<<\"; recursive CFG blocks: "<<report.cfg.blocks.size()<<"; confirmed function entries: "<<report.cfg.function_entries.size()<<".\\n\";std::cout<<\"Generated native ARM/Thumb handlers: \"<<(kGeneratedNativeArmBlockCount+kGeneratedNativeThumbBlockCount)<<\"; LZ10 assets: \"<<kLzAssetCandidateCount<<\".\\n\";std::cout<<\"Original ARM entry target: 0x"<<std::hex<<std::uppercase<<report.entry_target<<std::dec<<"\\n\";std::cout<<\"ARM boot bridge and confirmed Thumb blocks are statically lifted.\\n\";return 0;}\n";write_file(out_dir/"generated/game_entry.cpp",entry.str());

  uint32_t bootThumbTarget=0;
  for(const auto& b:report.cfg.blocks){if(b.start!=report.entry_target||b.mode!=GbaCodeMode::Arm)continue;for(const auto& e:b.successors)if(e.mode==GbaCodeMode::Thumb){bootThumbTarget=e.address;break;}}
  std::ostringstream bootTest;
  bootTest<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include <iostream>\n#include <string>\nint main(int argc,char**argv){if(argc<=1){std::cerr<<\"ROM path missing\\n\";return 1;}GbaRuntime r;std::string err;if(!r.loadRom(argv[1],err)){std::cerr<<err<<\'\\n\';return 2;}r.reset();const auto t=dispatch_native_block(r,"<<hexu(report.entry_target)<<",false);if(t.kind!=NativeTransferKind::Next||!t.thumb||t.address!="<<hexu(bootThumbTarget)<<")return 3;return 0;}\n";
  write_file(out_dir/"tests/rom_preview_test.cpp",R"TEST(#include "gba_runtime.hpp"
#include <cassert>
#include <iostream>
int main(){
  GbaRuntime r;r.reset();
  r.setKeysPressed(uint16_t((1u<<0)|(1u<<3)));
  assert(r.read16(0x04000130u)==uint16_t(0x03f6u));
  r.setKeysPressed(0);assert(r.read16(0x04000130u)==0x03ffu);
  r.scheduleKeysAtFrame(1u,0x8u);
  r.scheduleKeysAtFrame(2u,0u);
  r.advanceCycles(160u*1232u);
  assert(r.vblankEvents()==1u&&r.read16(0x04000130u)==0x03f7u);
  r.advanceCycles(228u*1232u);
  assert(r.vblankEvents()==2u&&r.read16(0x04000130u)==0x03ffu);
  auto image=r.renderPreview();
  assert(image.rgb.size()==240u*160u*3u);
  r.reset();
  r.write16(0x04000000u,0x0403u);
  r.write16(0x04000020u,0x0100u);r.write16(0x04000026u,0x0100u);
  r.write16(0x06000000u,0x001fu);
  auto bitmap=r.renderPreview();
  assert(bitmap.mode==3u);
  assert(bitmap.rgb[0]==255u && bitmap.rgb[1]==0 && bitmap.rgb[2]==0);
  std::cout<<"ROM preview + active-low GBA keypad OK\n";
  return 0;
}
)TEST");
  write_file(out_dir/"tests/boot_bridge_test.cpp",bootTest.str());
  std::ostringstream originTest;
  originTest<<"#include \"gba_runtime.hpp\"\n#include <string>\n"
    <<"int main(int argc,char**argv){if(argc<2)return 1;GbaRuntime r;std::string err;if(!r.loadRom(argv[1],err))return 2;"
    <<"const auto& bytes=r.rom();if(bytes.size()<128)return 3;"
    <<"size_t off=0;for(size_t i=0;i+48<bytes.size();++i){"
    <<"if(bytes[i]!=0xffu && bytes[i+1]!=0xffu && bytes[i+2]!=0xffu){off=i;break;}}"
    <<"for(unsigned i=0;i<32;++i)r.write8(0x03000400u+i,bytes[off+i]);"
    <<"const uint32_t found=r.uniqueRomCopyOrigin(0x03000400u,32);"
    <<"return found==0x08000000u+off?0:4;}\n";
  write_file(out_dir/"tests/rom_copy_origin_test.cpp",originTest.str());
  if(relocated){
    std::ostringstream boot;
    boot<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include <string>\n"
      <<"int main(int argc,char**argv){if(argc<2)return 1;GbaRuntime r;std::string err;if(!r.loadRom(argv[1],err))return 2;"
      <<"r.reset();const auto result=run_native_blocks(r,"<<hexu(report.entry_target)<<",false,"<<(relocated->irq_entry_ram?80000u:710000u)<<"u);"
      <<"if(!result.supported||result.blocks!="<<(relocated->irq_entry_ram?80000u:710000u)<<"u)return 3;"
      <<"if(result.relocated_arm_blocks<10u)return 4;";
    if(relocated->irq_entry_ram)boot<<"if(r.irqEntries()<1u||r.irqReturns()<1u||r.inBiosIrq())return 5;";
    boot<<"return 0;}\n";
    write_file(out_dir/"tests/relocated_boot_integration_test.cpp",boot.str());
  }
  if(relocated){
    std::ostringstream t;
    t<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include <string>\n"
     <<"int main(int argc,char**argv){if(argc<2)return 1;GbaRuntime r;std::string err;if(!r.loadRom(argv[1],err))return 2;\n"
     <<"const uint32_t src="<<hexu(relocated->source_rom)<<",dst="<<hexu(relocated->dest_ram)<<";\n"
     <<"for(uint32_t i=0;i<"<<hexu(relocated->byte_count)<<";i+=4u)r.write32(dst+i,r.read32(src+i));\n"
     <<"r.reg(13)=0x03007F00u;const uint32_t oldSp=r.reg(13);\n"
     <<"auto n=dispatch_native_block(r,"<<hexu(relocated->entry_ram)<<",false);\n"
     <<"if(n.kind!=NativeTransferKind::Next||n.address!="<<hexu(relocated->entry_ram+4u)<<"||r.reg(13)>=oldSp)return 3;\n"
     <<"r.write8("<<hexu(relocated->entry_ram)<<",uint8_t(r.read8("<<hexu(relocated->entry_ram)<<")^1u));\n"
     <<"n=dispatch_native_block(r,"<<hexu(relocated->entry_ram)<<",false);\n"
     <<"return n.kind==NativeTransferKind::Unsupported?0:4;}\n";
    write_file(out_dir/"tests/relocated_arm_test.cpp",t.str());
  }
  if(relocated && !relocated->extra_copies.empty()){
    const auto& ex=relocated->extra_copies.front();
    std::ostringstream test;
    test<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include \"arm_ops.hpp\"\n#include <string>\n"
      <<"int main(int argc,char**argv){if(argc<2)return 1;GbaRuntime r;std::string error;"
      <<"if(!r.loadRom(argv[1],error))return 2;r.reset();"
      <<"const uint32_t src="<<hexu(ex.source_rom)<<",dst="<<hexu(ex.dest_ram)<<",size="<<hexu(ex.byte_count)<<";"
      <<"for(uint32_t off=0;off<size;off+=4u)r.write32(dst+off,r.read32(src+off));"
      <<"r.reg(13)=0x03007C00u;"
      <<"auto next=dispatch_native_block(r,dst,false);"
      <<"if(next.kind!=NativeTransferKind::Next||next.address!=dst+4u)return 3;"
      <<"r.write8(dst,uint8_t(r.read8(dst)^1u));"
      <<"if(dispatch_native_block(r,dst,false).kind!=NativeTransferKind::Unsupported)return 4;"
      <<"r.reg(1)=0x02000000u;r.reg(2)=0x20u;r.write32(0x02000080u,0xCAFEBABEu);"
      <<"ArmOps::singleTransfer(r,true,false,true,true,false,1,0,(2u<<7)|2u,true,0x08000000u);"
      <<"if(r.reg(0)!=0xCAFEBABEu)return 5;"
      <<"r.reg(10)=0x20u;"
      <<"ArmOps::dataProc(r,4,false,15,15,false,0,0,10,0,0,0x03002240u);"
      <<"if(r.reg(15)!=0x03002268u)return 6;"
      <<"return 0;}\n";
    write_file(out_dir/"tests/extra_arm_execution_test.cpp",test.str());
  }

  if(relocated){
    const auto& copies=relocated->extra_copies;
    for(const auto& variant:copies){
      if(!variant.overlay)continue;
      const uint32_t overlap=std::max(variant.dest_ram,relocated->dest_ram);
      const uint32_t overlapEnd=std::min(uint64_t(variant.dest_ram)+variant.byte_count,uint64_t(relocated->dest_ram)+relocated->byte_count);
      const GbaArmCopyRegion* base=nullptr;
      GbaArmCopyRegion primaryCopy{relocated->source_rom,relocated->dest_ram,relocated->byte_count,relocated->entry_ram};
      if(overlap<overlapEnd)base=&primaryCopy;
      else for(const auto& candidate:copies){
        if(&candidate==&variant)break;
        const uint32_t lo=std::max(candidate.dest_ram,variant.dest_ram);
        const uint64_t hi=std::min(uint64_t(candidate.dest_ram)+candidate.byte_count,uint64_t(variant.dest_ram)+variant.byte_count);
        if(uint64_t(lo)<hi){base=&candidate;break;}
      }
      if(!base)continue;
      const uint32_t addr=std::max(base->dest_ram,variant.dest_ram);
      const uint32_t variantAtOld=rom.read32(size_t(variant.source_rom-0x08000000u)+addr-variant.dest_ram);
      const bool existsVariantAtOld=std::any_of(iwramBlocks.begin(),iwramBlocks.end(),[&](const GbaBasicBlock& b){return b.start==addr&&!b.instructions.empty()&&b.instructions[0].raw==variantAtOld;});
      std::ostringstream t;
      t<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include <string>\n"
        <<"int main(int argc,char** argv){if(argc<2)return 1;GbaRuntime r;std::string e;if(!r.loadRom(argv[1],e))return 2;"
        <<"auto load=[&](uint32_t src,uint32_t dst,uint32_t size){for(uint32_t n=0;n<size;n+=4u)r.write32(dst+n,r.read32(src+n));};"
        <<"r.reset();load("<<hexu(base->source_rom)<<","<<hexu(base->dest_ram)<<","<<hexu(base->byte_count)<<");"
        <<"const auto oldOpcode=r.read32("<<hexu(addr)<<");"
        <<"const auto before=dispatch_native_block(r,"<<hexu(addr)<<",false);"
        <<"load("<<hexu(variant.source_rom)<<","<<hexu(variant.dest_ram)<<","<<hexu(variant.byte_count)<<");"
        <<"const auto newOpcode=r.read32("<<hexu(addr)<<");"
        <<"const auto after=dispatch_native_block(r,"<<hexu(addr)<<",false);"
        <<"if(before.kind!=NativeTransferKind::Next)return 3;"
        <<"if(after.kind!="<<(existsVariantAtOld?"NativeTransferKind::Next":"NativeTransferKind::Unsupported")<<")return 4;"
        <<"if(dispatch_native_block(r,"<<hexu(variant.entry_ram)<<",false).kind!=NativeTransferKind::Next)return 6;"
        <<"r.write32("<<hexu(addr)<<",0xFFFFFFFFu);"
        <<"if(dispatch_native_block(r,"<<hexu(addr)<<",false).kind!=NativeTransferKind::Unsupported)return 5;"
        <<"return 0;}\n";
      write_file(out_dir/"tests/relocated_overlay_test.cpp",t.str());
      break;
    }
  }

  // Regression for live ARM instruction patches observed in Crash ACQE.
  // This test is emitted only if BOTH original ROM opcodes are present in a
  // mapped region, and verifies the changed opcode semantics (not just a skip).
  const auto containsArm=[](const std::vector<GbaBasicBlock>& blocks,uint32_t addr,uint32_t raw){
    return std::any_of(blocks.begin(),blocks.end(),[&](const auto& b){
      return b.start==addr&&!b.instructions.empty()&&b.instructions[0].raw==raw;});};
  const bool hasObservedArmPatches=relocated &&
    containsArm(iwramBlocks,0x030022A4u,0xE0822008u) &&
    containsArm(iwramBlocks,0x030022B4u,0xBAFFFFF3u);
  if(hasObservedArmPatches){
    std::ostringstream t;
    t<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include <string>\n"
      <<"int main(int argc,char**argv){if(argc<2)return 1;GbaRuntime r;std::string e;if(!r.loadRom(argv[1],e))return 2;r.reset();"
      <<"for(unsigned off=0;off<0x200u;off+=4u)r.write32(0x03002208u+off,r.read32(0x0803A358u+off));"
      <<"r.reg(2)=17;r.reg(8)=5;"
      <<"r.write32(0x030022A4u,0xE0422008u);"
      <<"auto result=dispatch_native_block(r,0x030022A4u,false);"
      <<"if(result.kind!=NativeTransferKind::Next||result.address!=0x030022A8u||r.reg(2)!=12u)return 3;"
      <<"r.reg(2)=17;r.write32(0x030022A4u,0xE0822008u);"
      <<"result=dispatch_native_block(r,0x030022A4u,false);"
      <<"if(result.kind!=NativeTransferKind::Next||r.reg(2)!=22u)return 4;"
      <<"r.write32(0x030022A4u,0xE0022008u);"
      <<"if(dispatch_native_block(r,0x030022A4u,false).kind!=NativeTransferKind::Unsupported)return 5;"
      <<"r.write32(0x030022B4u,0xCAFFFFF3u);"
      <<"result=dispatch_native_block(r,0x030022B4u,false);"
      <<"if(result.kind!=NativeTransferKind::Next||result.address!=0x03002288u)return 6;"
      <<"r.setNZ(0u);result=dispatch_native_block(r,0x030022B4u,false);"
      <<"if(result.kind!=NativeTransferKind::Next||result.address!=0x030022B8u)return 7;"
      <<"r.write32(0x030022B4u,0xCAFFFFF2u);"
      <<"if(dispatch_native_block(r,0x030022B4u,false).kind!=NativeTransferKind::Unsupported)return 8;"
      <<"return 0;}\n";
    write_file(out_dir/"tests/arm_patched_opcodes_test.cpp",t.str());
  }
  if(thumbReturnForTest) {
    std::ostringstream test;
    test<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n"
        <<"int main(){GbaRuntime runtime;runtime.reset();runtime.reg(14)=0x08000171u;"
        <<"const auto t=dispatch_native_block(runtime,"<<hexu(thumbReturnForTest)<<",true);"
        <<"return t.kind==NativeTransferKind::Next && t.thumb && t.address==0x08000170u?0:1;}\n";
    write_file(out_dir/"tests/native_thumb_dispatch_test.cpp",test.str());
  }



  if(firstVeneerAddress && thumbReturnForTest && firstVeneerCallsite){
    std::ostringstream traceTest;
    traceTest<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include \"native_trace_file.hpp\"\n#include <vector>\n"
        <<"static void record(const NativeDynamicCallEvent& e,void* c){auto* v=static_cast<std::vector<NativeDynamicCallEvent>*>(c);v->push_back(e);}\n"
        <<"int main(){GbaRuntime runtime;runtime.reset();std::vector<NativeDynamicCallEvent> events;"
        <<"runtime.reg(14)="<<hexu((firstVeneerCallsite+4u)|1u)<<";runtime.reg("<<firstVeneerReg<<")="<<hexu(thumbReturnForTest|1u)<<";"
        <<"set_native_dynamic_call_observer(&record,&events);"
        <<"(void)run_native_blocks(runtime,"<<hexu(firstVeneerAddress)<<",true,1);"
        <<"set_native_dynamic_call_observer(nullptr,nullptr);"
        <<"NativeTraceFile sink;if(!sink.open(\"native-trace-smoke.txt\"))return 2;"
        <<"if(events.size()!=1u)return 3;NativeTraceFile::capture(events[0],&sink);"
        <<"return events[0].callsite=="<<hexu(firstVeneerCallsite)<<" && "
        <<"events[0].veneer=="<<hexu(firstVeneerAddress)<<" && events[0].observed_target=="
        <<hexu(thumbReturnForTest|1u)<<" && events[0].thumb ? 0 : 1;}\n";
    write_file(out_dir/"tests/dynamic_call_trace_test.cpp",traceTest.str());
  }

  if(receiverPattern){
    const auto& pattern=*receiverPattern;
    const auto veneer=std::find_if(report.cfg.indirect_veneer_stats.begin(),report.cfg.indirect_veneer_stats.end(),
        [&](const GbaIndirectVeneerStat& v){return v.address==pattern.veneer;});
    const unsigned receiverReg=veneer->register_index==0u?1u:0u;
    std::ostringstream test;
    test<<"#include \"gba_runtime.hpp\"\n#include \"native_blocks.hpp\"\n#include \"native_trace_file.hpp\"\n#include <vector>\n#include <string>\n"
        <<"static void collect(const NativeDynamicCallEvent& e,void* ptr){static_cast<std::vector<NativeDynamicCallEvent>*>(ptr)->push_back(e);}\n"
        <<"int main(int argc,char** argv){if(argc<2)return 1;GbaRuntime r;std::string err;if(!r.loadRom(argv[1],err))return 2;"
        <<"r.reset();const uint32_t obj=0x02000100u;r.reg("<<receiverReg<<")=obj;"
        <<"NativeTraceFile f;if(!f.open(\"native-receiver-smoke.txt\"))return 4;"
        <<"r.setMemoryWriteObserver(&NativeTraceFile::captureWrite,&f);"
        <<"r.write32(obj+"<<pattern.object_offset<<"u,"<<hexu(receiverTable)<<");"
        <<"r.reg("<<unsigned(veneer->register_index)<<")="<<hexu(receiverTarget)<<";"
        <<"r.reg(14)="<<hexu((pattern.callsite+4u)|1u)<<";"
        <<"std::vector<NativeDynamicCallEvent> events;set_native_dynamic_call_observer(&collect,&events);"
        <<"(void)run_native_blocks(r,"<<hexu(pattern.veneer)<<",true,1);"
        <<"set_native_dynamic_call_observer(nullptr,nullptr);"
        <<"if(events.size()!=1u||events[0].evidence!=3u||events[0].write_serial==0u||events[0].receiver!=obj||events[0].vtable!="<<hexu(receiverTable)
        <<"||events[0].method_slot!="<<pattern.slot_offset<<"u||events[0].observed_target!="<<hexu(receiverTarget)<<")return 3;"
        <<"NativeTraceFile::capture(events[0],&f);return 0;}\n";
    write_file(out_dir/"tests/native_receiver_trace_test.cpp",test.str());
  }
  const char* runtime_test=R"CPP(#include "gba_runtime.hpp"
#include "thumb_ops.hpp"
#include <iostream>
int main(){
 GbaRuntime r;r.reset();
 r.write32(0x02000000,0x12345678);if(r.read32(0x02000000)!=0x12345678)return 1;
 r.write16(0x03000002,0xBEEF);if(r.read16(0x03000002)!=0xBEEF)return 2;
 r.write32(0x02000020,0xAABBCCDD);r.reg(0)=0x02000020;r.reg(1)=0x02000040;r.reg(2)=(1u<<26)|1u;r.swi(0x0B);if(r.read32(0x02000040)!=0xAABBCCDD)return 3;
 r.reg(0)=81;r.swi(0x08);if(r.reg(0)!=9)return 4;
 ThumbOps::immOp(r,0,0,5);ThumbOps::immOp(r,2,0,3);if(r.reg(0)!=8)return 5;ThumbOps::immOp(r,1,0,8);if(!r.flagZ()||!r.condition(0))return 6;
 r.reg(13)=0x0203FFF0;r.reg(0)=0x11223344;r.reg(14)=0x08000101;ThumbOps::push(r,1,true);r.reg(0)=0;r.reg(14)=0;const uint32_t pc=ThumbOps::pop(r,1,true);if(r.reg(0)!=0x11223344||pc!=0x08000101||r.reg(13)!=0x0203FFF0)return 7;
 return 0;
}
)CPP";write_file(out_dir/"tests/runtime_test.cpp",runtime_test);
  const char* hardwareTest=R"CPP(#include "gba_runtime.hpp"
#include <cstdint>
#include <iostream>
int main(){
 GbaRuntime r;r.reset();
 auto check=[](bool condition,int code){if(!condition){std::cerr<<"hardware regression "<<code<<'\n';return false;}return true;};
 if(!check(r.read16(0x04000130u)==0x03FFu,1))return 1;
 r.setKeysPressed(1u);if(!check(r.read16(0x04000130u)==0x03FEu,2))return 2;
 r.write16(0x04000130u,0u);if(!check(r.read16(0x04000130u)==0x03FEu,3))return 3;
 r.write16(0x04000200u,0x000Fu);r.write16(0x04000208u,1u);
 r.write16(0x04000004u,uint16_t((2u<<8)|0x38u));
 r.advanceCycles(1005u);if(!check(!(r.read16(0x04000004u)&2u),4))return 4;
 r.advanceCycles(1u);if(!check((r.read16(0x04000004u)&2u)&&r.pendingIrq()==2u,5))return 5;
 r.write16(0x04000202u,2u);if(!check(r.pendingIrq()==0u,6))return 6;
 r.advanceCycles(226u);if(!check(r.read16(0x04000006u)==1u && !(r.read16(0x04000004u)&2u),7))return 7;
 r.advanceCycles(1232u);if(!check(r.scanline()==2u && (r.pendingIrq()&4u),8))return 8;
 r.write16(0x04000202u,4u);
 r.advanceCycles(158u*1232u);if(!check(r.scanline()==160u && r.vblankEvents()==1u && (r.pendingIrq()&1u),9))return 9;
 r.advanceCycles(67u*1232u);if(!check(r.scanline()==227u && !(r.read16(0x04000004u)&1u),10))return 10;
 r.advanceCycles(1232u);if(!check(r.scanline()==0u && r.completedFrames()==1u && r.clockCycles()==280896u,11))return 11;
 r.write16(0x04000202u,0xFFFFu);
 r.write16(0x04000100u,0xFFFEu);r.write16(0x04000102u,0x00C0u);
 r.advanceCycles(2u);if(!check(r.read16(0x04000100u)==0xFFFEu && (r.pendingIrq()&8u),12))return 12;
 r.write16(0x04000104u,0xFFFFu);r.write16(0x04000106u,0x00C4u);
 r.advanceCycles(2u);if(!check((r.read16(0x04000202u)&0x10u)!=0u,13))return 13;
 r.write16(0x04000202u,0x0018u);if(!check((r.read16(0x04000202u)&0x18u)==0u,14))return 14;
 r.write16(0x04000102u,0u);r.write16(0x04000106u,0u);
 r.write32(0x02000020u,0xABCDEF01u);
 r.write32(0x040000D4u,0x02000020u);r.write32(0x040000D8u,0x05000000u);
 r.write32(0x040000DCu,0xD4000001u); // DMA3 VBlank, word, IRQ, enable
 if(!check(r.read32(0x05000000u)==0u,15))return 15;
 r.advanceCycles(160u*1232u);
 if(!check(r.read32(0x05000000u)==0xABCDEF01u && (r.read16(0x04000202u)&0x0800u),16))return 16;
 if(!check(!(r.read32(0x040000DCu)&0x80000000u),17))return 17;
 std::cout<<"LCD 280896 cycles/frame; IF W1C; VBlank/HBlank/VCount; timers/cascade; DMA3 event PASS\n";
 return 0;
}
)CPP";
  write_file(out_dir/"tests/hardware_timing_test.cpp",hardwareTest);
  const char* videoTest=R"CPP(#include "gba_runtime.hpp"
#include <cstdint>
#include <iostream>
int main(){
 GbaRuntime r;r.reset();r.enableVideoCapture(true);
 const auto empty=r.currentVideoSample();
 r.write16(0x04000000u,0x0403u);
 r.write16(0x05000000u,0x001Fu);
 r.write16(0x06000000u,0x7C00u);
 r.write16(0x07000000u,0x0100u);
 const auto changed=r.currentVideoSample();
 if(changed.dispcnt!=0x0403u || changed.regs_hash==empty.regs_hash ||
    changed.palette_hash==empty.palette_hash || changed.vram_hash==empty.vram_hash ||
    changed.oam_hash==empty.oam_hash || !changed.vram_changes || !changed.palette_changes ||
    !changed.oam_changes || !changed.video_io_changes)return 1;
 // DMA3 immediate copies into video RAM; expected state reflects the transfer.
 r.write16(0x02000000u,0x1234u);
 r.write32(0x040000D4u,0x02000000u);
 r.write32(0x040000D8u,0x06000002u);
 r.write32(0x040000DCu,0x80000001u);
 if(r.read16(0x06000002u)!=0x1234u||r.currentVideoSample().dma3_transfers!=1u)return 2;
 r.advanceCycles(160u*1232u);
 if(r.videoSamples().size()!=1u||r.videoSamples()[0].frame!=1u||
    r.videoSamples()[0].vcount!=160u||r.videoSamples()[0].cycles!=197120u||
    r.videoSamples()[0].vram_hash!=r.currentVideoSample().vram_hash)return 3;
 // SWI register-memory-reset clears video regions directly, not via write8.
 // Those mutations must still increment change counters for audit integrity.
 const auto beforeReset=r.currentVideoSample();
 r.registerRamReset(4u|8u|16u);
 const auto afterReset=r.currentVideoSample();
 if(afterReset.vram_hash==beforeReset.vram_hash||
    afterReset.palette_hash==beforeReset.palette_hash||
    afterReset.oam_hash==beforeReset.oam_hash||
    afterReset.vram_changes<=beforeReset.vram_changes||
    afterReset.palette_changes<=beforeReset.palette_changes||
    afterReset.oam_changes<=beforeReset.oam_changes)return 7;
 r.advanceCycles(280896u);
 if(r.videoSamples().size()!=2u||r.videoSamples()[1].frame!=2u||
    r.videoSamples()[1].cycles!=478016u)return 4;
 r.reset();
 if(!r.videoSamples().empty()||r.currentVideoSample().vram_changes||
    r.currentVideoSample().dma3_transfers)return 5;
 r.advanceCycles(160u*1232u);
 if(!r.videoSamples().empty())return 6;
 std::cout<<"Video sample FNV, IO/palette/VRAM/OAM mutations, DMA3 and VBlank PASS\n";
}
)CPP";
  write_file(out_dir/"tests/video_state_test.cpp",videoTest);
  const char* videoBusTest=R"BUSCPP(#include "gba_runtime.hpp"
#include <iostream>
int main(){
 GbaRuntime r;r.reset();
 // 8-bit CPU stores to palette/background video RAM duplicate the byte.
 r.write8(0x05000001u,0x12u);
 if(r.read16(0x05000000u)!=0x1212u||r.read16(0x05000400u)!=0x1212u)return 1;
 r.write8(0x06000003u,0x34u);
 if(r.read16(0x06000002u)!=0x3434u)return 2;
 r.write16(0x06000002u,0x5678u);
 if(r.read16(0x06000002u)!=0x5678u)return 3;
 // Tile OBJ VRAM and OAM ignore STRB even when using mirror aliases.
 r.write16(0x06010000u,0x9ABCu);r.write8(0x06018000u,0xFFu);
 if(r.read16(0x06018000u)!=0x9ABCu)return 4;
 r.write16(0x07000000u,0x1234u);r.write8(0x07000400u,0xEEu);
 if(r.read16(0x07000000u)!=0x1234u)return 5;
 // Bitmap mode permits 8-bit writes to BG VRAM below 0x14000 only.
 r.write16(0x04000000u,3u);
 r.write8(0x06013FFFu,0x56u);
 if(r.read16(0x06013FFEu)!=0x5656u)return 6;
 r.write16(0x06014000u,0x789Au);r.write8(0x0601C000u,0x99u);
 if(r.read16(0x06014000u)!=0x789Au)return 7;
 r.write16(0x06018000u,0x5678u);
 if(r.read16(0x06010000u)!=0x5678u)return 8;
 // DMA16/32 must NOT be subject to the CPU's STRB policy.
 r.write32(0x02000000u,0x11223344u);
 r.write32(0x040000D4u,0x02000000u);r.write32(0x040000D8u,0x07000000u);
 r.write32(0x040000DCu,0x84000001u); // DMA3 immediate word
 if(r.read32(0x07000000u)!=0x11223344u)return 9;
 // LZ77 BIOS VRAM SWI must pack two decompressed bytes into one halfword.
 r.write8(0x02000100u,0x10u);r.write8(0x02000101u,3u);
 r.write8(0x02000104u,0u);r.write8(0x02000105u,0x21u);
 r.write8(0x02000106u,0x43u);r.write8(0x02000107u,0x65u);
 r.reg(0)=0x02000100u;r.reg(1)=0x06000010u;r.swi(0x12u);
 if(r.read16(0x06000010u)!=0x4321u||r.read16(0x06000012u)!=0x0065u)return 10;
 std::cout<<"GBA video bus byte width, mirroring, DMA, LZ77 VRAM PASS\n";
}
)BUSCPP";
  write_file(out_dir/"tests/video_bus_test.cpp",videoBusTest);

  const char* frameTest=R"CPP(#include "gba_runtime.hpp"
#include <iostream>
int main(){
    GbaRuntime r;r.reset();
    r.write16(0x05000000u,0x001Fu); // Backdrop red
    r.write16(0x04000000u,0x0003u|0x0400u); // BG2, mode 3
    r.write16(0x04000020u,0x0100u);r.write16(0x04000026u,0x0100u); // BG2 identity on hardware
    r.write16(0x06000000u,0x03E0u); // First pixel green
    r.enableFrameCapture({1,2});r.advanceCycles(197120u);
    if(r.frameCaptures().size()!=1u)return 1;
    const auto& f=r.frameCaptures().front().image;
    if(f.mode!=3u||f.rgb[0]!=0||f.rgb[1]!=255||f.rgb[2]!=0)return 2;
    if(f.rgb[3]!=0||f.rgb[4]!=0||f.rgb[5]!=0)return 3;
    if(!gba_ppu::writePng("ppu-frame-selftest.png",f))return 4;
    // Text BG0 + palette entry + mapped 4bpp tile.
    r.reset();r.write16(0x04000000u,0x0100u);r.write16(0x04000008u,0x1F00u); // BG0 screenblock 31
    r.write16(0x05000002u,0x7C00u); // BG palette index 1 blue
    r.write16(0x06000000u,0x0001u); // Pixel zero has index 1
    r.enableFrameCapture({1});r.advanceCycles(197120u);
    if(r.frameCaptures().size()!=1u)return 5;
    const auto& t=r.frameCaptures()[0].image;
    if(t.rgb[0]!=0||t.rgb[1]!=0||t.rgb[2]!=255)return 6;
    r.reset();r.write16(0x04000000u,0x0083u); // Forced blank
    r.enableFrameCapture({1});r.advanceCycles(197120u);
    const auto& white=r.frameCaptures()[0].image;
    if(white.rgb[0]!=255||white.rgb[1]!=255||white.rgb[2]!=255)return 7;
    // Mode 1 affine BG2: identity transform, screenblock 31, tile 1, palette 2.
    r.reset();r.write16(0x04000000u,0x0401u);
    r.write16(0x0400000Cu,0x1F00u);r.write16(0x04000020u,0x0100u);r.write16(0x04000026u,0x0100u);
    r.write16(0x0600F800u,1u);r.write16(0x06000040u,2u);
    r.write16(0x05000004u,0x03E0u);
    r.enableFrameCapture({1});r.advanceCycles(197120u);
    const auto& affine=r.frameCaptures()[0].image;
    if(affine.mode!=1u||affine.rgb[0]!=0||affine.rgb[1]!=255||affine.rgb[2]!=0)return 8;
    // OBJ mapping 1D, palette bank, tile 0, 4bpp.
    r.reset();r.write16(0x04000000u,0x1040u);
    r.write16(0x05000202u,0x001Fu);r.write16(0x06010000u,1u);
    r.enableFrameCapture({1});r.advanceCycles(197120u);
    const auto& obj=r.frameCaptures()[0].image;
    if(obj.rgb[0]!=255||obj.rgb[1]!=0||obj.rgb[2]!=0)return 9;
    std::cout<<"PPU bitmap3/text4/affine BG2/OBJ 1D/forced blank capture PASS\n";
}
)CPP";
  write_file(out_dir/"tests/ppu_frame_test.cpp",frameTest);
  const char* ppuEffectsTest=R"CPP(#include "gba_ppu_renderer.hpp"
#include <array>
#include <cstdint>
#include <iostream>
namespace {
template<size_t N> void w16(std::array<uint8_t,N>& v,size_t at,uint16_t x){v[at]=uint8_t(x);v[at+1]=uint8_t(x>>8);}
bool eq(const gba_ppu::Frame& f,int x,int y,int r,int g,int b){size_t k=(size_t(y)*240+x)*3;return f.rgb[k]==r&&f.rgb[k+1]==g&&f.rgb[k+2]==b;}
}
int main(){
 std::array<uint8_t,0x60> io{};std::array<uint8_t,1024> pal{};std::array<uint8_t,0x18000> vr{};std::array<uint8_t,1024> oam{};
 w16(io,0x20,0x0100);w16(io,0x26,0x0100); // BG2 identity
 w16(pal,0,0x001f); // backdrop red
 w16(io,0,0x0403); // mode 3 BG2
 w16(vr,0,0x03e0);w16(vr,2,0x03e0); // green screen at first two pixels
 const auto capture=[&](){return gba_ppu::render(io.data(),pal.data(),vr.data(),oam.data());};
 if(!eq(capture(),0,0,0,255,0))return 1;
 w16(io,0x50,0x2044); // BG2 target1, backdrop target2, alpha mode
 w16(io,0x52,0x0808); // 8/16 + 8/16
 if(!eq(capture(),0,0,123,123,0))return 2;
 w16(io,0x50,0x0084);w16(io,0x54,16); // BG2 target1, brighten by 16
 if(!eq(capture(),0,0,255,255,255))return 3;
 w16(io,0x50,0x00c4); // darken
 if(!eq(capture(),0,0,0,0,0))return 4;
 w16(io,0x50,0);
 w16(io,0,0x2403); // WIN0 + mode 3 BG2
 w16(io,0x40,0x0001);w16(io,0x44,0x0001); // WIN0 only pixel (0,0)
 w16(io,0x48,0x0004);w16(io,0x4a,0x0000);
 if(!eq(capture(),0,0,0,255,0)||!eq(capture(),1,0,255,0,0))return 5;
 w16(io,0,0x6403); // WIN0 and WIN1; WIN0 takes precedence
 w16(io,0x42,0x0002);w16(io,0x46,0x0001);
 w16(io,0x48,0x0400); // BG2 allowed only in WIN1
 if(!eq(capture(),0,0,255,0,0)||!eq(capture(),1,0,0,255,0))return 6;
 w16(io,0,0x2403);w16(io,0x48,0x0004);w16(io,0x4a,0x0024);
 w16(io,0x50,0x0084);w16(io,0x54,16); // effect allowed outside, masked in WIN0
 if(!eq(capture(),0,0,0,255,0)||!eq(capture(),1,0,255,255,255))return 7;
 // Semitransparent OBJ in GBA bitmap mode: OBJ VRAM begins at tile 512.
 io.fill(0);oam.fill(0);w16(io,0x20,0x0100);w16(io,0x26,0x0100);w16(io,0,0x1443); // mode 3, BG2, OBJ, OBJ 1D
 w16(pal,514,0x001f);w16(vr,0x14000,0x0001); // OBJ palette index 1, red
 w16(oam,0,0x0400);w16(oam,2,0);w16(oam,4,512); // semi-transparent OBJ tile 512
 w16(io,0x50,0x0400);w16(io,0x52,0x0808); // BG2 is second target
 if(!eq(capture(),0,0,123,123,0))return 8;
 w16(vr,0x14000,0x0000); // Transparent OBJ restores BG
 if(!eq(capture(),0,0,0,255,0))return 9;
 std::cout<<"GBA PPU windows, BG/OBJ priority, alpha, brightness and semitransparent OBJ PASS\n";
}
)CPP";
  write_file(out_dir/"tests/ppu_effects_test.cpp",ppuEffectsTest);
  const char* ppuObjLayerTest=R"OBLCPP(#include "gba_ppu_renderer.hpp"
#include <array>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <vector>
static void wr(uint8_t* p,size_t at,uint16_t x){p[at]=uint8_t(x);p[at+1]=uint8_t(x>>8);}
static bool pixelIs(const gba_ppu::Frame& f,unsigned x,unsigned y,unsigned r,unsigned g,unsigned b){
    size_t k=(size_t(y)*240u+x)*3u;
    return f.rgb[k]==r&&f.rgb[k+1]==g&&f.rgb[k+2]==b;
}
int main(){
    std::array<uint8_t,0x60> io{};
    std::array<uint8_t,0x400> palette{},oam{};
    std::array<uint8_t,0x18000> vram{};
    wr(io.data(),0,0x1043u); // Bitmap mode 3, OBJ, 1-D sprites, BG disabled
    wr(palette.data(),0,0x03E0u); // green backdrop
    wr(palette.data(),0x202,0x001Fu); // red sprite index 1
    wr(palette.data(),0x204,0x7C00u); // blue sprite index 2
    wr(io.data(),0x52,0x0808u); // 50% foreground + 50% second target
    wr(oam.data(),0,0x0400u);wr(oam.data(),2,0);wr(oam.data(),4,512u); // OAM 0: semi red
    wr(oam.data(),8,0);wr(oam.data(),10,0);wr(oam.data(),12,513u);  // OAM 1: blue, directly behind
    wr(vram.data(),0x14000,0x1111u);
    wr(vram.data(),0x14020,0x2222u);
    wr(vram.data(),0x14004,0x1111u);wr(vram.data(),0x14024,0x2222u);
    auto render=[&](){return gba_ppu::render(io.data(),palette.data(),vram.data(),oam.data());};
    // The lower OBJ cannot serve as the second blending target (GBATEK).
    wr(io.data(),0x50,0x1000u); // second target OBJ only
    if(!pixelIs(render(),0,0,255,0,0))return 1;
    wr(io.data(),0x50,0x2000u); // second target backdrop only
    if(!pixelIs(render(),0,0,123,123,0))return 2;
    // Background outranks the OBJ. Only the winner of the OBJ layer can
    // contribute as the second target behind the foreground BG.
    wr(io.data(),0,0x1443u); // enable BG2
    wr(io.data(),0x20,0x0100u);wr(io.data(),0x26,0x0100u);
    wr(vram.data(),0,0x03E0u); // green BG2 pixel
    wr(oam.data(),4,512u|(2u<<10)); // first OBJ behind BG2
    wr(oam.data(),12,513u|(3u<<10));
    wr(io.data(),0x50,0x1044u); // BG2 first + OBJ second + alpha
    if(!pixelIs(render(),0,0,123,123,0))return 3;
    // Per-line OAM snapshots can switch the winning OBJ without stale pixels.
    wr(io.data(),0,0x1043u); // back to no BG2
    wr(io.data(),0x50,0); // plain colors
    std::vector<uint8_t> lines(160u*0x400u,0);
    for(unsigned y=0;y<160u;++y)std::copy(oam.begin(),oam.end(),lines.data()+size_t(y)*0x400u);
    wr(lines.data(),4,512u); // top red, first scanline
    wr(lines.data(),12,513u); // lower blue
    wr(lines.data()+0x400u,0,0x0200u); // top red disabled on line 1
    wr(lines.data()+0x400u,12,513u); // blue visible (still priority 3)
    auto raster=gba_ppu::render(io.data(),palette.data(),vram.data(),oam.data(),nullptr,nullptr,nullptr,lines.data());
    if(!pixelIs(raster,0,0,255,0,0)||!pixelIs(raster,0,1,0,0,255))return 4;
    std::cout<<"Only highest visible OBJ participates in blending and raster pass\n";
}
)OBLCPP";
  write_file(out_dir/"tests/ppu_obj_layer_test.cpp",ppuObjLayerTest);
  const char* ppuObjTest=R"OBJTEST(#include "gba_ppu_renderer.hpp"
#include <array>
#include <cstdint>
#include <iostream>
namespace {
template<size_t N> void wr(std::array<uint8_t,N>& a,size_t n,uint16_t v){a[n]=uint8_t(v);a[n+1]=uint8_t(v>>8);}
bool rgb(const gba_ppu::Frame& f,int x,int y,int r,int g,int b){const size_t at=(size_t(y)*240u+size_t(x))*3u;return f.rgb[at]==r&&f.rgb[at+1]==g&&f.rgb[at+2]==b;}
}
int main(){
    std::array<uint8_t,0x60> io{};
    std::array<uint8_t,1024> pal{};
    std::array<uint8_t,0x18000> vr{};
    std::array<uint8_t,1024> oam{};
    wr(io,0x20,0x0100);wr(io,0x26,0x0100);
    const auto render=[&](){return gba_ppu::render(io.data(),pal.data(),vr.data(),oam.data());};
    wr(pal,0,0x001f); // red backdrop
    wr(vr,0,0x03e0);wr(vr,2,0x03e0);wr(vr,4,0x03e0); // green bitmap3 BG2 pixels 0,1,2
    wr(io,0,0x9443); // OBJWIN, OBJ, BG2, OBJ 1D, mode3
    wr(io,0x4a,0x0400); // only OBJ-window pixels may show BG2
    wr(oam,0,0x0800); // OBJ mode 2: window, not color
    wr(oam,2,0);wr(oam,4,512); // tile 512: bitmap-mode OBJ base
    wr(vr,0x14000,0x0011); // two opaque indices for pixels 0,1
    if(!rgb(render(),0,0,0,255,0)||!rgb(render(),1,0,0,255,0)||!rgb(render(),2,0,255,0,0))return 1;
    // Transparent pixels must not create an OBJ window; OBJWIN disabled by DISPCNT must suppress it.
    wr(vr,0x14000,0x0001);
    if(!rgb(render(),1,0,255,0,0))return 2;
    wr(io,0,0x1443);
    if(!rgb(render(),0,0,0,255,0))return 3; // without windows, BG2 always visible
    // WIN0 wins over OBJWIN at overlapping pixels, even if WIN0 masks BG2 out.
    wr(io,0,0xB443);wr(io,0x40,0x0001);wr(io,0x44,0x0001);wr(io,0x48,0);
    wr(vr,0x14000,0x0011);
    if(!rgb(render(),0,0,255,0,0))return 4;
    wr(io,0x40,0x0102);
    if(!rgb(render(),0,0,0,255,0)||!rgb(render(),1,0,255,0,0))return 5;
    // Mosaic applies to BG samples, not the window geometry: BG mode3 first green and next red.
    io.fill(0);oam.fill(0);vr.fill(0);wr(io,0x20,0x0100);wr(io,0x26,0x0100);
    wr(io,0,0x0403);wr(io,0x0c,0x0040);wr(io,0x4c,0x0011); // 2x2 BG mosaic
    wr(vr,0,0x03e0);wr(vr,2,0x001f);
    if(!rgb(render(),1,0,0,255,0)||!rgb(render(),0,1,0,255,0))return 6;
    wr(io,0x0c,0);
    if(!rgb(render(),1,0,255,0,0))return 7;
    // Sprite OBJ mosaic: source (1,0) and (0,1) inherit upper-left pixel.
    io.fill(0);oam.fill(0);vr.fill(0);wr(io,0x20,0x0100);wr(io,0x26,0x0100);
    wr(io,0,0x1043);wr(io,0x4c,0x1100);wr(pal,514,0x03e0);
    wr(oam,0,0x1000);wr(oam,2,0);wr(oam,4,512);
    vr[0x14000]=1;
    if(!rgb(render(),1,0,0,255,0)||!rgb(render(),0,1,0,255,0))return 8;
    wr(oam,0,0);
    if(!rgb(render(),1,0,255,0,0))return 9;
    // Affine OBJ identity matrix from OAM parameter gaps.
    oam.fill(0);wr(oam,0,0x0100);wr(oam,2,0);wr(oam,4,512);
    wr(oam,6,256);wr(oam,14,0);wr(oam,22,0);wr(oam,30,256);
    if(!rgb(render(),0,0,0,255,0)||!rgb(render(),1,0,255,0,0))return 10;
    // Double-size affine canvas displays source upper-left at (4,4), not at (0,0).
    wr(oam,0,0x0300);
    if(!rgb(render(),4,4,0,255,0)||!rgb(render(),0,0,255,0,0))return 11;
    // Affine OBJ window: nontransparent matrix-sampled pixel enables BG2.
    wr(io,0,0x9443);wr(io,0x4a,0x0400);wr(oam,0,0x0B00); // affine double-size + OBJWIN
    if(!rgb(render(),4,4,0,0,0))return 12; // BG2 bitmap is 0, so black when unmasked
    if(!rgb(render(),0,0,255,0,0))return 13; // backdrop outside OBJ window
    // Disable affine by requesting a shape=3 OBJ: no color, no phantom window.
    wr(oam,0,0xCB00);
    if(!rgb(render(),4,4,255,0,0))return 14;
    // Exhaustive screen X and selected Y coverage, including wrapped coordinates,
    // affine double-size, the disabled bit and invalid shapes. Span pruning must
    // NEVER omit a source pixel that objPixel() could have returned.
    for(unsigned shape=0;shape<4;shape++)for(unsigned size=0;size<4;size++)
      for(unsigned affineState=0;affineState<4;affineState++)
        for(unsigned ox=0;ox<512;ox++){
        const unsigned base0=(shape<<14)|(affineState<<8);
        const unsigned base1=(size<<14)|ox;
        wr(oam,0,base0);wr(oam,2,base1);
        for(unsigned oy:{0u,7u,120u,220u,248u,255u}){
          wr(oam,0,base0|oy);
          for(unsigned row:{0u,1u,7u,31u,80u,127u,159u}){
            unsigned from=99,to=99;
            const bool has=gba_ppu::objVisibleSpan(oam.data(),0,row,from,to);
            const bool aff=(base0&0x100u)!=0;
            const bool enabled=shape!=3u&&(aff||(base0&0x200u)==0);
            const unsigned w=shape==3u?0u:gba_ppu::kObjDims[shape][size][0];
            const unsigned h=shape==3u?0u:gba_ppu::kObjDims[shape][size][1];
            const unsigned width=w*((aff&&(base0&0x200u))?2u:1u);
            const unsigned height=h*((aff&&(base0&0x200u))?2u:1u);
            const bool validY=((row+256u-oy)&255u)<height;
            bool any=false;
            for(unsigned x=0;x<240u;x++){
                const bool expect=enabled&&validY&&(((x+512u-ox)&511u)<width);
                const bool actual=has&&from<=x&&x<to;
                if(expect!=actual){std::cerr<<"OBJ clipped span disagreement shape="<<shape<<" size="<<size<<" x="<<ox<<" y="<<oy<<" row="<<row<<" scan="<<x<<"\n";return 15;}
                any|=expect;
            }
            if(any!=has)return 16;
          }
        }
      }
    std::cout<<"PPU OBJWIN transparency/priority, BG/OBJ mosaic, affine and double-size OBJ PASS\n";
}
)OBJTEST";
  write_file(out_dir/"tests/ppu_obj_window_test.cpp",ppuObjTest);
  const char* rasterTest=R"RASTER(#include "gba_ppu_renderer.hpp"
#include <array>
#include <algorithm>
#include <cstdint>
#include <iostream>
static void wr(uint8_t* a,unsigned off,uint16_t v){a[off]=uint8_t(v);a[off+1]=uint8_t(v>>8);}
static bool rgb(const gba_ppu::Frame& f,int x,int y,int r,int g,int b){size_t p=(size_t(y)*240u+size_t(x))*3u;return f.rgb[p]==r&&f.rgb[p+1]==g&&f.rgb[p+2]==b;}
int main(){
 std::array<uint8_t,0x60> io{};std::array<uint8_t,1024> pal{};
 std::array<uint8_t,0x18000> vr{};std::array<uint8_t,1024> oam{};
 std::array<uint8_t,160u*0x60u> scan{};
 wr(io.data(),0x20,0x0100);wr(io.data(),0x26,0x0100);
 wr(io.data(),0,0x0403);wr(pal.data(),0,0x001f); // red backdrop
 wr(vr.data(),0,0x03e0);wr(vr.data(),480,0x03e0); // green at (0,0),(0,1)
 for(unsigned y=0;y<160u;++y)std::copy(io.begin(),io.end(),scan.begin()+size_t(y)*0x60u);
 auto render=[&](){return gba_ppu::render(io.data(),pal.data(),vr.data(),oam.data(),scan.data());};
 if(gba_ppu::fingerprint(render())!=gba_ppu::fingerprint(gba_ppu::render(io.data(),pal.data(),vr.data(),oam.data())))return 1;
 wr(scan.data(),0,0x0003); // disable BG2 on first line
 if(!rgb(render(),0,0,255,0,0)||!rgb(render(),0,1,0,255,0))return 2;
 wr(scan.data(),0,0x0483); // forced blank on first line
 if(!rgb(render(),0,0,255,255,255)||!rgb(render(),0,1,0,255,0))return 3;
 wr(scan.data(),0,0x0403);
 wr(scan.data()+0x60u,0x50,0x0084); // BG2 first target, brightness increase
 wr(scan.data()+0x60u,0x54,16u);
 if(!rgb(render(),0,0,0,255,0)||!rgb(render(),0,1,255,255,255))return 4;
 std::array<uint8_t,160u*1024u> rowPal{};
 for(unsigned y=0;y<160u;++y)std::copy(pal.begin(),pal.end(),rowPal.begin()+size_t(y)*1024u);
 auto paletteRender=[&](){return gba_ppu::render(io.data(),pal.data(),vr.data(),oam.data(),scan.data(),rowPal.data());};
 if(gba_ppu::fingerprint(paletteRender())!=gba_ppu::fingerprint(render()))return 5;
 // Per-line backdrop: the VBlank palette differs from the first two HBlank snapshots.
 wr(io.data(),0,0x0003);
 for(unsigned y=0;y<160u;++y)wr(scan.data()+size_t(y)*0x60u,0,0x0003);
 wr(rowPal.data(),0,0x7C00); // blue on line 0
 wr(rowPal.data()+1024u,0,0x03E0); // green on line 1
 if(!rgb(paletteRender(),0,0,0,0,255)||!rgb(paletteRender(),0,1,0,255,0))return 6;
 if(!rgb(render(),0,0,255,0,0)||!rgb(render(),0,1,255,0,0))return 7;
 // Per-line indexed background palette, not only the backdrop.
 wr(io.data(),0,0x0404); // mode 4, BG2
 for(unsigned y=0;y<160u;++y){wr(scan.data()+size_t(y)*0x60u,0,0x0404);wr(scan.data()+size_t(y)*0x60u,0x50,0);}
 vr[0]=1;vr[240]=1;
 wr(pal.data(),2,0x001F); // VBlank pixel would be red
 wr(rowPal.data(),2,0x7C00);wr(rowPal.data()+1024u,2,0x03E0);
 if(!rgb(paletteRender(),0,0,0,0,255)||!rgb(paletteRender(),0,1,0,255,0))return 8;
 // In bitmap modes, the first OBJ tile is mapped after 0x14000.
 wr(io.data(),0,0x1404);
 for(unsigned y=0;y<160u;++y)wr(scan.data()+size_t(y)*0x60u,0,0x1404);
 wr(oam.data(),4,0x0200); // OBJ #0 4bpp tile 512, size 8x8 at (0,0)
 vr[0x14000u]=0x11;vr[0x14004u]=0x11;
 wr(rowPal.data(),0x202u,0x03E0); // green sprite pixel on row 0
 wr(rowPal.data()+1024u,0x202u,0x7C00); // blue sprite pixel on row 1
 if(!rgb(paletteRender(),0,0,0,255,0)||!rgb(paletteRender(),0,1,0,0,255))return 9;

 // Per-line VRAM: mode 3 BG2 reads each scanline's own VRAM image, not VBlank VRAM.
 wr(io.data(),0,0x0403);
 for(unsigned y=0;y<160u;++y)wr(scan.data()+size_t(y)*0x60u,0,0x0403);
 std::vector<uint8_t> rowVr(160u*0x18000u,0);
 // Keep unchanged baseline rows red; snapshots at lines 0 and 1 are blue/green.
 wr(vr.data(),0,0x001F);wr(vr.data(),480u,0x001F);
 wr(rowVr.data(),0,0x7C00);wr(rowVr.data()+0x18000u,480u,0x03E0);
 auto vramRender=[&](){return gba_ppu::render(io.data(),pal.data(),vr.data(),oam.data(),scan.data(),rowPal.data(),rowVr.data());};
 if(!rgb(vramRender(),0,0,0,0,255)||!rgb(vramRender(),0,1,0,255,0))return 10;
 if(!rgb(render(),0,0,255,0,0)||!rgb(render(),0,1,255,0,0))return 11;
 // Per-line OAM: sprite is disabled on line 0 and enabled on line 1.
 // BG falls back to red; enabled sprite is blue and overlaps at x=0,y=1.
 wr(io.data(),0,0x1403);
 for(unsigned y=0;y<160u;++y)wr(scan.data()+size_t(y)*0x60u,0,0x1403);
 std::vector<uint8_t> rowOam(160u*0x400u,0);
 for(unsigned y=0;y<160u;++y){
   std::copy(oam.begin(),oam.end(),rowOam.begin()+size_t(y)*0x400u);
   wr(rowOam.data()+size_t(y)*0x400u,4,0x0200); // first OBJ tile 512
 }
 wr(oam.data(),0,0x0200); // VBlank OBJ disabled; snapshots differ
 wr(rowOam.data(),0,0x0200); // OBJ 0 disabled on line 0
 wr(rowOam.data()+0x400u,0,0x0000); // OBJ enabled on line 1
 wr(rowPal.data()+0x400u,0x202u,0x7C00); // blue OBJ
 wr(rowVr.data()+0x18000u,0x14004u,0x0011); // sprite pixel y=1
 auto oamRender=[&](){return gba_ppu::render(io.data(),pal.data(),vr.data(),oam.data(),scan.data(),rowPal.data(),rowVr.data(),rowOam.data());};
 if(!rgb(oamRender(),0,0,0,0,255)||!rgb(oamRender(),0,1,0,0,255))return 12;
 // Changed OAM must actually affect the frame; no fabricated equivalence.
 if(gba_ppu::fingerprint(oamRender())==gba_ppu::fingerprint(vramRender()))return 13;
 std::cout<<"Per-line registers, palette, VRAM and OAM snapshot PASS\n";
}
)RASTER";
  write_file(out_dir/"tests/ppu_raster_test.cpp",rasterTest);


  const char* bitmapAffineTest=R"BITMAPAFFINE(#include "gba_ppu_renderer.hpp"
#include <array>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <vector>
static void wr16(uint8_t* p,unsigned a,uint16_t v){p[a]=uint8_t(v);p[a+1]=uint8_t(v>>8);}
static void wr32(uint8_t* p,unsigned a,uint32_t v){for(int i=0;i<4;i++)p[a+unsigned(i)]=uint8_t(v>>(i*8));}
static bool col(const gba_ppu::Frame& f,unsigned x,unsigned y,int r,int g,int b){size_t i=(size_t(y)*240+x)*3;return f.rgb[i]==r&&f.rgb[i+1]==g&&f.rgb[i+2]==b;}
int main(){
 using gba_ppu::render;
 std::array<uint8_t,0x60> io{};std::array<uint8_t,1024> pal{};
 std::array<uint8_t,0x18000> vr{};std::array<uint8_t,1024> oam{};
 const auto reset=[&](unsigned mode){io.fill(0);pal.fill(0);vr.fill(0);oam.fill(0);wr16(io.data(),0,uint16_t(0x0400u|mode));wr16(io.data(),0x20,256);wr16(io.data(),0x26,256);wr16(pal.data(),0,0x7C1Fu);};
 const auto run=[&](){return render(io.data(),pal.data(),vr.data(),oam.data());};
 #define CHECK(e) do{if(!(e)){std::cerr<<"Bitmap affine failed at line "<<__LINE__<<": "<<#e<<'\n';return 1;}}while(0)
 // Mode 3 (15-bit direct color): identity, translation, negative clipping,
 // scaling by 2, and a 90-degree rotation with a shifted reference origin.
 reset(3);wr16(vr.data(),0,0x03E0);wr16(vr.data(),2,0x7C00);wr16(vr.data(),4,0x001F);
 wr16(vr.data(),480,0x001F);
 CHECK(col(run(),0,0,0,255,0)&&col(run(),1,0,0,0,255));
 wr32(io.data(),0x28,256);CHECK(col(run(),0,0,0,0,255));
 wr32(io.data(),0x28,uint32_t(-256));CHECK(col(run(),0,0,255,0,255));
 wr32(io.data(),0x28,0);wr16(io.data(),0x20,512);wr16(io.data(),0x26,512);
 CHECK(col(run(),1,0,255,0,0));
 wr16(io.data(),0x20,0);wr16(io.data(),0x22,256);wr16(io.data(),0x24,uint16_t(-256));wr16(io.data(),0x26,0);wr32(io.data(),0x2C,256);
 CHECK(col(run(),0,0,255,0,0)&&col(run(),1,0,0,255,0));
 // Mode 4 page selection after affine mapping. Keep the palette stable and
 // select x=1 source on screen x=0, including page 1.
 reset(4);wr16(pal.data(),2,0x7C00);wr16(pal.data(),4,0x03E0);
 vr[1]=1;vr[0xA000+1]=2;wr32(io.data(),0x28,256);
 CHECK(col(run(),0,0,0,0,255));wr16(io.data(),0,0x0414);
 CHECK(col(run(),0,0,0,255,0));
 // Mode 5: physical bitmap is 160x128, regardless of bit 13 wrapping.
 reset(5);wr16(io.data(),0x0C,0x2000);wr16(vr.data(),(127*160+159)*2,0x03E0);
 CHECK(col(run(),159,127,0,255,0));
 CHECK(col(run(),160,127,255,0,255));
 wr32(io.data(),0x28,uint32_t(-256));CHECK(col(run(),0,0,255,0,255));
 // HBlank scanline snapshots can carry a different affine reference X for
 // successive rows. The legacy VBlank register image remains unchanged.
 reset(3);wr16(vr.data(),0,0x03E0);wr16(vr.data(),2,0x7C00);
 wr16(vr.data(),480,0x03E0);wr16(vr.data(),482,0x001F);
 std::vector<uint8_t> rows(160u*0x60u);
 for(unsigned y=0;y<160;y++)std::copy(io.begin(),io.end(),rows.begin()+size_t(y)*0x60u);
 wr32(rows.data()+0x60u,0x28,256);
 auto frame=render(io.data(),pal.data(),vr.data(),oam.data(),rows.data());
 CHECK(col(frame,0,0,0,255,0)&&col(frame,0,1,255,0,0));
 CHECK(col(run(),0,1,0,255,0));
 std::cout<<"Bitmap BG2 affine modes 3/4/5, clipping, frame select, HBlank registers PASS\n";
}
)BITMAPAFFINE";
  write_file(out_dir/"tests/ppu_bitmap_affine_test.cpp",bitmapAffineTest);
  const char* irqTest=R"CPP(#include "gba_runtime.hpp"
#include <cstdint>
#include <iostream>
int main(){
 GbaRuntime r;r.reset();
 const auto check=[](bool b,int n){if(!b)std::cerr<<"IRQ regression "<<n<<'\n';return b;};
 // Reproduce the GBA crt0 setup of distinct system/IRQ stack registers.
 r.reg(13)=0x03007F00u;r.reg(14)=0x08001235u;
 r.writeCpsr(0x12u,1u);r.reg(13)=0x03007FA0u;r.reg(14)=0xDEADBEEFu;
 r.writeCpsr(0x1Fu,1u);
 if(!check(r.reg(13)==0x03007F00u&&r.reg(14)==0x08001235u,1))return 1;
 r.write16(0x04000200u,1u);r.write16(0x04000208u,1u);
 r.write16(0x04000004u,8u);
 r.advanceCycles(160u*1232u);
 if(!check(r.pendingIrq()==1u&&r.irqRequested(),2))return 2;
 uint32_t pc=0;
 if(!check(!r.enterBiosIrq(0x08001234u,true,pc)&&r.irqUnvectored()==1u,3))return 3;
 r.write32(0x03007FFCu,0x03000634u);
 if(!check(r.enterBiosIrq(0x08001234u,true,pc)&&pc==0x03000634u,4))return 4;
 if(!check(r.inBiosIrq()&&r.irqEntries()==1u&&(r.cpsr()&0xDFu)==0x92u,5))return 5;
 if(!check(r.spsrIrq()==0x3Fu&&r.reg(13)==0x03007F88u,6))return 6;
 if(!check(r.reg(14)==0x138u&&r.read32(0x03007F9Cu)==0x08001238u,7))return 7;
 if(!check(!r.irqRequested(),8))return 8;
 if(!check(!r.enterBiosIrq(0x08001238u,false,pc),9))return 9;
 // User handler acknowledges IF (W1C), then BX LR -> BIOS 0x138.
 r.write16(0x04000202u,1u);r.reg(0)=99u;r.reg(12)=88u;
 uint32_t resumed=0;bool thumb=false;
 if(!check(r.finishBiosIrq(resumed,thumb),10))return 10;
 if(!check(resumed==0x08001234u&&thumb&&r.irqReturns()==1u,11))return 11;
 if(!check(r.cpsr()==0x3Fu&&r.reg(13)==0x03007F00u&&r.reg(14)==0x08001235u,12))return 12;
 if(!check(r.reg(0)==0u&&r.reg(12)==0u&&r.pendingIrq()==0u,13))return 13;
 // IRQ masked at CPU level must not be delivered even with IE/IF/IME set.
 r.write16(0x04000200u,1u);r.write16(0x04000202u,0xFFFFu);
 r.write16(0x04000004u,8u);r.advanceCycles(280896u);
 r.writeCpsr(0x9Fu,1u);
 if(!check(!r.irqRequested()&&!r.enterBiosIrq(0x08001100u,true,pc),14))return 14;
 std::cout<<"ARM7 IRQ entry, banked LR/SP, SPSR, BIOS HLE and restore PASS\n";
 return 0;
}
)CPP";
  // The ACQE call adapter at 0x08039990 uses MOV r2,PC; ADD r2,#5;
  // MOV lr,r2; BX r1. Missing PC pipeline semantics turned the LR into 0x5.
  const char* pcTest=R"CPP(#include "gba_runtime.hpp"
#include "thumb_ops.hpp"
#include <iostream>
int main(){
 GbaRuntime r;r.reset();r.reg(15)=0u;
 ThumbOps::highOp(r,2,2,15,0x08039990u);
 if(r.reg(2)!=0x08039994u)return 1;
 ThumbOps::immOp(r,2,2,5u);
 ThumbOps::highOp(r,2,14,2,0x08039994u);
 if(r.reg(14)!=0x08039999u)return 2;
 r.reg(4)=12u;
 ThumbOps::highOp(r,0,4,15,0x08001002u);
 if(r.reg(4)!=0x08001012u)return 3;
 r.reg(5)=0x08001008u;
 ThumbOps::highOp(r,1,5,15,0x08001004u);
 if(!r.flagZ())return 4;
 // The actual ACQE block is address-specific and must compute the same LR.
 r.reg(0)=0u;r.reg(1)=0u;r.reg(2)=0x02000100u;
 r.reg(3)=0x02000200u;r.reg(13)=0x03007000u;
 r.write32(0x02000200u,0x02000300u);
 r.write32(0x02000344u,0x02000400u);
 const auto t=dispatch_native_block(r,0x08039982u,true);
 if(t.kind!=NativeTransferKind::Next || t.address!=0x02000400u || t.thumb || r.reg(14)!=0x08039999u)return 5;
 std::cout<<"Thumb PC pipeline and real ACQE indirect ARM handoff PASS\n";
 return 0;
}
)CPP";
  // Include transfer declarations in the generated test.
  std::string pcTestCode=pcTest;
  pcTestCode.insert(pcTestCode.find("#include <iostream>"),"#include \"native_blocks.hpp\"\n");
  // Only test ACQE-specific assembled instructions if these bytes and a lifted
  // block were actually found in this input ROM. Generic ROMs test PC semantics.
  const bool hasCrashAdapter=rom.bytes().size()>0x39998u &&
      rom.read16(0x39990u)==0x467Au && rom.read16(0x39992u)==0x3205u &&
      rom.read16(0x39994u)==0x4696u && rom.read16(0x39996u)==0x4708u &&
      std::any_of(report.cfg.blocks.begin(),report.cfg.blocks.end(),[](const auto& b){
        return b.mode==GbaCodeMode::Thumb && b.start==0x08039982u;});
  if(!hasCrashAdapter){
    const size_t start=pcTestCode.find(" // The actual ACQE block");
    const size_t end=pcTestCode.find(" std::cout<<",start);
    if(start!=std::string::npos&&end!=std::string::npos)pcTestCode.erase(start,end-start);
  }
  write_file(out_dir/"tests/thumb_pc_pipeline_test.cpp",pcTestCode);
  write_file(out_dir/"tests/irq_exception_test.cpp",irqTest);

  write_file(out_dir/"reports/compatibility-report.json",report_to_json(rom,report));write_file(out_dir/"reports/compatibility-report.txt",report_to_text(rom,report));
  std::ostringstream frontier;
  frontier<<"Port GBA Builder v2.8.0 - framebuffer capture + bitmap BG2 affine\n\n";
  frontier<<"Naive branch targets: "<<report.code_targets.size()<<"\n";
  frontier<<"Confirmed CFG blocks: "<<report.cfg.blocks.size()<<"\n";
  frontier<<"Confirmed function entries: "<<report.cfg.function_entries.size()<<"\n";
  frontier<<"Execution-observed roots (NOT direct-call proof): "<<report.cfg.profiled_roots.size()<<"\n";
  frontier<<"Recovered switch tables: "<<report.cfg.resolved_switch_tables<<" -> "<<report.cfg.resolved_switch_targets<<" targets\n";
  frontier<<"Compiler POP/BX returns: "<<report.cfg.compiler_epilogue_returns<<"\n";
  frontier<<"Dynamic call-via sites still runtime-dependent: "<<report.cfg.indirect_call_sites<<"\n";
  frontier<<"Generated native handlers: "<<(generatedArmBlocks+generatedThumbBlocks)<<" (ARM "<<generatedArmBlocks<<", Thumb "<<generatedThumbBlocks<<")\n";
  frontier<<"LZ10 streams: "<<report.lz10_streams.size()<<"\n\nConfirmed functions:\n";
  for(const auto& e:report.cfg.function_entries)frontier<<"0x"<<std::hex<<std::uppercase<<e.address<<std::dec<<" "<<(e.mode==GbaCodeMode::Thumb?"THUMB":"ARM")<<"\n";
  write_file(out_dir/"reports/native-frontier.txt",frontier.str());
  std::ostringstream tables;
  tables<<"ROM vtables rooted in reachable PC-relative literal loads\n"
        <<"These are method entrypoints, NOT a per-callsite target proof.\n"
        <<"Tables="<<report.cfg.rooted_function_tables.size()
        <<" slots="<<report.cfg.rooted_table_slots
        <<" distinct_methods="<<report.cfg.rooted_table_distinct_functions<<"\n\n";
  for(const auto& table:report.cfg.rooted_function_tables) {
    tables<<"table="<<hexu(table.address)<<" from_ldr="<<hexu(table.literal_reference)
          <<" slots="<<table.slots<<"\n";
    for(const auto& e:table.methods)tables<<"  THUMB "<<hexu(e.address)<<"\n";
  }
  write_file(out_dir/"reports/rom-vtables.txt",tables.str());
  std::ostringstream dyn;
  dyn<<"Dynamic GBA veneer callsites (never assume all methods are reachable from a given call)\n";
  size_t pending=0,found=0;
  for(const auto& block:report.cfg.blocks) {
    for(const auto& call:block.calls) {
      auto ven=std::find_if(report.cfg.indirect_veneer_stats.begin(),report.cfg.indirect_veneer_stats.end(),
        [&](const GbaIndirectVeneerStat& a){return a.address==call.address;});
      if(ven==report.cfg.indirect_veneer_stats.end())continue;
      const auto pc=block.instructions.size()>=2u?block.instructions[block.instructions.size()-2].address:block.start;
      dyn<<hexu(pc)<<" via="<<hexu(call.address)<<" target_register=r"<<unsigned(ven->register_index);
      if(block.resolved_dynamic_calls.empty()) {++pending;dyn<<" status=RUNTIME_DEPENDENT";}
      else {++found;dyn<<" status=STATIC_EXACT";for(const auto& dest:block.resolved_dynamic_calls)dyn<<" "<<hexu(dest.address);}
      dyn<<"\n";
    }
  }
  dyn<<"Summary: pending="<<pending<<" recovered="<<found
     <<" ROM_table_roots="<<report.cfg.rooted_function_tables.size()<<"\n";
  write_file(out_dir/"reports/dynamic-calls.txt",dyn.str());

  std::ostringstream constructorEvidence;
  constructorEvidence<<"Constructor stores of ROM-rooted GBA C++ vtable pointers\n"
      <<"Store evidence only; does not bind a callsite to an object.\n"
      <<"Count="<<report.cfg.vtable_installs.size()<<"\n";
  for(const auto& v:report.cfg.vtable_installs) constructorEvidence
      <<"store="<<hexu(v.instruction)<<" table="<<hexu(v.table_address)
      <<" object_offset="<<v.object_offset<<" base_reg=r"<<unsigned(v.base_register)<<"\n";
  write_file(out_dir/"reports/vtable-constructor-stores.txt",constructorEvidence.str());
  std::ostringstream virtualSites;
  virtualSites<<"Advisory virtual callsite load chains, not statically resolved targets\n"
      <<"Count="<<report.cfg.virtual_call_patterns.size()<<"\n";
  for(const auto& p:report.cfg.virtual_call_patterns) {
      virtualSites<<"call="<<hexu(p.callsite)<<" via="<<hexu(p.veneer)
          <<" target=r"<<unsigned(p.call_register)<<" object_offset="<<p.object_offset
          <<" method_slot_offset="<<p.slot_offset<<" candidate_tables="<<p.candidate_tables.size()
          <<" candidate_methods="<<p.candidate_methods.size()<<" crosses_blocks="<<(p.crosses_blocks?"YES":"NO")<<" status=CANDIDATE_ONLY\n";
      for(const auto addr:p.candidate_tables) virtualSites<<"  table="<<hexu(addr)<<"\n";
      for(const auto& e:p.candidate_methods) virtualSites<<"  method="<<hexu(e.address)<<"\n";
  }
  write_file(out_dir/"reports/virtual-call-candidates.txt",virtualSites.str());
  std::ostringstream callerReport;
  callerReport << "Direct caller -> constructor-function with vptr store (advisory, NOT instance proof)\n"
      << "Count=" << report.cfg.constructor_callers.size() << "\n";
  for(const auto& link:report.cfg.constructor_callers)
      callerReport<<"caller="<<hexu(link.callsite)<<" callee="<<hexu(link.callee_entry)
        <<" store="<<hexu(link.constructor_store)<<" table="<<hexu(link.table_address)
        <<" object_offset="<<link.object_offset<<" status=CALLGRAPH_ONLY\n";
  write_file(out_dir/"reports/constructor-callgraph.txt",callerReport.str());


  std::map<std::pair<uint16_t,uint16_t>,size_t> virtualClusters;
  for(const auto& p:report.cfg.virtual_call_patterns) ++virtualClusters[{p.object_offset,p.slot_offset}];
  std::vector<std::pair<std::pair<uint16_t,uint16_t>,size_t>> rankedClusters(virtualClusters.begin(),virtualClusters.end());
  std::sort(rankedClusters.begin(),rankedClusters.end(),[](const auto& a,const auto& b){
      if(a.second!=b.second)return a.second>b.second;
      return a.first<b.first;
  });
  std::ostringstream heat;
  heat<<"Virtual-call investigation priority, ranked by repeated (object field, method slot) pairs.\n"
      <<"NOT proof of object identity or a call target.\n";
  for(const auto& row:rankedClusters) heat<<"object_field="<<row.first.first
      <<" method_slot="<<row.first.second<<" callsites="<<row.second<<"\n";
  write_file(out_dir/"reports/virtual-dispatch-priority.txt",heat.str());


  std::ostringstream cfgReport;cfgReport<<cfg_to_text(report.cfg)<<"\nBlocks:\n";for(const auto& b:report.cfg.blocks){cfgReport<<"0x"<<std::hex<<std::uppercase<<b.start<<"-0x"<<b.end<<std::dec<<" "<<(b.mode==GbaCodeMode::Thumb?"THUMB":"ARM")<<" ins="<<b.instructions.size()<<" term="<<terminator_name(b.terminator)<<" succ="<<b.successors.size()<<" calls="<<b.calls.size()<<"\n";}write_file(out_dir/"reports/recursive-cfg.txt",cfgReport.str());

  // Never truncate the source ROM when generating into an existing project.
  // std::filesystem::equivalent also detects hardlinks/symlink aliases.
  const auto gameInput=out_dir/"input"/rom.path().filename();
  std::error_code equivError;
  const bool alreadySame=fs::exists(gameInput) && fs::equivalent(rom.path(),gameInput,equivError);
  if(equivError){error="Cannot identify ROM input path: "+equivError.message();return false;}
  if(!alreadySame){
    std::error_code copyError;
    fs::copy_file(rom.path(),gameInput,fs::copy_options::overwrite_existing,copyError);
    if(copyError){error="Cannot copy ROM into generated input/: "+copyError.message();return false;}
  }
  const char* bat=R"BAT(@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH.& pause& exit /b 1)
if not exist build mkdir build
cmake -S . -B build -A x64
if errorlevel 1 goto :fail
cmake --build build --config Release
if errorlevel 1 goto :fail
ctest --test-dir build -C Release --output-on-failure
if errorlevel 1 goto :fail
echo.
echo Build + runtime self-test concluidos.
echo EXE em build\Release\
pause
exit /b 0
:fail
echo.
echo Falha no build/teste.
pause
exit /b 1
)BAT";write_file(out_dir/"COMPILAR-WINDOWS.cmd",bat);
  const char* readme=R"TXT(Generated native-port foundation - Port GBA Builder v1.8.0

STATUS
- ROM/header audit: implemented
- ARM + Thumb branch-target discovery: implemented
- GBA pointer/memory-region profiling: implemented
- LZ10 candidate discovery: implemented
- Native C++ project generation: implemented
- GBA memory map: EWRAM/IWRAM/IO/Palette/VRAM/OAM/ROM/SRAM implemented
- BIOS SWIs: Div, Sqrt, CpuSet, CpuFastSet, LZ77UnCompWram/Vram foundation
- Generated runtime self-test: implemented
- Recursive entry-rooted CFG: implemented
- Static Thumb-1 native block lifting: implemented for confirmed Thumb blocks
- agbcc POP/BX return recovery: implemented
- Static switch/jump-table recovery: implemented
- ARM boot/static lifting: implemented for the cartridge boot bridge
- LCD/timers/IRQ and DMA3: event-based model; cycle cost is approximate, DMA0-2 and complete PPU/audio not validated
- --run N --video-evidence video.txt: ROM-bound per-VBlank FNV64 memory-state signatures, NOT rendered frames
- PPU composition of basic BG/OBJ modes: PARTIAL, framebuffer PNG export available; windows/blending/affine OBJ/cycle-accurate raster NOT YET VALIDATED
- ROM-free asset extraction: pending

This is not an emulator wrapper. The generated runtime is a compatibility scaffold used while code and assets are progressively lifted to native C++.
)TXT";write_file(out_dir/"README-GENERATED.txt",readme);
  return true;
 }catch(const std::exception&e){error=e.what();return false;}
}
