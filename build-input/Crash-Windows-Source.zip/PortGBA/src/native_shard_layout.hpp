#pragma once
#include <cstdint>
#include <iomanip>
#include <sstream>
#include <string>

namespace native_shards {
// ROM-address derived identity. Adding a root does not renumber other C++ units.
constexpr uint32_t kThumbAddressShift=11u; // 2048-byte ROM windows
constexpr uint32_t key(uint32_t romAddress){return romAddress>>kThumbAddressShift;}
inline std::string name(uint32_t page){
    std::ostringstream id;
    id<<"native_thumb_"<<std::hex<<std::setw(6)<<std::setfill('0')<<page;
    return id.str();
}
}
