#include "replay_audit.hpp"
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>
#include <stdexcept>
#include <vector>
namespace {
struct FrameRow { unsigned frame=0,mode=0,unsupported=0;uint64_t pixels=0;unsigned dispcnt=0; };
struct Manifest {uint64_t rom_hash=0;size_t rom_bytes=0;std::map<unsigned,FrameRow> rows;};
uint64_t number(const std::string& s) {
    if(s.empty())throw std::runtime_error("empty manifest number");
    size_t n=0;const auto v=std::stoull(s,&n,0);
    if(n!=s.size())throw std::runtime_error("malformed manifest number");
    return v;
}
std::vector<std::string> fields(const std::string& s){
    std::vector<std::string> out;std::istringstream in(s);std::string t;
    while(std::getline(in,t,'\t'))out.push_back(t);
    return out;
}
Manifest load(const std::filesystem::path& file){
    std::ifstream in(file);if(!in)throw std::runtime_error("cannot open frame manifest: "+file.string());
    std::string line;if(!std::getline(in,line))throw std::runtime_error("empty manifest");
    const auto hdr=fields(line);if(hdr.size()!=3||hdr[0]!="GBA_FRAME_V1"||hdr[1].rfind("rom_fnv=",0)!=0||hdr[2].rfind("rom_bytes=",0)!=0)
        throw std::runtime_error("invalid GBA_FRAME_V1 header");
    Manifest m;m.rom_hash=number(hdr[1].substr(8));m.rom_bytes=static_cast<size_t>(number(hdr[2].substr(10)));
    unsigned prior=0;
    while(std::getline(in,line)){
        const auto row=fields(line);
        if(row.size()!=6)throw std::runtime_error("invalid frame row (expected 6 columns)");
        const auto frame=number(row[0]),mode=number(row[1]),dispcnt=number(row[2]),pix=number(row[3]),unsupported=number(row[4]);
        if(frame==0||frame>10000000||frame<=prior||mode>5||dispcnt>65535||unsupported>1000000||row[5]!="vblank_"+row[0]+".png")
            throw std::runtime_error("invalid or unordered frame row");
        if(!std::filesystem::is_regular_file(file.parent_path()/row[5]))throw std::runtime_error("missing PNG: "+row[5]);
        FrameRow f;f.frame=static_cast<unsigned>(frame);f.mode=static_cast<unsigned>(mode);f.dispcnt=static_cast<unsigned>(dispcnt);f.pixels=pix;f.unsupported=static_cast<unsigned>(unsupported);
        m.rows.emplace(f.frame,f);prior=f.frame;
    }
    if(m.rows.empty())throw std::runtime_error("manifest has no frames");
    return m;
}
uint64_t fnv(const std::vector<uint8_t>& rom){uint64_t v=14695981039346656037ull;for(uint8_t b:rom){v^=b;v*=1099511628211ull;}return v;}
}
ReplayAuditResult audit_input_replay(const std::vector<uint8_t>& rom,const std::filesystem::path& base,const std::filesystem::path& active,unsigned first){
    ReplayAuditResult result;
    try{
        if(!first)throw std::runtime_error("first-input frame must be positive");
        const auto a=load(base),b=load(active);const auto hash=fnv(rom);
        if(hash!=a.rom_hash||hash!=b.rom_hash||rom.size()!=a.rom_bytes||rom.size()!=b.rom_bytes)
            throw std::runtime_error("frame manifests are not bound to the supplied ROM");
        if(a.rows.size()!=b.rows.size())throw std::runtime_error("captured frame sets differ");
        unsigned before=0,after=0,unchangedAfter=0;
        for(const auto& [id,reference]:a.rows){
            auto it=b.rows.find(id);if(it==b.rows.end())throw std::runtime_error("captured frame IDs differ");
            const auto& changed=it->second;
            if(reference.mode!=changed.mode||reference.dispcnt!=changed.dispcnt||reference.unsupported||changed.unsupported)
                throw std::runtime_error("frame mode or unsupported effects differ; visual input audit inconclusive");
            if(id<=first){
                if(reference.pixels!=changed.pixels)throw std::runtime_error("input effect occurred before the first scheduled input frame");
                ++before;
            } else if(reference.pixels!=changed.pixels)++after;
            else ++unchangedAfter;
        }
        if(!before||!after)throw std::runtime_error("no baseline frame or no visual effect after the scheduled input");
        result.valid=true;result.matching_before=before;result.divergent_after=after;result.matching_after=unchangedAfter;
        std::ostringstream out;out<<"INPUT_REPLAY_AUDIT PASS rom_fnv=0x"<<std::hex<<hash<<std::dec
           <<" first_input_frame="<<first<<" identical_before="<<before
           <<" different_after="<<after<<" identical_after="<<unchangedAfter
           <<" (frame-signature evidence, not proof of collisions or gameplay completion)";
        result.report=out.str();
    }catch(const std::exception& e){result.report=std::string("INPUT_REPLAY_AUDIT FAIL: ")+e.what();}
    return result;
}
