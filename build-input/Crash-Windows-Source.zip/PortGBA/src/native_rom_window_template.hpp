#pragma once
// This is a Windows-only preview of the GENERATED ARM/Thumb GBA runtime.
// It does NOT use a bespoke Crash menu or the manually reconstructed gameplay.
inline constexpr const char* kNativeRomWindowSource = R"ROMWIN(#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>
#include "gba_runtime.hpp"
#include "native_blocks.hpp"

namespace {
GbaRuntime gba;
std::vector<uint8_t> bgr(240u*160u*4u,0);
uint32_t pc=__ENTRY_PC__u;
bool thumb=false,halted=false;
uint16_t pressed=0;
uint64_t shownFrame=0;
HWND window=nullptr;
std::string state="Inicializando ROM...";

uint16_t buttonForKey(WPARAM key){
 switch(key){
 case 'Z': return 1u<<0;  // A
 case 'X': return 1u<<1;  // B
 case VK_BACK:return 1u<<2; // SELECT
 case VK_RETURN:return 1u<<3; // START
 case VK_RIGHT:return 1u<<4;
 case VK_LEFT:return 1u<<5;
 case VK_UP:return 1u<<6;
 case VK_DOWN:return 1u<<7;
 case 'A':return 1u<<9; // L
 case 'S':return 1u<<8; // R
 default:return 0;
 }
}
void setKeys(WPARAM key,bool down){
 const uint16_t bit=buttonForKey(key);
 if(!bit)return;
 if(down)pressed=uint16_t(pressed|bit);
 else pressed=uint16_t(pressed&~bit);
 gba.setKeysPressed(pressed);
}
void repaintImage(){
 const auto image=gba.renderPreview();
 for(size_t i=0;i<240u*160u;++i){
   bgr[i*4+0]=image.rgb[i*3+2];
   bgr[i*4+1]=image.rgb[i*3+1];
   bgr[i*4+2]=image.rgb[i*3];
   bgr[i*4+3]=0;
 }
 state="ROM original | frame "+std::to_string(shownFrame)+" | "+(halted?"BLOQUEIO DE TRADUCAO":"ARM/Thumb em execucao");
 SetWindowTextA(window,state.c_str());
 InvalidateRect(window,nullptr,FALSE);
}
LRESULT CALLBACK wndProc(HWND h,UINT message,WPARAM w,LPARAM l){
 switch(message){
 case WM_KEYDOWN:case WM_SYSKEYDOWN:setKeys(w,true);return 0;
 case WM_KEYUP:case WM_SYSKEYUP:setKeys(w,false);return 0;
 case WM_KILLFOCUS:pressed=0;gba.setKeysPressed(0);return 0;
 case WM_CLOSE:DestroyWindow(h);return 0;
 case WM_DESTROY:PostQuitMessage(0);return 0;
 case WM_ERASEBKGND:return 1;
 case WM_PAINT:{
   PAINTSTRUCT ps{};HDC dc=BeginPaint(h,&ps);
   RECT r{};GetClientRect(h,&r);
   BITMAPINFO bmi{};bmi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
   bmi.bmiHeader.biWidth=240;bmi.bmiHeader.biHeight=-160;
   bmi.bmiHeader.biPlanes=1;bmi.bmiHeader.biBitCount=32;
   bmi.bmiHeader.biCompression=BI_RGB;
   SetStretchBltMode(dc,COLORONCOLOR);
   StretchDIBits(dc,0,0,r.right,r.bottom,0,0,240,160,
                 bgr.data(),&bmi,DIB_RGB_COLORS,SRCCOPY);
   EndPaint(h,&ps);return 0;
 }
 }
 return DefWindowProcA(h,message,w,l);
}
} // namespace
int WINAPI WinMain(HINSTANCE instance,HINSTANCE,LPSTR,int show){
 std::string error;
 if(!gba.loadRom("input/__ROM_NAME__",error)){
    MessageBoxA(nullptr,error.c_str(),"ROM original - falha",MB_OK|MB_ICONERROR);return 2;
 }
 uint64_t hash=14695981039346656037ull;
 for(uint8_t byte:gba.rom()){hash^=byte;hash*=1099511628211ull;}
 if(hash!=__ROM_HASH__ull||gba.rom().size()!=__ROM_SIZE__u){
    MessageBoxA(nullptr,"Fingerprint da ROM diferente do codigo traduzido.","ROM original",MB_OK|MB_ICONERROR);return 4;
 }
 gba.reset();
 WNDCLASSA cls{};cls.lpfnWndProc=wndProc;cls.hInstance=instance;
 cls.hCursor=LoadCursorA(nullptr,IDC_ARROW);cls.lpszClassName="NativeRomGbaPreview";
 if(!RegisterClassA(&cls))return 3;
 window=CreateWindowA(cls.lpszClassName,"ROM original GBA",WS_OVERLAPPEDWINDOW,
          CW_USEDEFAULT,CW_USEDEFAULT,980,680,nullptr,nullptr,instance,nullptr);
 if(!window)return 3;
 ShowWindow(window,show);
 MSG msg{};bool alive=true;
 while(alive){
   while(PeekMessageA(&msg,nullptr,0,0,PM_REMOVE)){
     if(msg.message==WM_QUIT){alive=false;break;}
     TranslateMessage(&msg);DispatchMessageA(&msg);
   }
   if(!alive)break;
   if(halted){Sleep(16);continue;}
   const auto result=run_native_blocks(gba,pc,thumb,4000u);
   pc=result.pc;thumb=result.thumb;
   if(!result.supported){
       halted=true;state="BLOQUEIO PC=0x";
       char msgtext[120]{};
       wsprintfA(msgtext,"PC nao traduzido: 0x%08X (frame %u)",pc,unsigned(gba.vblankEvents()));
       SetWindowTextA(window,msgtext);
       repaintImage();
       MessageBoxA(window,msgtext,"ROM original - traducao incompleta",MB_OK|MB_ICONWARNING);
   }
   if(gba.vblankEvents()!=shownFrame){
       shownFrame=gba.vblankEvents();repaintImage();
   }
 }
 return 0;
}
)ROMWIN";
