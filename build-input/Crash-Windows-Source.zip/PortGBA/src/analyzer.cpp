#include "analyzer.hpp"
#include <algorithm>
#include <iomanip>
#include <set>
#include <sstream>

namespace {
constexpr uint32_t kRomBase = 0x08000000u;

std::string json_escape(const std::string& s) {
    std::ostringstream o;
    for (unsigned char c : s) {
        switch (c) {
            case '"': o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\n': o << "\\n"; break;
            case '\r': o << "\\r"; break;
            case '\t': o << "\\t"; break;
            default: if (c < 0x20) o << '?'; else o << static_cast<char>(c); break;
        }
    }
    return o.str();
}

bool in_range(uint32_t v, uint32_t lo, uint32_t hi) { return v >= lo && v <= hi; }

bool valid_lz10(const std::vector<uint8_t>& d, size_t start, Lz10Candidate& out) {
    if (start + 4 > d.size() || d[start] != 0x10) return false;
    const size_t target = size_t(d[start + 1]) | (size_t(d[start + 2]) << 8) | (size_t(d[start + 3]) << 16);
    if (!target || target > 8u * 1024u * 1024u) return false;
    size_t p = start + 4, produced = 0;
    while (produced < target) {
        if (p >= d.size()) return false;
        const uint8_t flags = d[p++];
        for (int bit = 7; bit >= 0 && produced < target; --bit) {
            if (flags & (1u << bit)) {
                if (p + 2 > d.size()) return false;
                const uint8_t a = d[p++], b = d[p++];
                const size_t count = (a >> 4) + 3u;
                const size_t distance = (size_t(a & 0x0F) << 8) + b + 1u;
                if (distance > produced) return false;
                produced += std::min(count, target - produced);
            } else {
                if (p >= d.size()) return false;
                ++p; ++produced;
            }
        }
    }
    out = {start, p - start, target};
    return true;
}

void add_code_target(std::set<uint32_t>& targets, uint32_t target, size_t rom_size) {
    if (target >= kRomBase && uint64_t(target - kRomBase) < rom_size) targets.insert(target & ~1u);
}
}

AnalysisReport analyze_rom(const GbaRom& rom) {
    AnalysisReport r;
    const auto& d = rom.bytes();
    r.rom_size = d.size();
    r.entry_word = rom.read32(0);
    std::set<uint32_t> targets;

    if ((r.entry_word & 0x0E000000u) == 0x0A000000u) {
        r.entry_looks_arm_branch = true;
        int32_t imm24 = static_cast<int32_t>(r.entry_word & 0x00FFFFFFu);
        if (imm24 & 0x00800000) imm24 |= static_cast<int32_t>(0xFF000000u);
        const int32_t disp = imm24 << 2;
        r.entry_target = static_cast<uint32_t>(kRomBase + 8u + disp);
        add_code_target(targets, r.entry_target, d.size());
    }

    for (size_t off = 0; off + 4 <= d.size(); off += 4) {
        const uint32_t w = rom.read32(off);
        const uint32_t addr = kRomBase + static_cast<uint32_t>(off);
        if ((w & 0x0E000000u) == 0x0A000000u && (w >> 28) != 0xFu) {
            ++r.arm_branch_candidates;
            if (w & 0x01000000u) ++r.arm_bl_candidates;
            int32_t imm24 = static_cast<int32_t>(w & 0x00FFFFFFu);
            if (imm24 & 0x00800000) imm24 |= static_cast<int32_t>(0xFF000000u);
            add_code_target(targets, static_cast<uint32_t>(int64_t(addr) + 8 + (int64_t(imm24) << 2)), d.size());
        }
        if ((w & 0x0FFFFFF0u) == 0x012FFF10u) ++r.arm_bx_candidates;
        if ((w & 0x0F000000u) == 0x0F000000u) ++r.arm_swi_candidates;

        if (in_range(w, 0x08000000u, 0x0DFFFFFFu)) ++r.rom_pointer_literals;
        else if (in_range(w, 0x02000000u, 0x0203FFFFu)) ++r.ewram_pointer_literals;
        else if (in_range(w, 0x03000000u, 0x03007FFFu)) ++r.iwram_pointer_literals;
        else if (in_range(w, 0x04000000u, 0x040003FFu)) {
            ++r.io_register_literals;
            if (in_range(w,0x04000000u,0x0400005Fu)) ++r.display_io_literals;
            if (in_range(w,0x04000060u,0x040000A7u)) ++r.sound_io_literals;
            if (in_range(w,0x040000B0u,0x040000DFu)) ++r.dma_io_literals;
            if (in_range(w,0x04000100u,0x0400010Fu)) ++r.timer_io_literals;
            if (in_range(w,0x04000130u,0x04000133u)) ++r.keypad_io_literals;
            if (in_range(w,0x04000200u,0x0400020Bu)) ++r.irq_io_literals;
        }
        else if (in_range(w, 0x05000000u, 0x050003FFu)) ++r.palette_pointer_literals;
        else if (in_range(w, 0x06000000u, 0x06017FFFu)) ++r.vram_pointer_literals;
        else if (in_range(w, 0x07000000u, 0x070003FFu)) ++r.oam_pointer_literals;
        else if (in_range(w, 0x0E000000u, 0x0E00FFFFu)) ++r.sram_pointer_literals;
    }

    for (size_t off = 0; off + 2 <= d.size(); off += 2) {
        const uint16_t h = rom.read16(off);
        const uint32_t addr = kRomBase + static_cast<uint32_t>(off);
        if ((h & 0xFF00u) == 0xDF00u) ++r.thumb_swi_candidates;
        if ((h & 0xF800u) == 0xE000u) {
            ++r.thumb_branch_candidates;
            int32_t disp = int32_t(h & 0x7FFu) << 1;
            if (disp & 0x800) disp |= ~0xFFF;
            add_code_target(targets, static_cast<uint32_t>(int64_t(addr) + 4 + disp), d.size());
        } else if ((h & 0xF000u) == 0xD000u && (h & 0x0F00u) != 0x0F00u && (h & 0x0F00u) != 0x0E00u) {
            ++r.thumb_branch_candidates;
            int32_t disp = int8_t(h & 0xFFu) << 1;
            add_code_target(targets, static_cast<uint32_t>(int64_t(addr) + 4 + disp), d.size());
        }
        if (off + 4 <= d.size() && (h & 0xF800u) == 0xF000u) {
            const uint16_t h2 = rom.read16(off + 2);
            if ((h2 & 0xF800u) == 0xF800u) {
                ++r.thumb_bl_candidates;
                int32_t high = int32_t(h & 0x7FFu) << 12;
                if (high & 0x400000) high |= ~0x7FFFFF;
                const int32_t low = int32_t(h2 & 0x7FFu) << 1;
                add_code_target(targets, static_cast<uint32_t>(int64_t(addr) + 4 + high + low), d.size());
            }
        }
    }

    size_t run = 0;
    for (uint8_t c : d) {
        if (c >= 32 && c <= 126) ++run;
        else { if (run >= 5) ++r.ascii_string_count; run = 0; }
    }
    if (run >= 5) ++r.ascii_string_count;

    for (size_t off = 0; off + 4 <= d.size(); off += 4) {
        if (d[off] != 0x10) continue;
        Lz10Candidate c;
        if (valid_lz10(d, off, c)) {
            r.lz10_streams.push_back(c);
            r.lz10_decompressed_bytes += c.decompressed_size;
        }
    }
    r.lz10_candidates = r.lz10_streams.size();
    r.code_targets.assign(targets.begin(), targets.end());
    if (r.entry_looks_arm_branch) r.cfg = build_recursive_cfg(rom, r.entry_target);

    const auto& h = rom.header();
    if (h.fixed_value != 0x96) r.warnings.emplace_back("Fixed value do header nao e 0x96.");
    if (!h.checksum_ok) r.warnings.emplace_back("Checksum do header nao confere.");
    if (!h.logo_signature_ok) r.warnings.emplace_back("Assinatura inicial do logo Nintendo nao confere.");
    if (!r.entry_looks_arm_branch) r.warnings.emplace_back("Primeira instrucao nao parece o branch ARM padrao de entrada.");
    if (r.code_targets.empty()) r.warnings.emplace_back("Nenhum alvo de branch dentro da ROM foi descoberto.");
    return r;
}

std::string report_to_json(const GbaRom& rom, const AnalysisReport& r) {
    const auto& h = rom.header(); std::ostringstream o;
    o << "{\n  \"builder_version\": \"0.5.0\",\n";
    o << "  \"title\": \"" << json_escape(h.title) << "\",\n  \"game_code\": \"" << json_escape(h.game_code) << "\",\n  \"maker_code\": \"" << json_escape(h.maker_code) << "\",\n";
    o << "  \"rom_size\": " << r.rom_size << ",\n  \"header_checksum_ok\": " << (h.checksum_ok?"true":"false") << ",\n  \"logo_signature_ok\": " << (h.logo_signature_ok?"true":"false") << ",\n";
    o << "  \"entry_word\": \"0x" << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << r.entry_word << "\",\n  \"entry_target\": \"0x" << std::setw(8) << r.entry_target << "\",\n" << std::dec;
    o << "  \"arm_branch_candidates\": " << r.arm_branch_candidates << ",\n  \"arm_bl_candidates\": " << r.arm_bl_candidates << ",\n  \"arm_bx_candidates\": " << r.arm_bx_candidates << ",\n  \"arm_swi_candidates\": " << r.arm_swi_candidates << ",\n";
    o << "  \"thumb_branch_candidates\": " << r.thumb_branch_candidates << ",\n  \"thumb_bl_candidates\": " << r.thumb_bl_candidates << ",\n  \"thumb_swi_candidates\": " << r.thumb_swi_candidates << ",\n";
    o << "  \"pointer_literals\": {\"rom\": " << r.rom_pointer_literals << ", \"ewram\": " << r.ewram_pointer_literals << ", \"iwram\": " << r.iwram_pointer_literals << ", \"io\": " << r.io_register_literals << ", \"palette\": " << r.palette_pointer_literals << ", \"vram\": " << r.vram_pointer_literals << ", \"oam\": " << r.oam_pointer_literals << ", \"sram\": " << r.sram_pointer_literals << "},\n";
    o << "  \"io_profile\": {\"display\": " << r.display_io_literals << ", \"sound\": " << r.sound_io_literals << ", \"dma\": " << r.dma_io_literals << ", \"timers\": " << r.timer_io_literals << ", \"keypad\": " << r.keypad_io_literals << ", \"irq\": " << r.irq_io_literals << "},\n";
    o << "  \"ascii_string_count\": " << r.ascii_string_count << ",\n  \"lz10_candidates\": " << r.lz10_candidates << ",\n  \"lz10_decompressed_bytes\": " << r.lz10_decompressed_bytes << ",\n";
    o << "  \"recursive_cfg\": {\"blocks\": " << r.cfg.blocks.size() << ", \"arm_blocks\": " << r.cfg.arm_blocks << ", \"thumb_blocks\": " << r.cfg.thumb_blocks << ", \"functions\": " << r.cfg.function_entries.size() << ", \"instructions\": " << r.cfg.decoded_instructions << ", \"resolved_indirects\": " << r.cfg.resolved_indirects << ", \"unresolved_indirects\": " << r.cfg.unresolved_indirects << ", \"compiler_epilogue_returns\": " << r.cfg.compiler_epilogue_returns << ", \"resolved_switch_tables\": " << r.cfg.resolved_switch_tables << ", \"resolved_switch_targets\": " << r.cfg.resolved_switch_targets << ", \"indirect_call_veneers\": " << r.cfg.indirect_call_veneers << ", \"indirect_call_sites\": " << r.cfg.indirect_call_sites << ", \"resolved_dynamic_call_sites\": " << r.cfg.resolved_dynamic_call_sites << ", \"resolved_dynamic_call_targets\": " << r.cfg.resolved_dynamic_call_targets << ", \"rom_rooted_vtables\": " << r.cfg.rooted_function_tables.size() << ", \"rom_rooted_table_slots\": " << r.cfg.rooted_table_slots << ", \"rom_rooted_distinct_methods\": " << r.cfg.rooted_table_distinct_functions << ", \"crossblock_virtual_patterns\": " << r.cfg.crossblock_virtual_patterns << ", \"constructor_callgraph_links\": " << r.cfg.constructor_callers.size() << ", \"thumb_liftable_blocks\": " << r.cfg.thumb_liftable_blocks << "},\n";
    o << "  \"code_targets\": ["; for (size_t i=0;i<r.code_targets.size();++i){if(i)o<<", ";o<<"\"0x"<<std::hex<<std::uppercase<<r.code_targets[i]<<std::dec<<"\"";} o << "],\n";
    o << "  \"lz10_streams\": ["; for(size_t i=0;i<r.lz10_streams.size();++i){if(i)o<<", ";const auto& c=r.lz10_streams[i];o<<"{\"offset\": "<<c.offset<<", \"compressed\": "<<c.compressed_size<<", \"decompressed\": "<<c.decompressed_size<<"}";} o << "],\n";
    o << "  \"warnings\": ["; for(size_t i=0;i<r.warnings.size();++i){if(i)o<<", ";o<<"\""<<json_escape(r.warnings[i])<<"\"";} o << "]\n}\n";
    return o.str();
}

std::string report_to_text(const GbaRom& rom, const AnalysisReport& r) {
    const auto& h=rom.header(); std::ostringstream o;
    o << "Port GBA Builder v2.6.0 - ROM CFG, overlays and patched ARM code\n===============================================\n";
    o << "Title: "<<h.title<<"\nGame code: "<<h.game_code<<"\nMaker: "<<h.maker_code<<"\nROM size: "<<r.rom_size<<" bytes\n";
    o << "Header checksum: "<<(h.checksum_ok?"OK":"FAIL")<<"\nNintendo logo prefix: "<<(h.logo_signature_ok?"OK":"FAIL")<<"\nARM entry branch: "<<(r.entry_looks_arm_branch?"YES":"NO")<<"\n";
    if(r.entry_looks_arm_branch)o<<"Entry target: 0x"<<std::hex<<std::uppercase<<r.entry_target<<std::dec<<"\n";
    o << "ARM B/BL candidates: "<<r.arm_branch_candidates<<" (BL "<<r.arm_bl_candidates<<")\nARM BX candidates: "<<r.arm_bx_candidates<<"\nARM SWI candidates: "<<r.arm_swi_candidates<<"\n";
    o << "Thumb branches: "<<r.thumb_branch_candidates<<"\nThumb BL pairs: "<<r.thumb_bl_candidates<<"\nThumb SWI candidates: "<<r.thumb_swi_candidates<<"\nNaive in-ROM branch targets: "<<r.code_targets.size()<<"\n";
    o << cfg_to_text(r.cfg);
    o << "Pointer literals: ROM="<<r.rom_pointer_literals<<" EWRAM="<<r.ewram_pointer_literals<<" IWRAM="<<r.iwram_pointer_literals<<" IO="<<r.io_register_literals<<" PAL="<<r.palette_pointer_literals<<" VRAM="<<r.vram_pointer_literals<<" OAM="<<r.oam_pointer_literals<<" SRAM="<<r.sram_pointer_literals<<"\n";
    o << "I/O profile: display="<<r.display_io_literals<<" sound="<<r.sound_io_literals<<" DMA="<<r.dma_io_literals<<" timers="<<r.timer_io_literals<<" keypad="<<r.keypad_io_literals<<" IRQ="<<r.irq_io_literals<<"\n";
    o << "LZ10 streams: "<<r.lz10_candidates<<" -> "<<r.lz10_decompressed_bytes<<" decompressed bytes\nASCII strings (>=5): "<<r.ascii_string_count<<"\n";
    if(!r.warnings.empty()){o<<"Warnings:\n";for(const auto&w:r.warnings)o<<" - "<<w<<"\n";}
    return o.str();
}
