#pragma once
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

struct ReplayAuditResult {
    bool valid=false;
    unsigned matching_before=0, divergent_after=0, matching_after=0;
    std::string report;
};
ReplayAuditResult audit_input_replay(const std::vector<uint8_t>& rom,
    const std::filesystem::path& baseline_manifest,
    const std::filesystem::path& active_manifest,
    unsigned first_input_frame);
