#pragma once
#include "gba_rom.hpp"
#include "cfg.hpp"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

struct Lz10Candidate {
    size_t offset = 0;
    size_t compressed_size = 0;
    size_t decompressed_size = 0;
};

struct AnalysisReport {
    size_t rom_size = 0;
    uint32_t entry_word = 0;
    bool entry_looks_arm_branch = false;
    uint32_t entry_target = 0;
    size_t arm_branch_candidates = 0;
    size_t arm_bl_candidates = 0;
    size_t arm_bx_candidates = 0;
    size_t arm_swi_candidates = 0;
    size_t thumb_branch_candidates = 0;
    size_t thumb_bl_candidates = 0;
    size_t thumb_swi_candidates = 0;
    size_t rom_pointer_literals = 0;
    size_t ewram_pointer_literals = 0;
    size_t iwram_pointer_literals = 0;
    size_t io_register_literals = 0;
    size_t palette_pointer_literals = 0;
    size_t vram_pointer_literals = 0;
    size_t oam_pointer_literals = 0;
    size_t sram_pointer_literals = 0;
    size_t display_io_literals = 0;
    size_t sound_io_literals = 0;
    size_t dma_io_literals = 0;
    size_t timer_io_literals = 0;
    size_t keypad_io_literals = 0;
    size_t irq_io_literals = 0;
    size_t ascii_string_count = 0;
    size_t lz10_candidates = 0;
    size_t lz10_decompressed_bytes = 0;
    std::vector<uint32_t> code_targets;
    GbaCfgAnalysis cfg;
    std::vector<Lz10Candidate> lz10_streams;
    std::vector<std::string> warnings;
};

AnalysisReport analyze_rom(const GbaRom& rom);
std::string report_to_json(const GbaRom& rom, const AnalysisReport& report);
std::string report_to_text(const GbaRom& rom, const AnalysisReport& report);
