#pragma once
#include "gba_rom.hpp"
#include "analyzer.hpp"
#include <filesystem>
#include <string>
#include <cstdint>
#include <vector>
#include <utility>

// Optional ROM-to-IWRAM execution map, established by boot DMA or a trace.
// Bytes are verified against LIVE RAM before dispatch: this is not a ROM CFG root.
struct GbaArmCopyRegion {
    uint32_t source_rom = 0;
    uint32_t dest_ram = 0;
    uint32_t byte_count = 0;
    uint32_t entry_ram = 0;
    bool overlay = false; // explicit alternate code image for occupied IWRAM bytes
};

struct GbaRelocatedArm {
    uint32_t source_rom = 0;
    uint32_t dest_ram = 0;
    uint32_t byte_count = 0;
    uint32_t entry_ram = 0;
    uint32_t irq_entry_ram = 0; // Optional ROM-copied BIOS IRQ callback, explicit evidence.
    std::vector<GbaArmCopyRegion> extra_copies; // Explicit runtime-observed ARM regions, not ROM CFG roots.
    std::vector<uint32_t> observed_arm_roots; // Run-observed targets, never static ROM roots.
    bool scan_rom_backed_copies=false; // opt-in bounded ARM prelift, always check live RAM opcode
    GbaRelocatedArm(uint32_t src=0,uint32_t dst=0,uint32_t size=0,uint32_t entry=0,uint32_t irq=0,
                    std::vector<GbaArmCopyRegion> extras={})
       :source_rom(src),dest_ram(dst),byte_count(size),entry_ram(entry),irq_entry_ram(irq),extra_copies(std::move(extras)){}
};
bool validate_relocated_arm(const GbaRom& rom, const GbaRelocatedArm& copy, std::string& error);

bool generate_port_project(const GbaRom& rom,
                           const AnalysisReport& report,
                           const std::filesystem::path& out_dir,
                           std::string& error,
                           const GbaRelocatedArm* relocated = nullptr);
